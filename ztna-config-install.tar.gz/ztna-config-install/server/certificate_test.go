package main

import (
	"context"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"pam-ztna-lab-server/internal/gate"
)

func configureTestCA(t *testing.T, s *gate.Store) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "ca")
	if err := exec.Command("ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", path).Run(); err != nil {
		t.Fatal("create test CA:", err)
	}
	if err := s.SetCAKey(path); err != nil {
		t.Fatal(err)
	}
	return path
}

func TestCertificateRoutesUseAdminAuthentication(t *testing.T) {
	path := filepath.Join(t.TempDir(), "grants.json")
	past := time.Now().Add(-time.Hour)
	// Route tests use inert sentinels; signing and validity are tested in gate.
	rows := []gate.Grant{
		{ID: "approved", User: "alice", Fingerprint: "a", State: "approved", Cert: "certificate-sentinel"},
		{ID: "pending", User: "alice", Fingerprint: "b", State: "pending"},
		{ID: "revoked", User: "alice", Fingerprint: "c", State: "revoked", Cert: "certificate-sentinel"},
		{ID: "expired", User: "alice", Fingerprint: "d", State: "approved", ExpiresAt: &past, Cert: "certificate-sentinel"},
		{ID: "legacy", User: "alice", Fingerprint: "e", State: "approved"},
	}
	data, _ := json.Marshal(rows)
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
	s, err := gate.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	// Pending rows loaded from disk become denied. Exercise a live pending row too.
	wire := make([]byte, 51)
	binary.BigEndian.PutUint32(wire, 11)
	copy(wire[4:], "ssh-ed25519")
	binary.BigEndian.PutUint32(wire[15:], 32)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go s.Await(ctx, gate.Request{User: "bob", Key: base64.StdEncoding.EncodeToString(wire)})
	var pendingID string
	deadline := time.Now().Add(time.Second)
	for pendingID == "" && time.Now().Before(deadline) {
		for _, g := range s.Snapshot() {
			if g.State == "pending" {
				pendingID = g.ID
			}
		}
		if pendingID == "" {
			time.Sleep(time.Millisecond)
		}
	}
	if pendingID == "" {
		t.Fatal("no live pending request")
	}
	ca := configureTestCA(t, s)
	// A tampered sibling .pub must never influence this route.
	if err := os.WriteFile(ca+".pub", []byte("PRIVATE FILE SENTINEL"), 0600); err != nil {
		t.Fatal(err)
	}
	public, err := s.CAPublicKey()
	if err != nil {
		t.Fatal(err)
	}
	token := strings.Repeat("t", 32)
	h := adminHandler(s, token)
	for _, tc := range []struct {
		path, method  string
		authenticated bool
		want          int
	}{
		{"/api/certificate?id=approved", "GET", false, 401},
		{"/api/ca/public-key", "GET", false, 401},
		{"/api/certificate?id=approved", "GET", true, 200},
		{"/api/certificate?id=pending", "GET", true, 404},
		{"/api/certificate?id=" + pendingID, "GET", true, 404},
		{"/api/certificate?id=revoked", "GET", true, 404},
		{"/api/certificate?id=expired", "GET", true, 404},
		{"/api/certificate?id=legacy", "GET", true, 404},
		{"/api/certificate?id=missing", "GET", true, 404},
		{"/api/certificate", "GET", true, 404},
		{"/api/certificate?id=approved", "POST", true, 405},
		{"/api/ca/public-key", "GET", true, 200},
		{"/api/ca/public-key", "POST", true, 405},
	} {
		r := httptest.NewRequest(tc.method, "http://127.0.0.1:8080"+tc.path, nil)
		if tc.authenticated {
			r.SetBasicAuth("admin", token)
		}
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != tc.want {
			t.Fatalf("%s %s auth=%t: got %d want %d", tc.method, tc.path, tc.authenticated, w.Code, tc.want)
		}
		if w.Code == 200 && tc.path == "/api/ca/public-key" && (w.Body.String() != public || strings.Contains(w.Body.String(), "PRIVATE")) {
			t.Fatal("route did not serve only derived public key")
		}
		if w.Code == 200 && tc.path == "/api/certificate?id=approved" && w.Body.String() != "certificate-sentinel" {
			t.Fatal("wrong certificate returned")
		}
		if w.Header().Get("Cache-Control") != "no-store" {
			t.Fatal("response may be cached")
		}
	}
}
