package gate

import (
	"bytes"
	"encoding/base64"
	"encoding/binary"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

func TestApprovalWithoutCAIsAtomic(t *testing.T) {
	s, err := Open(filepath.Join(t.TempDir(), "grants.json"))
	if err != nil {
		t.Fatal(err)
	}
	done, cancel := start(s, Request{User: "alice", Key: testKey(1)})
	defer cancel()
	g := pending(t, s)
	if err := s.Decide(g.ID, "approve", "changed", 600); err == nil {
		t.Fatal("approval without CA accepted")
	}
	if !reflect.DeepEqual(g, s.Snapshot()[0]) {
		t.Fatal("failed signing changed grant")
	}
	if _, err := os.Stat(s.path); !os.IsNotExist(err) {
		t.Fatal("failed signing persisted approval")
	}
	select {
	case <-done:
		t.Fatal("failed signing released waiter")
	default:
	}
	if _, err := s.Certificate(g.ID); err == nil {
		t.Fatal("failed signing exposed certificate")
	}
}

func TestCertificateValidityAndPersistence(t *testing.T) {
	for _, seconds := range []int64{600, 28800, 604800, 0} {
		t.Run(time.Duration(seconds*int64(time.Second)).String(), func(t *testing.T) {
			s := openTest(t)
			done, cancel := start(s, Request{User: "alice", Key: testKey(1)})
			defer cancel()
			g := pending(t, s)
			before := time.Now().Unix()
			if err := s.Decide(g.ID, "approve", "laptop", seconds); err != nil {
				t.Fatal(err)
			}
			if !<-done {
				t.Fatal("approved login rejected")
			}
			cert, err := s.Certificate(g.ID)
			if err != nil {
				t.Fatal(err)
			}
			fields := strings.Fields(cert)
			if len(fields) < 2 {
				t.Fatal("missing certificate")
			}
			wire, err := base64.StdEncoding.DecodeString(fields[1])
			if err != nil {
				t.Fatal("invalid certificate encoding")
			}
			r := bytes.NewReader(wire)
			readString := func() string {
				var n uint32
				if binary.Read(r, binary.BigEndian, &n) != nil || uint64(n) > uint64(r.Len()) {
					t.Fatal("invalid certificate field")
				}
				b := make([]byte, n)
				r.Read(b)
				return string(b)
			}
			if readString() != "ssh-ed25519-cert-v01@openssh.com" {
				t.Fatal("wrong certificate type")
			}
			readString() // nonce
			readString() // public key
			var serial uint64
			var kind uint32
			binary.Read(r, binary.BigEndian, &serial)
			binary.Read(r, binary.BigEndian, &kind)
			if kind != 1 || readString() != "alice" || readString() != "\x00\x00\x00\x05alice" {
				t.Fatal("incorrect user principal or key ID")
			}
			var after, until uint64
			if binary.Read(r, binary.BigEndian, &after) != nil || binary.Read(r, binary.BigEndian, &until) != nil {
				t.Fatal("missing validity")
			}
			ttl := seconds
			if ttl == 0 || ttl > MaxCertificateSeconds {
				ttl = MaxCertificateSeconds
			}
			if int64(until) < before+ttl || int64(until) > time.Now().Unix()+ttl || int64(after) > before {
				t.Fatal("incorrect certificate validity")
			}
			reloaded, err := Open(s.path)
			if err != nil {
				t.Fatal(err)
			}
			stored, err := reloaded.Certificate(g.ID)
			if err != nil || stored != cert {
				t.Fatal("certificate not persisted")
			}
			if row := s.Snapshot()[0]; row.Key != "" || row.Cert != "" {
				t.Fatal("list exposes signing data")
			}
			if err := s.Decide(g.ID, "revoke", "", 0); err != nil {
				t.Fatal(err)
			}
			if _, err := s.Certificate(g.ID); err == nil {
				t.Fatal("revoked certificate downloadable")
			}
		})
	}
}

func TestCertificateFailureRestoresPreviousApproval(t *testing.T) {
	s := openTest(t)
	done, cancel := start(s, Request{User: "alice", Key: testKey(2)})
	defer cancel()
	g := pending(t, s)
	if err := s.Decide(g.ID, "approve", "original", 600); err != nil {
		t.Fatal(err)
	}
	if !<-done {
		t.Fatal("approval rejected")
	}
	cert, _ := s.Certificate(g.ID)
	before := s.Snapshot()[0]
	disk, err := os.ReadFile(s.path)
	if err != nil {
		t.Fatal(err)
	}
	originalPath := s.path
	s.path = filepath.Join(t.TempDir(), "missing", "grants.json")
	if err := s.Decide(g.ID, "approve", "changed", 3600); err == nil {
		t.Fatal("save error ignored")
	}
	s.path = originalPath
	if err := os.Remove(s.caKeyPath); err != nil {
		t.Fatal(err)
	}
	if err := s.Decide(g.ID, "approve", "changed", 3600); err == nil {
		t.Fatal("signing error ignored")
	}
	current, err := s.Certificate(g.ID)
	if err != nil || current != cert || !reflect.DeepEqual(before, s.Snapshot()[0]) {
		t.Fatal("previous approval not restored")
	}
	currentDisk, err := os.ReadFile(s.path)
	if err != nil || !bytes.Equal(disk, currentDisk) {
		t.Fatal("failed renewal changed persisted approval")
	}
}

func TestCAConfigurationFailsClosed(t *testing.T) {
	s, err := Open(filepath.Join(t.TempDir(), "grants.json"))
	if err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{"", filepath.Join(t.TempDir(), "missing"), t.TempDir()} {
		if s.SetCAKey(path) == nil {
			t.Fatal("invalid CA accepted")
		}
	}
	if _, err := s.CAPublicKey(); err == nil {
		t.Fatal("unconfigured CA available")
	}
	bad := filepath.Join(t.TempDir(), "bad")
	if err := os.WriteFile(bad, []byte("invalid"), 0600); err != nil {
		t.Fatal(err)
	}
	if s.SetCAKey(bad) == nil {
		t.Fatal("invalid CA content accepted")
	}
}
