package gate

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

const MaxCertificateSeconds int64 = 8 * 60 * 60

// SetCAKey validates a dedicated, unencrypted signing key before serving traffic.
// Only ssh-keygen's public output is cached; the private contents never leave it.
func (s *Store) SetCAKey(path string) error {
	if path == "" {
		return errors.New("--ca-key is required; provide a dedicated SSH CA private key")
	}
	abs, err := filepath.Abs(path)
	if err != nil {
		return errors.New("invalid CA key path")
	}
	f, err := os.Open(abs)
	if err != nil {
		return errors.New("CA key does not exist or is not readable")
	}
	info, err := f.Stat()
	f.Close()
	if err != nil || !info.Mode().IsRegular() || info.Mode().Perm()&0077 != 0 {
		return errors.New("CA key must be a regular private file (mode 0600 or 0400)")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	// No terminal, agent or interactive passphrase prompt is allowed here.
	cmd := exec.CommandContext(ctx, "ssh-keygen", "-y", "-P", "", "-f", abs)
	public, err := cmd.Output()
	if err != nil {
		return errors.New("cannot load CA key; expected a readable unencrypted SSH private key")
	}
	fields := strings.Fields(string(public))
	if len(fields) < 2 || (!strings.HasPrefix(fields[0], "ssh-") && !strings.HasPrefix(fields[0], "ecdsa-")) {
		return errors.New("invalid public CA key output")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.caKeyPath = abs
	s.caPublicKey = fields[0] + " " + fields[1] + "\n"
	return nil
}

// CAPublicKey never reads or serves the private file (or a replaceable .pub file).
func (s *Store) CAPublicKey() (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.caPublicKey == "" {
		return "", errors.New("CA is not configured")
	}
	return s.caPublicKey, nil
}

// Certificate is the only public API accessor for the stored certificate.
func (s *Store) Certificate(id string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for _, g := range s.rows {
		if g.ID == id && active(g) && g.Cert != "" {
			return g.Cert, nil
		}
	}
	return "", errors.New("approved certificate not available")
}

// Caller holds s.mu. On failure Decide restores the complete previous grant.
func (s *Store) signCertificate(g *Grant, seconds int64) error {
	if s.caKeyPath == "" {
		return errors.New("CA signing key is not configured")
	}
	fp, err := Fingerprint(g.Key)
	if err != nil || fp != g.Fingerprint {
		return errors.New("public key missing or mismatched; a new login request is required")
	}
	// -n is a comma-separated principal list: never allow one user to add another.
	if g.User == "" || len(g.User) > 128 || strings.ContainsAny(g.User, ", \t\r\n\x00") {
		return errors.New("invalid certificate principal")
	}
	if seconds < 0 {
		return errors.New("invalid certificate duration")
	}
	if seconds == 0 || seconds > MaxCertificateSeconds {
		seconds = MaxCertificateSeconds
	}
	dir, err := os.MkdirTemp("", "ztna-sign-*")
	if err != nil {
		return errors.New("cannot create signing workspace")
	}
	defer os.RemoveAll(dir)
	keyFile := filepath.Join(dir, "user.pub")
	if err = os.WriteFile(keyFile, []byte("ssh-ed25519 "+g.Key+"\n"), 0600); err != nil {
		return errors.New("cannot prepare public key for signing")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "ssh-keygen", "-q", "-s", s.caKeyPath, "-I", g.User, "-n", g.User, "-V", fmt.Sprintf("+%ds", seconds), keyFile)
	// Suppress tool output: errors must never embed key or certificate contents.
	if err = cmd.Run(); err != nil {
		return errors.New("certificate signing failed")
	}
	cert, err := os.ReadFile(filepath.Join(dir, "user-cert.pub"))
	if err != nil || !strings.HasPrefix(string(cert), "ssh-ed25519-cert-v01@openssh.com ") {
		return errors.New("signed certificate could not be read")
	}
	g.Cert = string(cert)
	return nil
}
