package sessionguard

import "testing"

func TestKeyIsolationAndGeneration(t *testing.T) {
	r := Registry{}
	active := map[string]bool{"a": true, "b": true}
	if err := r.Register("connection-a", "run-a", "a", active); err != nil {
		t.Fatal(err)
	}
	if err := r.Register("connection-b", "run-b", "b", active); err != nil {
		t.Fatal(err)
	}
	if err := r.Register("connection-a", "run-a", "b", active); err == nil {
		t.Fatal("transport switched keys")
	}
	if err := r.Register("connection-c", "run-c", "revoked", active); err == nil {
		t.Fatal("inactive approval registered")
	}
	states := map[string]UnitState{"connection-a": {"run-a", "active"}, "connection-b": {"run-b", "active"}}
	targets := r.Targets(map[string]bool{"b": true, "new-a": true}, states)
	if len(targets) != 1 || targets["connection-a"].GrantID != "a" {
		t.Fatal("revocation did not isolate original generation", targets)
	}
	states["connection-a"] = UnitState{"replacement", "active"}
	if _, ok := r.Targets(nil, states)["connection-a"]; ok {
		t.Fatal("old binding targeted reused unit")
	}
}
func TestAuthorityFailureClosesTrackedTransports(t *testing.T) {
	r := Registry{"one": {"a", "first"}, "closed": {"b", "second"}}
	targets := r.Targets(nil, map[string]UnitState{"one": {"first", "active"}, "closed": {"second", "inactive"}})
	if len(targets) != 1 || targets["one"].GrantID != "a" {
		t.Fatal(targets)
	}
	if _, ok := r["closed"]; ok {
		t.Fatal("closed session retained")
	}
}
