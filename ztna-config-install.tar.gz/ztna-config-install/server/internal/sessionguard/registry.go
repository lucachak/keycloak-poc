// Package sessionguard binds isolated systemd SSH instances to approval IDs.
package sessionguard

import "errors"

type Binding struct{ GrantID, Invocation string }
type UnitState struct{ Invocation, Active string }
type Registry map[string]Binding

// A transport cannot switch to another approved key after its first binding.
// Thus a key probe without a signature cannot attach someone else's session.
func (r Registry) Register(unit, invocation, grantID string, active map[string]bool) error {
	if !active[grantID] {
		return errors.New("approval no longer active")
	}
	if old, ok := r[unit]; ok && old.Invocation == invocation && old.GrantID != grantID {
		return errors.New("transport already bound to another approval")
	}
	if len(r) >= 2048 {
		if _, ok := r[unit]; !ok {
			return errors.New("session registry full")
		}
	}
	r[unit] = Binding{grantID, invocation}
	return nil
}

// nil active means the authority is unavailable: close tracked transports.
// Invocation checks prevent stale records from terminating reused unit names.
func (r Registry) Targets(active map[string]bool, states map[string]UnitState) map[string]Binding {
	targets := make(map[string]Binding)
	for unit, binding := range r {
		state, ok := states[unit]
		if !ok {
			continue
		} // Missing state is an inspection error, not proof of exit.
		if state.Invocation != binding.Invocation || state.Active == "inactive" || state.Active == "failed" {
			delete(r, unit)
			continue
		}
		if !active[binding.GrantID] {
			targets[unit] = binding
		}
	}
	return targets
}
