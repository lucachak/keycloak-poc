// Package enrollment owns the one-time bootstrap registry, independently of grants.
package enrollment

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/netip"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

const TokenTTL = 15 * time.Minute

var ErrToken = errors.New("invalid, expired or already used enrollment token")
var ErrInput = errors.New("invalid hostname or IP")
var ErrPersistence = errors.New("could not persist enrollment registry")

type Endpoint struct {
	ID           string    `json:"id"`
	Hostname     string    `json:"hostname"`
	IP           string    `json:"ip"`
	RegisteredAt time.Time `json:"registered_at"`
}
type tokenRecord struct {
	Digest    string    `json:"digest"`
	Hostname  string    `json:"hostname,omitempty"`
	ExpiresAt time.Time `json:"expires_at"`
}
type registry struct {
	Tokens    []tokenRecord `json:"tokens"`
	Endpoints []Endpoint    `json:"endpoints"`
}
type Store struct {
	mu   sync.Mutex
	path string
	data registry
	now  func() time.Time
}
type Page struct {
	Items []Endpoint `json:"items"`
	Total int        `json:"total"`
	Page  int        `json:"page"`
	Pages int        `json:"pages"`
}

func Open(path string) (*Store, error) {
	s := &Store{path: path, now: time.Now}
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return s, nil
	}
	if err != nil {
		return nil, ErrPersistence
	}
	if json.Unmarshal(b, &s.data) != nil || len(s.data.Tokens) > 1024 || len(s.data.Endpoints) > 10000 {
		return nil, errors.New("invalid enrollment registry")
	}
	return s, nil
}

func validHostname(host string) bool {
	if len(host) == 0 || len(host) > 253 {
		return false
	}
	for _, label := range strings.Split(host, ".") {
		if len(label) == 0 || len(label) > 63 || label[0] == '-' || label[len(label)-1] == '-' {
			return false
		}
		for _, c := range label {
			if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-') {
				return false
			}
		}
	}
	return true
}
func digest(token string) string {
	h := sha256.Sum256([]byte(token))
	return hex.EncodeToString(h[:])
}
func randomToken() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", errors.New("cannot generate enrollment secret")
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

// Issue returns the secret exactly once. Only its SHA-256 digest is persisted.
func (s *Store) Issue(hostname string) (string, time.Time, error) {
	if hostname != "" && !validHostname(hostname) {
		return "", time.Time{}, ErrInput
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	now := s.now()
	next := registry{Endpoints: s.data.Endpoints}
	for _, t := range s.data.Tokens {
		if now.Before(t.ExpiresAt) {
			next.Tokens = append(next.Tokens, t)
		}
	}
	if len(next.Tokens) >= 1024 {
		return "", time.Time{}, errors.New("enrollment token capacity reached")
	}
	secret, err := randomToken()
	if err != nil {
		return "", time.Time{}, err
	}
	expiry := now.Add(TokenTTL)
	next.Tokens = append(next.Tokens, tokenRecord{digest(secret), strings.ToLower(hostname), expiry})
	if err := s.save(next); err != nil {
		return "", time.Time{}, err
	}
	s.data = next
	return secret, expiry, nil
}

// Register consumes a token and records its endpoint in ONE atomic transaction.
// No credential remains that could authenticate subsequent server-to-server calls.
func (s *Store) Register(secret, hostname, ip string) (Endpoint, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var zero Endpoint
	if len(secret) != 43 {
		return zero, ErrToken
	}
	now := s.now()
	index := -1
	for i, t := range s.data.Tokens {
		if t.Digest == digest(secret) && now.Before(t.ExpiresAt) {
			index = i
			break
		}
	}
	if index < 0 {
		return zero, ErrToken
	}
	if expected := s.data.Tokens[index].Hostname; expected != "" && expected != strings.ToLower(hostname) {
		return zero, ErrToken
	}
	addr, err := netip.ParseAddr(ip)
	if !validHostname(hostname) || err != nil || addr.Zone() != "" || addr.IsUnspecified() || addr.IsMulticast() || addr.IsLoopback() {
		return zero, ErrInput
	}
	if len(s.data.Endpoints) >= 10000 {
		return zero, errors.New("endpoint capacity reached")
	}
	id, err := randomToken()
	if err != nil {
		return zero, err
	}
	endpoint := Endpoint{ID: id, Hostname: strings.ToLower(hostname), IP: addr.Unmap().String(), RegisteredAt: now.UTC()}
	next := registry{Endpoints: append(append([]Endpoint(nil), s.data.Endpoints...), endpoint)}
	for i, t := range s.data.Tokens {
		if i != index && now.Before(t.ExpiresAt) {
			next.Tokens = append(next.Tokens, t)
		}
	}
	if err := s.save(next); err != nil {
		return zero, err
	}
	s.data = next
	return endpoint, nil
}

func (s *Store) List(page, limit int) (Page, error) {
	if page < 1 || limit < 1 || limit > 100 {
		return Page{}, errors.New("invalid pagination")
	}
	s.mu.Lock()
	rows := append([]Endpoint{}, s.data.Endpoints...)
	s.mu.Unlock()
	sort.Slice(rows, func(i, j int) bool {
		if rows[i].RegisteredAt.Equal(rows[j].RegisteredAt) {
			return rows[i].ID < rows[j].ID
		}
		return rows[i].RegisteredAt.After(rows[j].RegisteredAt)
	})
	pages := (len(rows) + limit - 1) / limit
	if pages == 0 {
		pages = 1
	}
	if page > pages {
		page = pages
	}
	start, end := (page-1)*limit, page*limit
	if end > len(rows) {
		end = len(rows)
	}
	return Page{rows[start:end], len(rows), page, pages}, nil
}

// Caller holds mu; failed writes never consume a token in memory.
func (s *Store) save(next registry) error {
	b, err := json.MarshalIndent(next, "", "  ")
	if err != nil {
		return ErrPersistence
	}
	f, err := os.CreateTemp(filepath.Dir(s.path), ".endpoints-*")
	if err != nil {
		return ErrPersistence
	}
	defer os.Remove(f.Name())
	defer f.Close()
	if _, err := f.Write(b); err != nil {
		return ErrPersistence
	}
	if f.Sync() != nil || f.Close() != nil {
		return ErrPersistence
	}
	if os.Rename(f.Name(), s.path) != nil {
		return ErrPersistence
	}
	return nil
}
