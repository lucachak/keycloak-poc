package enrollment

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func openTest(t *testing.T) *Store {
	t.Helper()
	s, err := Open(filepath.Join(t.TempDir(), "endpoints.json"))
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func TestTokenIsHashedBoundExpiringAndSingleUse(t *testing.T) {
	s := openTest(t)
	now := time.Now()
	s.now = func() time.Time { return now }
	secret, expiry, err := s.Issue("HOST.internal")
	if err != nil || len(secret) != 43 || !expiry.Equal(now.Add(TokenTTL)) {
		t.Fatal("token issuance failed")
	}
	b, err := os.ReadFile(s.path)
	if err != nil || bytes.Contains(b, []byte(secret)) {
		t.Fatal("plaintext token persisted")
	}
	info, _ := os.Stat(s.path)
	if info.Mode().Perm() != 0600 {
		t.Fatal("registry permissions")
	}
	if _, err := s.Register(secret, "other.internal", "172.16.0.4"); !errors.Is(err, ErrToken) {
		t.Fatal("hostname binding bypassed")
	}
	if _, err := s.Register(secret, "host.internal", "invalid"); !errors.Is(err, ErrInput) {
		t.Fatal("invalid IP accepted")
	}
	ep, err := s.Register(secret, "host.internal", "172.16.0.4")
	if err != nil || ep.Hostname != "host.internal" || ep.IP != "172.16.0.4" {
		t.Fatal("registration failed")
	}
	reloaded, err := Open(s.path)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := reloaded.Register(secret, "host.internal", "172.16.0.4"); !errors.Is(err, ErrToken) {
		t.Fatal("token replay accepted after restart")
	}
	page, err := reloaded.List(1, 25)
	if err != nil || page.Total != 1 || page.Items[0].ID != ep.ID {
		t.Fatal("endpoint not persisted")
	}
	secret, _, err = s.Issue("")
	if err != nil {
		t.Fatal(err)
	}
	now = now.Add(TokenTTL)
	if _, err := s.Register(secret, "host.internal", "172.16.0.4"); !errors.Is(err, ErrToken) {
		t.Fatal("expired token accepted")
	}
}

func TestConcurrentReplayRegistersExactlyOnce(t *testing.T) {
	s := openTest(t)
	secret, _, err := s.Issue("")
	if err != nil {
		t.Fatal(err)
	}
	var successes atomic.Int32
	var wg sync.WaitGroup
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if _, err := s.Register(secret, "host", "192.168.1.2"); err == nil {
				successes.Add(1)
			}
		}()
	}
	wg.Wait()
	if successes.Load() != 1 {
		t.Fatal("token consumed more than once")
	}
	page, _ := s.List(1, 25)
	if page.Total != 1 {
		t.Fatal("duplicate endpoint")
	}
}

func TestPersistenceFailuresAreAtomic(t *testing.T) {
	s := openTest(t)
	secret, _, err := s.Issue("host")
	if err != nil {
		t.Fatal(err)
	}
	before, _ := os.ReadFile(s.path)
	path := s.path
	s.path = filepath.Join(t.TempDir(), "absent", "endpoints.json")
	if token, _, err := s.Issue(""); err == nil || token != "" {
		t.Fatal("failed save returned usable token")
	}
	if _, err := s.Register(secret, "host", "192.168.1.2"); !errors.Is(err, ErrPersistence) {
		t.Fatal("save failure ignored")
	}
	page, _ := s.List(1, 25)
	if page.Total != 0 {
		t.Fatal("failed save registered endpoint in memory")
	}
	s.path = path
	after, _ := os.ReadFile(path)
	if !bytes.Equal(before, after) {
		t.Fatal("failed save changed disk")
	}
	if _, err := s.Register(secret, "host", "192.168.1.2"); err != nil {
		t.Fatal("failed save consumed token")
	}
}

func TestInvalidInputAndPagination(t *testing.T) {
	s := openTest(t)
	for _, host := range []string{"bad\nname", "bad name", "-bad", "bad.", "<script>"} {
		if _, _, err := s.Issue(host); !errors.Is(err, ErrInput) {
			t.Fatal("invalid hostname accepted")
		}
	}
	if _, err := s.List(0, 25); err == nil {
		t.Fatal("invalid page accepted")
	}
	if _, err := s.List(1, 101); err == nil {
		t.Fatal("unbounded page accepted")
	}
	page, err := s.List(999999999, 25)
	if err != nil || page.Page != 1 || page.Pages != 1 || page.Items == nil {
		t.Fatal("empty pagination failed")
	}
}
