//go:build linux

package main

import (
	"syscall"
	"testing"
)

func TestRejectUntrustedPeersAndUnitNames(t *testing.T) {
	g := &guard{uid: 1234, prefix: "sshd-ztna@", helper: "/usr/local/libexec/ztna-keys"}
	for _, peer := range []*syscall.Ucred{nil, {Uid: 1235, Pid: 1}, {Uid: 1234, Pid: -1}} {
		if _, err := g.peerUnit(peer); err == nil {
			t.Fatal("untrusted peer accepted")
		}
	}
	for _, bad := range []string{"../ssh.service", "sshd-ztna@*.service", "sshd-ztna@x.service;reboot", "sshd-ztna@x.service\nssh.service"} {
		if unitPattern.MatchString(bad) {
			t.Fatal("unsafe unit name", bad)
		}
	}
	if !unitPattern.MatchString("sshd-ztna@0-127.0.0.1:2222-127.0.0.1:12345.service") {
		t.Fatal("systemd connection instance rejected")
	}
}
