//go:build linux

// The guard runs as root but only stops per-connection SSH template instances.
// It never accepts a PID or systemd unit supplied by the network client.
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"os/user"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"pam-ztna-lab-server/internal/sessionguard"
)

type peerKey struct{}
type guard struct {
	mu       sync.Mutex
	registry sessionguard.Registry
	client   *http.Client
	uid      uint32
	helper   string
	prefix   string
}

var grantPattern = regexp.MustCompile(`^[a-f0-9]{32}$`)
var unitPattern = regexp.MustCompile(`^[A-Za-z0-9@_.:\\\-]+\.service$`)

func command(args ...string) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Second)
	defer cancel()
	return exec.CommandContext(ctx, "systemctl", args...).Output()
}
func states(units []string) (map[string]sessionguard.UnitState, error) {
	result := map[string]sessionguard.UnitState{}
	if len(units) == 0 {
		return result, nil
	}
	args := append([]string{"show", "--property=Id,InvocationID,ActiveState", "--"}, units...)
	output, err := command(args...)
	if err != nil {
		return nil, err
	}
	for _, block := range strings.Split(strings.TrimSpace(string(output)), "\n\n") {
		props := map[string]string{}
		for _, line := range strings.Split(block, "\n") {
			k, v, ok := strings.Cut(line, "=")
			if ok {
				props[k] = v
			}
		}
		if props["Id"] != "" {
			result[props["Id"]] = sessionguard.UnitState{Invocation: props["InvocationID"], Active: props["ActiveState"]}
		}
	}
	return result, nil
}
func (g *guard) active() (map[string]bool, error) {
	response, err := g.client.Get("http://unix/active-grants")
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	if response.StatusCode != 200 {
		return nil, fmt.Errorf("authority status %d", response.StatusCode)
	}
	var ids []string
	if err = json.NewDecoder(http.MaxBytesReader(nil, response.Body, 1<<20)).Decode(&ids); err != nil {
		return nil, err
	}
	result := make(map[string]bool, len(ids))
	for _, id := range ids {
		result[id] = true
	}
	return result, nil
}
func (g *guard) peerUnit(cred *syscall.Ucred) (string, error) {
	if cred == nil || cred.Uid != g.uid {
		return "", errors.New("unexpected peer uid")
	}
	root := fmt.Sprintf("/proc/%d", cred.Pid)
	executable, err := os.Readlink(root + "/exe")
	if err != nil || executable != g.helper {
		return "", errors.New("unexpected peer executable")
	}
	data, err := os.ReadFile(root + "/cgroup")
	if err != nil {
		return "", err
	}
	for _, line := range strings.Split(string(data), "\n") {
		parts := strings.SplitN(line, ":", 3)
		if len(parts) != 3 {
			continue
		}
		unit := filepath.Base(parts[2])
		if strings.HasPrefix(unit, g.prefix) && len(unit) < 256 && unitPattern.MatchString(unit) {
			return unit, nil
		}
	}
	return "", errors.New("helper is not inside an isolated SSH connection")
}
func (g *guard) register(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" || r.URL.Path != "/register" {
		http.Error(w, "not found", 404)
		return
	}
	cred, _ := r.Context().Value(peerKey{}).(*syscall.Ucred)
	unit, err := g.peerUnit(cred)
	if err != nil {
		log.Printf("registration rejected: %v", err)
		http.Error(w, "untrusted peer", 403)
		return
	}
	var data struct {
		GrantID string `json:"grant_id"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 1024)).Decode(&data) != nil || !grantPattern.MatchString(data.GrantID) {
		http.Error(w, "invalid registration", 400)
		return
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	active, err := g.active()
	if err != nil {
		http.Error(w, "authority unavailable", 503)
		return
	}
	state, err := states([]string{unit})
	if err != nil || state[unit].Invocation == "" {
		http.Error(w, "unit unavailable", 503)
		return
	}
	if err = g.registry.Register(unit, state[unit].Invocation, data.GrantID, active); err != nil {
		http.Error(w, err.Error(), 403)
		return
	}
	log.Printf("bound %s to approval %s", unit, data.GrantID)
	w.WriteHeader(204)
}
func (g *guard) reconcile() error {
	g.mu.Lock()
	defer g.mu.Unlock()
	units := make([]string, 0, len(g.registry))
	for unit := range g.registry {
		units = append(units, unit)
	}
	current, err := states(units)
	if err != nil {
		return fmt.Errorf("cannot inspect units: %w", err)
	}
	active, err := g.active()
	if err != nil {
		log.Printf("authority unavailable; closing tracked SSH connections")
		active = nil
	}
	for unit, binding := range g.registry.Targets(active, current) {
		if !strings.HasPrefix(unit, g.prefix) || !unitPattern.MatchString(unit) {
			return errors.New("invalid registry unit")
		}
		// Stop exactly this instance, never a wildcard, user account or shared sshd.
		if _, err := command("stop", "--no-block", "--", unit); err != nil {
			return fmt.Errorf("cannot stop %s: %w", unit, err)
		}
		log.Printf("closing %s: approval %s inactive", unit, binding.GrantID)
		delete(g.registry, unit)
	}
	return nil
}
func run() error {
	socket := flag.String("socket", "/run/pam-ztna-guard/guard.sock", "private registration socket")
	authority := flag.String("authority", "/run/pam-ztna/auth.sock", "private authorization socket")
	prefix := flag.String("unit-prefix", "sshd-ztna@", "isolated systemd template prefix")
	helper := flag.String("helper", "/usr/local/libexec/ztna-keys", "installed root-owned helper")
	flag.Parse()
	if os.Geteuid() != 0 {
		return errors.New("session guard requires root")
	}
	account, err := user.Lookup("pam-ztna")
	if err != nil {
		return err
	}
	uid, err := strconv.ParseUint(account.Uid, 10, 32)
	if err != nil {
		return err
	}
	if !strings.HasSuffix(*prefix, "@") || !unitPattern.MatchString(*prefix+"test.service") {
		return errors.New("invalid unit prefix")
	}
	transport := &http.Transport{DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
		return (&net.Dialer{Timeout: time.Second}).DialContext(ctx, "unix", *authority)
	}}
	defer transport.CloseIdleConnections()
	g := &guard{registry: sessionguard.Registry{}, client: &http.Client{Transport: transport, Timeout: 2 * time.Second}, uid: uint32(uid), helper: *helper, prefix: *prefix}
	listener, err := net.Listen("unix", *socket)
	if err != nil {
		return err
	}
	defer listener.Close()
	if err = os.Chmod(*socket, 0660); err != nil {
		return err
	}
	server := &http.Server{Handler: http.HandlerFunc(g.register), ReadHeaderTimeout: 3 * time.Second, ReadTimeout: 5 * time.Second, WriteTimeout: 8 * time.Second, ConnContext: func(ctx context.Context, c net.Conn) context.Context {
		unix, ok := c.(*net.UnixConn)
		if !ok {
			return ctx
		}
		raw, err := unix.SyscallConn()
		if err != nil {
			return ctx
		}
		var cred *syscall.Ucred
		raw.Control(func(fd uintptr) { cred, _ = syscall.GetsockoptUcred(int(fd), syscall.SOL_SOCKET, syscall.SO_PEERCRED) })
		return context.WithValue(ctx, peerKey{}, cred)
	}}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGTERM, syscall.SIGINT)
	defer stop()
	errorsCh := make(chan error, 1)
	go func() { errorsCh <- server.Serve(listener) }()
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			server.Close()
			return nil
		case err := <-errorsCh:
			return err
		case <-ticker.C:
			if err := g.reconcile(); err != nil {
				return err
			} // BindsTo closes instances if the guard fails.
		}
	}
}
func main() {
	if err := run(); err != nil {
		log.Fatal(err)
	}
}
