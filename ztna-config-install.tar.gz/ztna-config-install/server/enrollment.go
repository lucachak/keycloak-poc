package main

import (
	"crypto/tls"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"pam-ztna-lab-server/internal/enrollment"
	"pam-ztna-lab-server/internal/gate"
)

func enrollmentAdminRoutes(mux *http.ServeMux, endpoints *enrollment.Store) {
	mux.HandleFunc("/api/enrollment/tokens", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		if r.Header.Get("X-ZTNA-Admin") != "1" || r.Header.Get("Content-Type") != "application/json" {
			http.Error(w, "forbidden", 403)
			return
		}
		if endpoints == nil {
			http.Error(w, "enrollment unavailable", 503)
			return
		}
		var req struct {
			Hostname string `json:"hostname"`
		}
		if decodeEnrollment(w, r, &req) != nil {
			http.Error(w, "bad request", 400)
			return
		}
		secret, expiry, err := endpoints.Issue(req.Hostname)
		if err != nil {
			status := 503
			if errors.Is(err, enrollment.ErrInput) {
				status = 400
			}
			http.Error(w, "cannot issue enrollment token", status)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(struct {
			Token     string    `json:"token"`
			ExpiresAt time.Time `json:"expires_at"`
		}{secret, expiry})
	})
	mux.HandleFunc("/api/endpoints", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "method", 405)
			return
		}
		if endpoints == nil {
			http.Error(w, "enrollment unavailable", 503)
			return
		}
		page, limit := 1, 25
		var err error
		if r.URL.Query().Has("page") {
			page, err = strconv.Atoi(r.URL.Query().Get("page"))
		}
		if err != nil {
			http.Error(w, "invalid page", 400)
			return
		}
		if r.URL.Query().Has("limit") {
			limit, err = strconv.Atoi(r.URL.Query().Get("limit"))
		}
		if err != nil {
			http.Error(w, "invalid limit", 400)
			return
		}
		result, err := endpoints.List(page, limit)
		if err != nil {
			http.Error(w, "invalid pagination", 400)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(result)
	})
}

func decodeEnrollment(w http.ResponseWriter, r *http.Request, dst any) error {
	d := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096))
	d.DisallowUnknownFields()
	if err := d.Decode(dst); err != nil {
		return err
	}
	if d.Decode(new(any)) != io.EOF {
		return errors.New("trailing data")
	}
	return nil
}

// This listener has no dashboard, admin credentials, signing or grant routes.
// The single-use token authorizes one response containing only the PUBLIC CA key.
func enrollmentHandler(s *gate.Store, endpoints *enrollment.Store) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		if r.TLS == nil {
			http.Error(w, "TLS required", 403)
			return
		}
		// Azure public-IP DNAT may still reach a private bind. Also reject public
		// peers; never trust X-Forwarded-For to bypass this boundary. NSG rules
		// must additionally restrict the actual satellite subnets.
		peer, _, err := net.SplitHostPort(r.RemoteAddr)
		if ip := net.ParseIP(peer); err != nil || ip == nil || !ip.IsPrivate() {
			http.Error(w, "private network required", 403)
			return
		}
		auth := r.Header.Get("Authorization")
		if !strings.HasPrefix(auth, "Bearer ") || len(strings.TrimPrefix(auth, "Bearer ")) != 43 {
			http.Error(w, "enrollment authentication required", 401)
			return
		}
		if r.URL.Path != "/v1/enroll" {
			http.NotFound(w, r)
			return
		}
		if r.Method != http.MethodPost {
			http.Error(w, "method", 405)
			return
		}
		if r.URL.RawQuery != "" || r.Header.Get("Origin") != "" || r.Header.Get("Content-Type") != "application/json" {
			http.Error(w, "bad request", 400)
			return
		}
		var req struct {
			Hostname string `json:"hostname"`
			IP       string `json:"ip"`
		}
		if decodeEnrollment(w, r, &req) != nil {
			http.Error(w, "bad request", 400)
			return
		}
		public, err := s.CAPublicKey()
		if err != nil {
			http.Error(w, "enrollment unavailable", 503)
			return
		}
		endpoint, err := endpoints.Register(strings.TrimPrefix(auth, "Bearer "), req.Hostname, req.IP)
		if err != nil {
			status := 503
			if errors.Is(err, enrollment.ErrToken) {
				status = 401
			}
			if errors.Is(err, enrollment.ErrInput) {
				status = 400
			}
			http.Error(w, "enrollment refused", status)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(struct {
			Endpoint    enrollment.Endpoint `json:"endpoint"`
			CAPublicKey string              `json:"ca_public_key"`
		}{endpoint, public})
	})
}

// Enabling the listener requires an explicit RFC1918/ULA address and separate TLS
// files. Empty configuration opens no enrollment port; wildcard/public binds fail.
func enrollmentServer(address, certFile, keyFile, caFile string, handler http.Handler) (*http.Server, error) {
	if address == "" {
		if certFile != "" || keyFile != "" {
			return nil, errors.New("TLS enrollment files require --enroll-listen")
		}
		return nil, nil
	}
	host, port, err := net.SplitHostPort(address)
	ip := net.ParseIP(host)
	n, portErr := strconv.Atoi(port)
	if err != nil || portErr != nil || n < 1024 || n > 65535 || ip == nil || !ip.IsPrivate() {
		return nil, errors.New("--enroll-listen requires a private IP literal and port 1024..65535")
	}
	if certFile == "" || keyFile == "" {
		return nil, errors.New("enrollment requires TLS certificate and key")
	}
	caInfo, err := os.Stat(caFile)
	if err != nil {
		return nil, errors.New("cannot inspect SSH CA")
	}
	for _, path := range []string{certFile, keyFile} {
		info, err := os.Stat(path)
		if err != nil || os.SameFile(caInfo, info) {
			return nil, errors.New("TLS files must exist and be separate from the SSH CA")
		}
	}
	pair, err := tls.LoadX509KeyPair(certFile, keyFile)
	if err != nil {
		return nil, errors.New("cannot load enrollment TLS certificate and key")
	}
	return &http.Server{Addr: address, Handler: handler,
		TLSConfig:         &tls.Config{MinVersion: tls.VersionTLS13, Certificates: []tls.Certificate{pair}},
		ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 10 * time.Second,
		IdleTimeout: 15 * time.Second, MaxHeaderBytes: 8192}, nil
}
