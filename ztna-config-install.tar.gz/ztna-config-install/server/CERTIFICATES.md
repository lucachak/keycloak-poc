# Certificados SSH — Frente 1

O central agora exige `--ca-key /caminho/da/ca_ssh` ao iniciar. O arquivo
deve conter uma chave privada SSH dedicada, sem passphrase, legível pelo usuário
do serviço, com permissões 0600 ou 0400. Não reutilize chaves TLS ou de host SSH.
Nenhuma CA real é criada pelo programa. Configure o caminho explicitamente antes
de atualizar um serviço instalado. O instalador em `deploy/install-server.sh`
agora recebe `--ca-key` antes dos argumentos posicionais; pacotes antigos não
incluem essa alteração. Consulte `../deploy/ENROLLMENT.md`. Nenhum serviço é
instalado ou reiniciado durante a implementação e os testes de desenvolvimento.

Uma nova requisição guarda a chave pública Ed25519. A aprovação assina um
certificado de usuário, com identidade e principal iguais ao usuário solicitado.
A validade é a duração aprovada, limitada a 8 horas; duração ilimitada também
emite somente 8 horas. Falhas de assinatura ou persistência não aprovam a
requisição e preservam o estado anterior.

No mesmo endereço local/túnel do painel, autenticado como `admin`:

- `GET /api/certificate?id=ID_DO_GRANT`: baixa o certificado de um grant aprovado
  e ainda ativo. Sem certificado ou sem aprovação ativa, retorna 404.
- `GET /api/ca/public-key`: retorna exclusivamente a chave pública derivada da CA.

Para baixar manualmente, `curl --fail --user admin` solicita a senha sem colocá-la
na linha de comando. Exemplo usando a porta local do painel:

```bash
curl --fail --user admin \
  'http://127.0.0.1:8080/api/certificate?id=ID_DO_GRANT' \
  --output "$HOME/.ssh/id_ed25519_ztna-cert.pub"
```

Transfira o certificado ao dono da chave correspondente por um canal confiável.
No cliente, selecione a chave privada e o certificado explicitamente:

```bash
ssh -i ~/.ssh/id_ed25519 \
  -o CertificateFile=~/.ssh/id_ed25519_ztna-cert.pub \
  -p 2222 usuario@servidor
```

O servidor de destino precisa confiar na CA e permitir esse principal para uma
conta local existente. A automação dessa configuração pertence à Frente 2.
Não há entrega automática de certificados. Grants anteriores sem `Key` exigem
uma nova requisição para emissão. Para renovar um certificado vencido de um grant
ainda ativo, aprove novamente e baixe o novo certificado.

Revogar o grant impede novos downloads, mas não invalida certificados já
entregues. Nos satélites, certificados deixam de permitir novos logins quando
expiram; isso não encerra conexões já abertas. KRL e encerramento remoto de sessões
por certificado estão fora desta frente. O guard existente continua associado
ao fluxo local anterior.

Validação local: `go test -race ./...` e `go vet ./...`. Os testes geram CAs
efêmeras em diretórios temporários; não dependem de CA de produção. O teste manual
`tests/revocation_live.py` foi adaptado à flag, mas requer serviços locais e não é
executado por `go test`.
