package main

import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"pam-ztna-lab-server/internal/enrollment"
	"pam-ztna-lab-server/internal/gate"
)

func enrollmentFixture(t *testing.T) (*gate.Store, *enrollment.Store, string) {
	t.Helper()
	s, err := gate.Open(filepath.Join(t.TempDir(), "grants.json"))
	if err != nil {
		t.Fatal(err)
	}
	ca := configureTestCA(t, s)
	e, err := enrollment.Open(filepath.Join(t.TempDir(), "endpoints.json"))
	if err != nil {
		t.Fatal(err)
	}
	return s, e, ca
}

func TestEnrollmentAdminUsesExistingBoundary(t *testing.T) {
	s, e, _ := enrollmentFixture(t)
	admin := strings.Repeat("a", 32)
	h := adminHandler(s, admin, e)
	for _, tc := range []struct {
		path, method, token, marker, origin string
		status                              int
	}{
		{"/api/enrollment/tokens", "POST", "", "1", "", 401},
		{"/api/enrollment/tokens", "POST", admin, "", "", 403},
		{"/api/enrollment/tokens", "POST", admin, "1", "https://evil.invalid", 403},
		{"/api/enrollment/tokens", "POST", admin, "1", "", 201},
		{"/api/enrollment/tokens", "GET", admin, "1", "", 405},
		{"/api/endpoints", "GET", "", "", "", 401},
		{"/api/endpoints", "GET", admin, "", "", 200},
		{"/api/endpoints", "POST", admin, "1", "", 405},
		{"/api/endpoints?limit=101", "GET", admin, "", "", 400},
	} {
		r := httptest.NewRequest(tc.method, "http://127.0.0.1:8080"+tc.path, strings.NewReader(`{"hostname":"host"}`))
		r.SetBasicAuth("admin", tc.token)
		r.Header.Set("X-ZTNA-Admin", tc.marker)
		r.Header.Set("Content-Type", "application/json")
		r.Header.Set("Origin", tc.origin)
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != tc.status {
			t.Fatalf("%s: got %d want %d", tc.path, w.Code, tc.status)
		}
		if w.Header().Get("Cache-Control") != "no-store" {
			t.Fatal("sensitive response cacheable")
		}
	}
}

func TestHTTPSRegistrationAndPublicCAOnly(t *testing.T) {
	s, e, ca := enrollmentFixture(t)
	secret, _, err := e.Issue("host")
	if err != nil {
		t.Fatal(err)
	}
	h := enrollmentHandler(s, e)
	// HTTPS runs over loopback in tests; simulate the VNet peer seen in production.
	server := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r.RemoteAddr = "172.16.0.9:12345"
		h.ServeHTTP(w, r)
	}))
	defer server.Close()
	request := func(token, path string) *http.Response {
		r, _ := http.NewRequest("POST", server.URL+path, strings.NewReader(`{"hostname":"host","ip":"172.16.0.4"}`))
		r.Header.Set("Authorization", "Bearer "+token)
		r.Header.Set("Content-Type", "application/json")
		response, err := server.Client().Do(r)
		if err != nil {
			t.Fatal("HTTPS request failed:", err)
		}
		return response
	}
	resp := request("wrong", "/v1/enroll")
	resp.Body.Close()
	if resp.StatusCode != 401 {
		t.Fatal("anonymous enrollment accepted")
	}
	for _, path := range []string{"/", "/api/endpoints", "/api/enrollment/tokens", "/api/certificate", "/api/ca/public-key"} {
		resp := request(secret, path)
		resp.Body.Close()
		if resp.StatusCode != 404 {
			t.Fatal("admin route exposed on enrollment listener")
		}
	}
	resp = request(secret, "/v1/enroll")
	defer resp.Body.Close()
	if resp.StatusCode != 201 {
		t.Fatal("enrollment rejected")
	}
	b, _ := io.ReadAll(resp.Body)
	private, _ := os.ReadFile(ca)
	if bytes.Contains(b, private) || bytes.Contains(b, []byte(secret)) || bytes.Contains(b, []byte("PRIVATE KEY")) {
		t.Fatal("sensitive material in enrollment response")
	}
	var result struct {
		CAPublicKey string              `json:"ca_public_key"`
		Endpoint    enrollment.Endpoint `json:"endpoint"`
	}
	if json.Unmarshal(b, &result) != nil {
		t.Fatal("invalid response")
	}
	public, _ := s.CAPublicKey()
	if result.CAPublicKey != public || result.Endpoint.Hostname != "host" {
		t.Fatal("wrong public CA or endpoint")
	}
	resp = request(secret, "/v1/enroll")
	resp.Body.Close()
	if resp.StatusCode != 401 {
		t.Fatal("token replay accepted")
	}
	plain := httptest.NewRecorder()
	h.ServeHTTP(plain, httptest.NewRequest("POST", "http://localhost/v1/enroll", nil))
	if plain.Code != 403 {
		t.Fatal("plaintext HTTP accepted")
	}
	for _, peer := range []string{"8.8.8.8:1234", "127.0.0.1:1234", "invalid"} {
		r := httptest.NewRequest("POST", "https://internal/v1/enroll", nil)
		r.RemoteAddr = peer
		r.Header.Set("X-Forwarded-For", "172.16.0.9")
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != 403 {
			t.Fatal("non-private peer bypassed enrollment boundary")
		}
	}
}

func TestEnrollmentListenerFailsClosed(t *testing.T) {
	_, _, ca := enrollmentFixture(t)
	if server, err := enrollmentServer("", "", "", ca, nil); err != nil || server != nil {
		t.Fatal("listener enabled by default")
	}
	for _, address := range []string{"0.0.0.0:9443", "[::]:9443", "8.8.8.8:9443", "localhost:9443", "172.16.0.4:22", "172.16.0.4:9443"} {
		if _, err := enrollmentServer(address, "", "", ca, nil); err == nil {
			t.Fatal("invalid/incomplete listener configuration accepted")
		}
	}
	if _, err := enrollmentServer("172.16.0.4:9443", ca, ca, ca, nil); err == nil {
		t.Fatal("SSH CA reused as TLS file")
	}
	fixture := httptest.NewTLSServer(http.NotFoundHandler())
	defer fixture.Close()
	pair := fixture.TLS.Certificates[0]
	key, err := x509.MarshalPKCS8PrivateKey(pair.PrivateKey)
	if err != nil {
		t.Fatal("cannot prepare test TLS key")
	}
	certPath, keyPath := filepath.Join(t.TempDir(), "tls.crt"), filepath.Join(t.TempDir(), "tls.key")
	if os.WriteFile(certPath, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: pair.Certificate[0]}), 0600) != nil || os.WriteFile(keyPath, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: key}), 0600) != nil {
		t.Fatal("cannot prepare TLS fixture")
	}
	configured, err := enrollmentServer("172.16.0.4:9443", certPath, keyPath, ca, nil)
	if err != nil || configured.TLSConfig.MinVersion != tls.VersionTLS13 {
		t.Fatal("valid private TLS configuration rejected or downgraded")
	}
	// Boundary tests exercise handlers with TLS metadata without opening a port.
	s, e, _ := enrollmentFixture(t)
	secret, _, _ := e.Issue("")
	for _, body := range []string{`{"hostname":"h","ip":"172.16.0.4","extra":1}`, `{}` + `{}`, strings.Repeat("x", 4097)} {
		r := httptest.NewRequest("POST", "https://internal/v1/enroll", strings.NewReader(body))
		r.TLS = &tls.ConnectionState{}
		r.RemoteAddr = "172.16.0.9:12345"
		r.Header.Set("Authorization", "Bearer "+secret)
		r.Header.Set("Content-Type", "application/json")
		w := httptest.NewRecorder()
		enrollmentHandler(s, e).ServeHTTP(w, r)
		if w.Code != 400 {
			t.Fatal("malformed request accepted")
		}
	}
}
