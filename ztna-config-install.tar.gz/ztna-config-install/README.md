# Login SSH com aprovação manual — PoC

Instalação por arquivo JSON: veja [deploy/CONFIG-INSTALL.md](deploy/CONFIG-INSTALL.md).

Comece pelo [manual simples de instalação e uso](MANUAL.md).

Para a autoridade central com certificados e servidores satélites, siga o
[guia de enrollment](deploy/ENROLLMENT.md) e o [guia de certificados](server/CERTIFICATES.md).
O central exige uma CA SSH dedicada (`--ca-key`). O enrollment HTTPS é opcional,
em listener privado separado; permanece desativado até configuração explícita.
As seções abaixo descrevem o fluxo local anterior, ainda disponível no central.
Os arquivos `.tar.gz` existentes em `build/` não foram atualizados por esta mudança;
use os scripts presentes em `deploy/` para esta versão.

Esta versão autoriza **usuário + chave Ed25519** no host onde o servidor roda.
O primeiro pedido aparece no painel; aprovar libera a autenticação, negar
recusa a tentativa. A autorização pode durar 10 minutos, 30 minutos, 1 hora,
8 horas, 1 dia, 7 dias, 30 dias ou ser ilimitada, até revogação. As decisões
são persistidas em JSON (0600) antes de liberar o cliente.

O SSH continua verificando a assinatura da chave privada. O servidor Go
decide quais chaves podem entrar usando `AuthorizedKeysCommand`. A chave
privada nunca é enviada ao painel. O módulo em `module/` e o código legado
do servidor foram preservados como referência; o fluxo atual não chama
esse módulo e não publica os endpoints antigos. O PAM padrão do sistema
continua aplicando as regras de conta/sessão do SSH.

## Instaladores Bash

Consulte [deploy/INSTALACAO.md](deploy/INSTALACAO.md) para instalar o cliente
com carregamento automático no ssh-agent e o servidor com systemd. Pacotes
em `build/ztna-client-linux.tar.gz` e `build/ztna-server-linux.tar.gz`.

## Identidade e hostname

O protocolo SSH não entrega o hostname local do cliente nessa etapa.
O painel mostra o IP observado pelo sshd e permite ao operador atribuir um
**hostname/nome do dispositivo**. Esse nome é um rótulo, não uma identificação
automaticamente verificada. PTR/reverse DNS também não comprova identidade.
Uma chave diferente requer outra aprovação; mudar o IP não invalida a chave.

Use uma chave por dispositivo e confira a impressão digital antes de aprovar.
O pedido pode aparecer na consulta da chave, antes de o SSH verificar sua
assinatura. Portanto ele representa uma chave apresentada, não prova de que
a conexão já foi autenticada. Copiar a mesma chave privada para outro aparelho
faz ambos terem a mesma identidade para esta PoC.

## Compilar e validar

A partir de `files/server/`:

```bash
go test -race ./...
go vet ./...
go build -buildvcs=false -o ../build/pam-ztna-server .
go build -buildvcs=false -o ../build/ztna-keys ./cmd/ztna-keys
go build -buildvcs=false -o ../build/ztna-session-guard ./cmd/ztna-session-guard
```

Não há dependências Go externas. Os testes cobrem isolamento de usuário e chave,
aprovação persistente, negação, revogação, expiração, concorrência, falha de
gravação, autenticação/CSRF do painel e o processo real do helper via socket Unix.

## Abrir o painel localmente

**Nesta VM já instalada, abra http://127.0.0.1:8081/.** O segredo está em
`/etc/pam-ztna/admin.env` (leitura com sudo). Não inicie outra instância para
aprovar os logins do serviço: a instância manual abaixo usa outro socket/banco.


Em um terminal Bash, escolha um segredo aleatório de pelo menos 32 caracteres
e guarde-o em seu gerenciador de senhas. Informe-o sem eco no terminal:

```bash
cd /home/kali/Documents/Code/install/files/server
read -r -s -p 'Segredo administrativo: ' ZTNA_ADMIN_TOKEN
export ZTNA_ADMIN_TOKEN
../build/pam-ztna-server --port 8080 --socket auth.sock --data grants.json
```

Abra http://127.0.0.1:8080/ e entre com usuário `admin` e esse segredo.
O servidor recusa iniciar sem o segredo. O HTML, os dados e as decisões exigem
autenticação. A interface escuta somente em loopback; para acesso remoto use
um túnel SSH administrativo já disponível. Não dependa do próprio login ainda
pendente para conseguir abrir o painel e aprová-lo.

A consulta do helper usa um socket Unix privado, não a porta do painel.
Nesta PoC, servidor e helper precisam estar na máquina que recebe o SSH.
Execute apenas uma instância por banco de autorizações. O diretório do banco
e do socket deve ser privado, pertencente à conta que executa o servidor.

## Preparar a integração SSH

Use o instalador descrito no [manual](MANUAL.md). Ele configura o socket
`sshd-ztna.socket`, uma instância `sshd-ztna@.service` por conexão e o monitor
`ztna-session-guard.service`. A autorização é vinculada à instância pelo helper
antes de sua chave ser liberada. Revogar ou expirar encerra essas conexões em
poucos segundos. O painel permanece em loopback e o SSH administrativo é separado.

O template `sshd-poc.conf.example` continua como referência para testes manuais;
executá-lo isoladamente, sem o monitor e o socket systemd, apenas bloqueia
novas autenticações. Para revogar conexões abertas, é obrigatório atualizar pelo
instalador completo. Consulte também [deploy/INSTALACAO.md](deploy/INSTALACAO.md).

## Fluxo no cliente

Crie uma chave Ed25519 dedicada, protegida por passphrase, e carregue-a no
`ssh-agent` da sua sessão. A passphrase é informada ao agente; não a cada
login SSH. Ajuste o caminho se já existir uma chave com esse nome:

```bash
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519_ztna
ssh-add ~/.ssh/id_ed25519_ztna
ssh-keygen -lf ~/.ssh/id_ed25519_ztna.pub
ssh -p 2222 -o IdentitiesOnly=yes -o ControlMaster=no -o ControlPath=none -i ~/.ssh/id_ed25519_ztna USUARIO@HOST
```

Confira a chave de host no primeiro contato, como em qualquer login SSH.
No painel, confira usuário, IP e fingerprint, atribua o hostname, selecione
a validade e aprove. Saia e reconecte: não haverá outra aprovação enquanto
a autorização for válida. Revogue e reconecte: surgirá um novo pedido.
Negar ou deixar a espera expirar recusa a tentativa.

## Limites explícitos

- No listener gerenciado, revogação e expiração encerram os transportes SSH
  vinculados em poucos segundos e bloqueiam novos logins. Não encerram o SSH
  administrativo nem garantem finalizar tarefas destacadas em outros serviços.
- “Ilimitado” é a validade da autorização, não um socket que sobreviva ao logout.
- Se o agente perder a chave carregada após reboot/logout, será necessário
  desbloqueá-la novamente. A autorização no servidor continua válida.
- Só chaves Ed25519 simples são aceitas nesta PoC, não RSA ou certificados.
- Um servidor fora do ar ou uma falha de gravação não libera novos logins.
- Pendências não sobrevivem a reinícios; aprovações e revogações persistem.
- O banco tem limite de 1024 identidades para limitar crescimento por pedidos.
  Esta PoC ainda não fornece limpeza/histórico de auditoria completo.
- O painel usa Basic Auth somente em loopback/túnel, sem contas múltiplas ou
  MFA. Quem conhece o segredo administrativo tem controle sobre as decisões.
- A integração completa com o sshd precisa ser validada no listener isolado.
  Os testes automatizados do helper não substituem essa validação.
