#!/usr/bin/env bash
set +x
set -euo pipefail
base=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
exec python3 "$base/config_install.py" "$@"
