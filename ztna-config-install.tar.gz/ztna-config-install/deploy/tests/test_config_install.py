import base64
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('config_install',Path(__file__).resolve().parents[1]/'config_install.py')
app=importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)

class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='ztna-config-test-')
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.ca=self.generate('ca'); self.key=self.generate('device'); self.host=self.generate('host')
        self.pub=Path(str(self.host)+'.pub').read_bytes().split()
        self.hostfp=app.fp(str(self.host)+'.pub')
        self.cafp=app.fp(str(self.ca)+'.pub')
        self.c={'role':'client','name':'test','user':'alice','identity_file':str(self.key),'key_mode':'unprotected',
                'ca_fingerprint':self.cafp,
                'authority':{'host':'192.0.2.1','port':2222,'host_fingerprint':self.hostfp},
                'servers':[{'name':'satellite','host':'10.20.1.5','port':2222,'host_fingerprint':self.hostfp}]}

    def generate(self,label):
        p=self.root/label
        subprocess.run(['ssh-keygen','-q','-t','ed25519','-N','','-f',str(p)],check=True,capture_output=True)
        return p

    def cert(self,principal='alice',validity='+600s',key=None,ca=None):
        key=key or self.key; ca=ca or self.ca
        subprocess.run(['ssh-keygen','-q','-s',str(ca),'-I',principal,'-n',principal,'-V',validity,str(key)+'.pub'],check=True,capture_output=True)
        return Path(str(key)+'-cert.pub').read_bytes()

    def test_certificates_reject_wrong_ca_user_key_and_expiry(self):
        valid=self.cert()
        self.assertEqual(app.cert_check(self.c,valid),valid)
        for data in [self.cert('bob'),self.cert(validity='-2h:-1h'),
                     self.cert(key=self.generate('other')),
                     self.cert(ca=self.generate('other-ca'))]:
            with self.assertRaises(app.Error): app.cert_check(self.c,data)

    def test_failed_import_keeps_previous_certificate(self):
        valid=self.cert()
        invalid=self.root/'invalid.pub'
        invalid.write_bytes(b'invalid certificate')
        with self.assertRaises(app.Error): app.client_action(self.c,'import',str(invalid))
        self.assertEqual(Path(str(self.key)+'-cert.pub').read_bytes(),valid)

    def test_operator_export_needs_only_client_public_key(self):
        data=self.cert()
        pub_only=self.root/'public-only'
        Path(str(pub_only)+'.pub').write_bytes(Path(str(self.key)+'.pub').read_bytes())
        c=copy.deepcopy(self.c); c['identity_file']=str(pub_only); c['operator']={'fixture':True}
        out=self.root/'exported.pub'
        with patch.object(app,'central_call',return_value=data),contextlib.redirect_stdout(io.StringIO()):
            app.client_action(c,'export',str(out))
        self.assertFalse(pub_only.exists())
        self.assertEqual(out.read_bytes(),data)
        self.assertEqual(out.stat().st_mode&0o777,0o600)

    def test_zero_prompt_mode_generates_only_a_new_key(self):
        c=copy.deepcopy(self.c); c['identity_file']=str(self.root/'new-device')
        real=app.run
        generated=[]
        def runner(args,*a,**kw):
            if args[0]=='ssh-keyscan': return ('['+args[-1]+']:2222 ').encode()+b' '.join(self.pub[:2])+b'\n'
            if args[:2]==['ssh-keygen','-t']:
                generated.append(args)
                return subprocess.run(args,check=True,capture_output=True).stdout
            return real(args,*a,**kw)
        with patch.object(Path,'home',return_value=self.root),patch.object(os,'geteuid',return_value=1000),patch.object(app,'run',side_effect=runner),contextlib.redirect_stdout(io.StringIO()):
            app.install_client(c,False)
            original=Path(c['identity_file']).read_bytes()
            app.install_client(c,False)
        self.assertEqual(len(generated),1)
        self.assertEqual(generated[0][-2:],['-N',''])
        self.assertEqual(Path(c['identity_file']).read_bytes(),original)
        self.assertEqual(Path(c['identity_file']).stat().st_mode&0o777,0o600)

    def test_json_is_data_and_paths_resolve_beside_config(self):
        p=self.root/'client.json'
        c=copy.deepcopy(self.c); c['identity_file']='device'; c['name']='x\nProxyCommand bad'
        p.write_text(json.dumps(c))
        config=app.load(str(p))
        self.assertEqual(config['identity_file'],str(self.key))
        with self.assertRaises(app.Error): app.render_client(config)

    def test_all_scanned_keys_must_match(self):
        correct=b'host '+b' '.join(self.pub[:2])+b'\n'
        other=Path(str(self.key)+'.pub').read_bytes().split()
        incorrect=b'host '+b' '.join(other[:2])+b'\n'
        app.scan_check(correct,self.hostfp)
        with self.assertRaises(app.Error): app.scan_check(correct+incorrect,self.hostfp)

    def test_install_client_and_generated_ssh_configuration(self):
        real=app.run
        def runner(args,*a,**kw):
            if args[0]=='ssh-keyscan':
                return ('['+args[-1]+']:2222 ').encode()+b' '.join(self.pub[:2])+b'\n'
            return real(args,*a,**kw)
        c=copy.deepcopy(self.c); c['operator']={'sensitive':'must not be distributed'}
        with patch.object(Path,'home',return_value=self.root),patch.object(os,'geteuid',return_value=1000),patch.object(app,'run',side_effect=runner),contextlib.redirect_stdout(io.StringIO()):
            app.install_client(c,False)
            root=app.profile_dir(c)
            stored=json.loads((root/'client.json').read_text())
            self.assertNotIn('operator',stored)
            self.assertEqual((root/'known_hosts').stat().st_mode&0o777,0o600)
            result=subprocess.run(['ssh','-G','-F',str(root/'ssh_config'),'satellite'],capture_output=True,text=True,check=True)
            self.assertIn('batchmode yes',result.stdout)
            self.assertIn('stricthostkeychecking true',result.stdout)
            self.assertIn('passwordauthentication no',result.stdout)
            self.assertIn('pubkeyacceptedalgorithms ssh-ed25519-cert-v01@openssh.com',result.stdout)
            self.assertTrue((self.root/'.local/bin/ztna-test').exists())

    def test_proxyjump_retains_pinned_known_hosts(self):
        c=copy.deepcopy(self.c)
        c['jump']={'host':'192.0.2.1','user':'admin','identity_file':str(self.key),'host_fingerprint':self.hostfp}
        c['servers'][0]['via_jump']=True
        with patch.object(Path,'home',return_value=self.root):
            config,_=app.render_client(c)
            p=self.root/'ssh_config'; p.write_text(config)
            result=subprocess.run(['ssh','-G','-F',str(p),'satellite'],capture_output=True,text=True,check=True)
            self.assertIn('proxyjump ztna-jump',result.stdout)
            self.assertIn('userknownhostsfile '+str(self.root/'.config/ztna/test/known_hosts'),result.stdout)

    def endpoint_config(self):
        hosts=self.root/'known_hosts'; hosts.write_text('fixture')
        ssh={'host':'192.0.2.1','user':'admin','identity_file':str(self.key),'known_hosts_file':str(hosts)}
        return {'role':'endpoint','central':{'ssh':ssh,'enrollment_url':'https://172.16.0.4:9443'},
                'target':{'ssh':ssh,'hostname':'new-host','listen_ip':'10.20.1.8','users':['alice']}}

    def test_failed_preflight_never_issues_token(self):
        calls=[]
        def remote(h,args,data=None):
            if args==['hostname']: return b'new-host\n'
            if '--check' in args: raise app.Error('preflight rejected')
            return b''
        def central(c,op,**kw): calls.append(op); return b'public tls fixture'
        with patch.object(app,'remote',side_effect=remote),patch.object(app,'central_call',side_effect=central),patch.object(app,'upload',return_value='/tmp/ztna-bootstrap-test'),contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(app.Error): app.endpoint(self.endpoint_config(),False)
        self.assertEqual(calls,['tls'])

    def test_failed_install_does_not_retry_and_cleans_temporaries(self):
        calls=[]; installed=[]; cleaned=[]
        def remote(h,args,data=None):
            if args==['hostname']: return b'new-host\n'
            if '--check' in args: return b'preflight passed\n'
            if '--token-file' in args:
                installed.append(args); raise app.Error('network response lost')
            cleaned.append(args); return b''
        def central(c,op,**kw):
            calls.append(op)
            return b'public fixture' if op=='tls' else json.dumps({'token':'t'*43}).encode()
        with patch.object(app,'remote',side_effect=remote),patch.object(app,'central_call',side_effect=central),patch.object(app,'upload',return_value='/tmp/ztna-bootstrap-test'),contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(app.Error): app.endpoint(self.endpoint_config(),False)
        self.assertEqual(calls,['tls','token']); self.assertEqual(len(installed),1); self.assertEqual(len(cleaned),1)

    def test_remote_arguments_are_shell_quoted_and_batch_only(self):
        c=self.endpoint_config()
        with patch.object(app,'run',return_value=b'') as run:
            app.remote(c['central']['ssh'],['python3','-c','print("$(touch BAD)")'])
        args=run.call_args.args[0]
        self.assertIn('BatchMode=yes',args)
        self.assertIn('StrictHostKeyChecking=yes',args)
        self.assertEqual(__import__('shlex').split(args[-1]),['python3','-c','print("$(touch BAD)")'])

if __name__=='__main__': unittest.main()
