"""Fault-injection tests; all installation paths and service commands are isolated.

Runs the Bash script against a temporary filesystem, mock network/systemd and
real sshd -t for generated configurations. Never installs or starts host services.
"""
import json
import os
import pwd
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import tempfile
import threading
import unittest


STUB = r'''#!/usr/bin/env python3
import json, os, pathlib, subprocess, sys
root = pathlib.Path(os.environ['ENROLL_TEST_ROOT'])
tool = pathlib.Path(sys.argv[0]).name
args = sys.argv[1:]
fault = os.environ.get('ENROLL_TEST_FAULT', '')
with (root/'events').open('a') as f:
    f.write(json.dumps([tool, args])+'\n')
if tool == 'getent':
    print('alice:x:1000:1000::/home/alice:/bin/bash')
elif tool == 'ip':
    print(json.dumps([{'addr_info': [{'local': '172.16.0.9'}]}]))
elif tool == 'systemctl':
    if args[0] == 'show':
        if args[-1] == 'sshd-ztna@.service': sys.exit(1)
        print('loaded' if fault == 'existing' else 'not-found')
    elif args[0] == 'start' and fault == 'start':
        sys.exit(1)
elif tool == 'sshd':
    if '-f' in args:
        config = args[args.index('-f')+1]
        if fault == 'validation' or (fault == 'installed-validation' and config.endswith('sshd_config_ztna')):
            sys.exit(1)
        result = subprocess.run([os.environ['ENROLL_TEST_SSHD'], *args], capture_output=True)
        if result.returncode:
            sys.stderr.write(result.stderr.decode())
        sys.exit(result.returncode)
elif tool == 'curl':
    if '--write-out' in args:
        assert '--tlsv1.3' in args and '--resolve' in args
        assert not any(a.startswith('@') for a in args)
        if fault == 'network': sys.exit(60)
        print('401', end='')
        sys.exit(0)
    assert args[0] == '--disable'
    assert not any(a in args for a in ['-k', '--insecure', '--retry', '-L', '--location'])
    token = (root/'token').read_text().strip()
    assert all(token not in arg for arg in args)
    header = next(a[1:] for a in args if a.startswith('@') and a.endswith('/headers'))
    assert pathlib.Path(header).read_text() == 'Authorization: Bearer '+token+'\n'
    assert '--resolve' in args and '--tlsv1.3' in args
    if fault == 'network': sys.exit(22)
    out = pathlib.Path(args[args.index('--output')+1])
    key = ' '.join((root/'ca.pub').read_text().split()[:2])+'\n'
    if fault == 'bad-response': key = 'PRIVATE KEY'
    request = json.loads((out.parent/'request.json').read_text())
    out.write_text(json.dumps({'ca_public_key':key,'endpoint':{'id':'test-id',**request,'registered_at':'2026-01-01T00:00:00Z'}}))
'''


@unittest.skipUnless(os.geteuid() == 0 and shutil.which('sshd'), 'requires root for isolated root-owned sshd configuration validation')
class EnrollmentInstallTests(unittest.TestCase):
    def setUp(self):
        # StrictModes rejects AuthorizedPrincipalsFile paths beneath writable /tmp.
        # /run is noexec on some hosts, so keep executable stubs under /var/lib.
        self.tmp = tempfile.TemporaryDirectory(prefix='ztna_enroll_test_', dir='/var/lib')
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.ssh = self.root/'etc/ssh'
        self.units = self.root/'etc/systemd/system'
        for directory in [self.ssh, self.units, self.root/'run/systemd/system', self.root/'run/lock', self.root/'bin']:
            directory.mkdir(parents=True, exist_ok=True)
        for key in [self.root/'ca', self.ssh/'ssh_host_ed25519_key']:
            subprocess.run(['ssh-keygen','-q','-t','ed25519','-N','','-f',str(key)], check=True, capture_output=True)
        self.secret = secrets.token_urlsafe(32)
        (self.root/'token').write_text(self.secret+'\n')
        (self.root/'token').chmod(0o600)
        source = Path(__file__).resolve().parents[1]/'enroll-endpoint.sh'
        script = source.read_text()
        for path in ['/etc/ssh','/etc/systemd/system','/run/systemd/system','/run/lock']:
            script = script.replace(path, str(self.root/path.lstrip('/')))
        self.script = self.root/'enroll.sh'
        self.script.write_text(script)
        for tool in ['sshd','curl','systemctl','ip','getent']:
            path = self.root/'bin'/tool
            path.write_text(STUB)
            path.chmod(0o755)
        self.env = dict(os.environ, ENROLL_TEST_ROOT=str(self.root), ENROLL_TEST_SSHD=shutil.which('sshd'), PATH=str(self.root/'bin')+':'+os.environ['PATH'])

    def run_script(self, fault='', central='https://172.16.0.4:9443'):
        self.env['ENROLL_TEST_FAULT'] = fault
        result = subprocess.run(['bash',str(self.script),'--central',central,'--listen-ip','172.16.0.9','--users','alice','--token-file',str(self.root/'token')], env=self.env, capture_output=True, text=True, timeout=20)
        self.assertNotIn(self.secret, result.stdout+result.stderr)
        self.assertEqual(list(self.ssh.glob('.ztna-enroll.*')), [])
        return result

    def events(self):
        path = self.root/'events'
        return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

    def assert_no_install(self):
        for name in ['sshd_config_ztna','ztna_ca.pub','ztna_principals','ztna_endpoint.json']:
            self.assertFalse((self.ssh/name).exists(), name)
        self.assertFalse((self.units/'sshd-ztna.socket').exists())
        self.assertFalse((self.units/'sshd-ztna@.service').exists())

    def test_success_validates_before_start_and_maps_only_local_principal(self):
        result = self.run_script()
        self.assertEqual(result.returncode,0,result.stderr)
        events = self.events()
        start = next(i for i,e in enumerate(events) if e == ['systemctl',['start','sshd-ztna.socket']])
        validations = [i for i,e in enumerate(events) if e[0]=='sshd' and '-f' in e[1]]
        self.assertEqual(len(validations),2)
        self.assertTrue(all(i < start for i in validations))
        self.assertEqual((self.ssh/'ztna_principals/alice').read_text(),'alice\n')
        config = (self.ssh/'sshd_config_ztna').read_text()
        self.assertIn('Port 2222\n',config)
        self.assertIn('AuthorizedKeysFile none\n',config)
        self.assertIn('PubkeyAcceptedAlgorithms ssh-ed25519-cert-v01@openssh.com\n',config)
        self.assertNotIn('Include ',config)
        self.assertFalse((self.ssh/'sshd_config').exists())
        self.assertEqual(sum(e[0]=='curl' for e in events),1)

    def test_invalid_staging_config_never_touches_services(self):
        result = self.run_script('validation')
        self.assertNotEqual(result.returncode,0)
        self.assert_no_install()
        self.assertFalse(any(e[0]=='systemctl' and e[1][0]!='show' for e in self.events()))
        self.assertIn('consumiu o token',result.stderr)

    def test_invalid_installed_config_rolls_back_before_service_actions(self):
        result = self.run_script('installed-validation')
        self.assertNotEqual(result.returncode,0)
        self.assert_no_install()
        self.assertFalse(any(e[0]=='systemctl' and e[1][0]!='show' for e in self.events()))

    def test_socket_start_failure_rolls_back_only_new_listener(self):
        result = self.run_script('start')
        self.assertNotEqual(result.returncode,0)
        self.assert_no_install()
        events = self.events()
        self.assertIn(['systemctl',['disable','--now','sshd-ztna.socket']],events)
        self.assertFalse(any(e[0]=='systemctl' and any(a in ('ssh','sshd','ssh.service','sshd.service') for a in e[1]) for e in events))

    def test_network_failure_has_no_retry(self):
        result = self.run_script('network')
        self.assertNotEqual(result.returncode,0)
        self.assert_no_install()
        self.assertEqual(sum(e[0]=='curl' for e in self.events()),1)
        self.assertIn('confira o painel',result.stderr)

    def test_invalid_ca_response_aborts(self):
        result = self.run_script('bad-response')
        self.assertNotEqual(result.returncode,0)
        self.assert_no_install()

    def test_precheck_verifies_tls_without_token_or_service_changes(self):
        result = subprocess.run(['bash',str(self.script),'--central','https://172.16.0.4:9443',
                                 '--listen-ip','172.16.0.9','--users','alice','--check'],
                                env=self.env,capture_output=True,text=True,timeout=20)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assert_no_install()
        events = self.events()
        self.assertEqual(sum(e[0]=='curl' for e in events),1)
        self.assertFalse(any(e[0]=='systemctl' and e[1][0]!='show' for e in events))
        self.assertEqual(list(self.ssh.glob('.ztna-enroll.*')),[])

    def test_existing_unit_is_not_overwritten(self):
        result = self.run_script('existing')
        self.assertNotEqual(result.returncode,0)
        self.assert_no_install()
        self.assertFalse(any(e[0]=='curl' for e in self.events()))

    def test_public_or_plaintext_central_is_refused(self):
        for central in ['http://172.16.0.4:9443','https://8.8.8.8:9443']:
            with self.subTest(central=central):
                result = self.run_script(central=central)
                self.assertNotEqual(result.returncode,0)
                self.assert_no_install()
                self.assertFalse(any(e[0]=='curl' for e in self.events()))

    def test_real_ssh_accepts_ca_certificate_and_rejects_wrong_principal(self):
        candidates = [p for p in pwd.getpwall() if 1000 <= p.pw_uid < 65534 and p.pw_shell.endswith(('/bash','/zsh','/sh'))]
        if not candidates:
            self.skipTest('requires an existing non-root login account for local SSH fixture')
        user = candidates[0].pw_name
        # sshd opens AuthorizedPrincipalsFile under the target user's UID.
        # Match /etc traversal permissions; private keys and tokens stay 0600.
        self.root.chmod(0o755)
        result = self.run_script()
        self.assertEqual(result.returncode,0,result.stderr)
        config = self.ssh/'sshd_config_ztna'
        config.write_text(config.read_text().replace('AllowUsers alice\n',f'AllowUsers {user}\n'))
        principal = self.ssh/'ztna_principals'/user
        principal.write_text(user+'\n')
        principal.chmod(0o644)
        subprocess.run([self.env['ENROLL_TEST_SSHD'],'-t','-f',str(config)],check=True,capture_output=True)
        for label in ['correct','wrong','unsigned']:
            key = self.root/label
            subprocess.run(['ssh-keygen','-q','-t','ed25519','-N','','-f',str(key)],check=True,capture_output=True)
            if label != 'unsigned':
                name = user if label == 'correct' else 'unrelated-principal'
                subprocess.run(['ssh-keygen','-q','-s',str(self.root/'ca'),'-I',name,'-n',name,'-V','+600s',str(key)+'.pub'],check=True,capture_output=True)
        # Model systemd Accept=yes: one sshd -i per accepted loopback connection.
        for label in ['correct','wrong','unsigned']:
            with self.subTest(identity=label), socket.socket() as listener:
                listener.bind(('127.0.0.1',0))
                listener.listen(1)
                listener.settimeout(10)
                port = listener.getsockname()[1]
                errors = []
                daemon_log = []
                def serve():
                    try:
                        connection, _ = listener.accept()
                        with connection:
                            child = subprocess.Popen([self.env['ENROLL_TEST_SSHD'],'-i','-e','-f',str(config)],stdin=connection,stdout=connection,stderr=subprocess.PIPE)
                            try:
                                _, stderr = child.communicate(timeout=10)
                                daemon_log.append(stderr.decode())
                            except subprocess.TimeoutExpired:
                                child.kill()
                                child.communicate()
                                errors.append('sshd fixture timed out')
                    except Exception as exc:
                        errors.append(type(exc).__name__)
                worker = threading.Thread(target=serve)
                worker.start()
                key = self.root/label
                options = ['ssh','-F','/dev/null','-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','IdentityAgent=none',
                           '-o','StrictHostKeyChecking=no','-o','UserKnownHostsFile=/dev/null','-o','ConnectTimeout=5',
                           '-i',str(key),'-p',str(port),f'{user}@127.0.0.1','printf READY']
                try:
                    client = subprocess.run(options,capture_output=True,text=True,timeout=12)
                finally:
                    worker.join(timeout=12)
                self.assertFalse(worker.is_alive())
                self.assertEqual(errors,[])
                if label == 'correct':
                    self.assertEqual(client.returncode,0,client.stderr+'\n'+''.join(daemon_log))
                    self.assertEqual(client.stdout,'READY')
                else:
                    self.assertNotEqual(client.returncode,0)


if __name__ == '__main__':
    unittest.main()
