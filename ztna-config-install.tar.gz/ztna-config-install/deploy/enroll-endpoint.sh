#!/usr/bin/env bash
# One-time satellite bootstrap. No authority daemon or session guard is installed.
set +x
set -Eeuo pipefail
umask 077
usage() {
    cat <<'EOF'
Uso: sudo bash enroll-endpoint.sh --central https://central.interno:9443 \
  --listen-ip IP_LOCAL --users lucas[,outro] [--tls-ca CA_TLS.pem] [--token-file ARQUIVO]
Sem --token-file, solicita o token sem eco no terminal. Nunca passe o token como argumento.
Exige contas locais existentes, OpenSSH, systemd, curl, Python 3, iproute2 e flock.
Instala somente SSH por certificado na porta 2222; não altera a porta 22.
EOF
}
die() { echo "Enrollment abortado: $*" >&2; exit 1; }
central='' address='' users='' tls_ca='' token_file='' check_only=0
while (( $# )); do
    case $1 in
        --help) usage; exit 0 ;;
        --check) check_only=1; shift ;;
        --central|--listen-ip|--users|--tls-ca|--token-file)
            (( $# >= 2 )) || die "Valor ausente para $1."
            case $1 in
                --central) central=$2 ;; --listen-ip) address=$2 ;; --users) users=$2 ;;
                --tls-ca) tls_ca=$2 ;; --token-file) token_file=$2 ;;
            esac
            shift 2 ;;
        *) die 'Opção desconhecida; consulte --help.' ;;
    esac
done
[[ $EUID == 0 ]] || die 'Execute com sudo.'
[[ -n $central && -n $address && -n $users ]] || { usage; exit 1; }
[[ -d /run/systemd/system ]] || die 'É necessário systemd ativo.'
for tool in curl python3 ip sshd ssh-keygen systemctl getent flock install; do
    command -v "$tool" >/dev/null || die "Dependência ausente: $tool."
done
exec 9>/run/lock/ztna-enroll.lock
flock -n 9 || die 'Outro enrollment está em execução.'
sshd_bin=$(command -v sshd)
[[ $sshd_bin =~ ^/[a-zA-Z0-9_/-]+$ ]] || die 'Caminho de sshd não suportado.'
[[ -z $tls_ca || -r $tls_ca ]] || die 'CA TLS não legível.'
[[ $users =~ ^[a-z_][a-z0-9_-]*(,[a-z_][a-z0-9_-]*)*$ ]] || die 'Informe contas Unix separadas por vírgula.'
IFS=',' read -r -a accounts <<< "$users"
for account in "${accounts[@]}"; do
    entry=$(getent passwd "$account") || die "Conta local inexistente: $account."
    IFS=: read -r _ _ uid _ _ _ login_shell <<< "$entry"
    [[ $uid != 0 && $login_shell != */nologin && $login_shell != */false ]] || die "Conta não permitida: $account."
done
config=/etc/ssh/sshd_config_ztna
ca_path=/etc/ssh/ztna_ca.pub
principals=/etc/ssh/ztna_principals
receipt=/etc/ssh/ztna_endpoint.json
socket_unit=/etc/systemd/system/sshd-ztna.socket
service_unit=/etc/systemd/system/sshd-ztna@.service
# Never overwrite an existing installation, including vendor units or drop-ins.
for path in "$config" "$ca_path" "$principals" "$receipt" "$socket_unit" "$service_unit" \
    /etc/systemd/system/sshd-ztna.socket.d /etc/systemd/system/sshd-ztna@.service.d; do
    [[ ! -e $path && ! -L $path ]] || die "Já existe $path; diagnostique antes de repetir."
done
for unit in sshd-ztna.socket sshd-ztna@enrollment-check.service sshd-ztna.service; do
    load_state=$(systemctl show --property=LoadState --value "$unit") || die "Não foi possível consultar $unit."
    [[ $load_state == not-found ]] || die "Unidade $unit já existente; exige revisão manual."
done
[[ -r /etc/ssh/ssh_host_ed25519_key ]] || die 'Instale/configure o OpenSSH e sua host key Ed25519 primeiro.'
"$sshd_bin" -t || die 'A configuração SSH administrativa já está inválida; corrija antes do enrollment.'
stage=$(mktemp -d /etc/ssh/.ztna-enroll.XXXXXXXX)
created=() activated=0 committed=0 enrolled=0
cleanup() {
    status=$?
    trap - EXIT
    if (( ! committed )); then
        if (( activated )); then
            if ! systemctl disable --now sshd-ztna.socket >/dev/null 2>&1; then
                echo 'Falha ao remover o socket recém-criado; revise sshd-ztna.socket manualmente.' >&2
            fi
            systemctl stop 'sshd-ztna@*.service' >/dev/null 2>&1 || true
        fi
        for path in "${created[@]}"; do rm -rf -- "$path"; done
        if (( activated )); then systemctl daemon-reload || true; fi
        echo 'Instalação não concluída; arquivos desta tentativa removidos. SSH administrativo preservado.' >&2
        if (( enrolled )); then
            echo 'O central já consumiu o token e registrou o endpoint. Diagnostique o erro antes de emitir outro token; não repita às cegas.' >&2
        fi
    fi
    rm -rf -- "$stage"
    exit "$status"
}
trap cleanup EXIT
# Resolve once and pin curl to this private IPv4. TLS still verifies the URL hostname.
python3 - "$central" "$address" > "$stage/network" <<'PY'
import ipaddress, json, socket, subprocess, sys, urllib.parse
try:
    u = urllib.parse.urlsplit(sys.argv[1])
    if u.scheme != 'https' or not u.hostname or u.username or u.password or u.path not in ('', '/') or u.query or u.fragment:
        raise ValueError()
    if any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-' for c in u.hostname):
        raise ValueError()
    port = u.port or 443
    networks = [ipaddress.ip_network(n) for n in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16')]
    ips = sorted({r[4][0] for r in socket.getaddrinfo(u.hostname, port, socket.AF_INET, socket.SOCK_STREAM)})
    if not ips or any(not any(ipaddress.ip_address(ip) in net for net in networks) for ip in ips):
        raise ValueError()
    address = ipaddress.IPv4Address(sys.argv[2])
    local = json.loads(subprocess.check_output(['ip','-j','-4','address','show']))
    if address.is_loopback or address.is_unspecified or address.is_multicast or not any(str(address) == a.get('local') for link in local for a in link.get('addr_info', [])):
        raise ValueError()
    print(f'https://{u.hostname}:{port}')
    print(f'{u.hostname}:{port}:{ips[0]}')
except Exception:
    sys.exit('URL HTTPS interna ou IPv4 local inválido; nenhuma chamada ao central realizada.')
PY
mapfile -t network < "$stage/network"
central=${network[0]}
resolve=${network[1]}
python3 - "$address" > "$stage/request.json" <<'PY'
import json, socket, sys
hostname = socket.gethostname().lower()
labels = hostname.split('.')
if len(hostname) > 253 or any(not x or len(x) > 63 or x.startswith('-') or x.endswith('-') or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in x) for x in labels):
    sys.exit('Hostname local inválido; corrija antes do enrollment.')
json.dump({'hostname': hostname, 'ip': sys.argv[1]}, sys.stdout)
PY
if (( check_only )); then
    check_args=(--disable --silent --show-error --proto '=https' --tlsv1.3 --noproxy '*' --connect-timeout 10 --max-time 15 --resolve "$resolve")
    [[ -z $tls_ca ]] || check_args+=(--cacert "$tls_ca")
    status=$(curl "${check_args[@]}" --output /dev/null --write-out '%{http_code}' "$central/v1/enroll") || die 'Pré-check HTTPS falhou; nenhum token consumido.'
    [[ $status == 401 ]] || die 'Pré-check HTTPS retornou um status inesperado; nenhum token consumido.'
    committed=1
    echo 'Pré-check concluído; nenhum token consumido e nenhum serviço alterado.'
    exit 0
fi
if [[ -n $token_file ]]; then
    [[ -f $token_file && -r $token_file ]] || die 'Arquivo do token não legível.'
    IFS= read -r token < "$token_file" || [[ -n ${token:-} ]] || die 'Token vazio.'
else
    IFS= read -r -s -p 'Token de enrollment: ' token </dev/tty || die 'Não foi possível ler o token.'
    echo >/dev/tty
fi
[[ $token =~ ^[A-Za-z0-9_-]{43}$ ]] || die 'Formato de token inválido.'
printf 'Authorization: Bearer %s\n' "$token" > "$stage/headers"
unset token
curl_args=(--disable --silent --show-error --fail --proto '=https' --tlsv1.3 --noproxy '*' --connect-timeout 10 --max-time 30 --resolve "$resolve")
[[ -z $tls_ca ]] || curl_args+=(--cacert "$tls_ca")
# No redirects, retries, insecure TLS or command-line bearer secret.
if ! curl "${curl_args[@]}" --header "@$stage/headers" --header 'Content-Type: application/json' \
    --data-binary "@$stage/request.json" --output "$stage/response.json" "$central/v1/enroll"; then
    rm -f -- "$stage/headers"
    die 'Falha HTTPS/enrollment. A resposta pode ter se perdido após consumo do token; confira o painel antes de qualquer nova tentativa.'
fi
enrolled=1
rm -f -- "$stage/headers"
python3 - "$stage" "$central" <<'PY'
import json, pathlib, sys
p = pathlib.Path(sys.argv[1])
try:
    response = json.loads((p/'response.json').read_text())
    request = json.loads((p/'request.json').read_text())
    key = response['ca_public_key']
    endpoint = response['endpoint']
    if endpoint['hostname'] != request['hostname'] or endpoint['ip'] != request['ip'] or not endpoint['id']:
        raise ValueError()
    fields = key.split()
    if len(fields) != 2 or fields[0] not in ('ssh-ed25519', 'ssh-rsa', 'ecdsa-sha2-nistp256', 'ecdsa-sha2-nistp384', 'ecdsa-sha2-nistp521') or '\n' in key.strip():
        raise ValueError()
    (p/'ca.pub').write_text(' '.join(fields)+'\n')
    (p/'receipt.json').write_text(json.dumps({'central': sys.argv[2], 'endpoint': endpoint}, indent=2)+'\n')
except Exception:
    sys.exit('Resposta de enrollment inválida; nenhum certificado ou segredo será impresso.')
PY
ssh-keygen -l -f "$stage/ca.pub" >/dev/null || die 'Chave pública da CA inválida.'
mkdir -m 0755 "$stage/principals"
for account in "${accounts[@]}"; do printf '%s\n' "$account" > "$stage/principals/$account"; done
# Independent configuration: never Include the administrative sshd_config.
cat > "$stage/sshd_config" <<EOF
# Managed by enroll-endpoint.sh for the dedicated certificate listener only.
Port 2222
ListenAddress $address
HostKey /etc/ssh/ssh_host_ed25519_key
PidFile /run/sshd-ztna.pid
AllowUsers ${accounts[*]}
PermitRootLogin no
UsePAM yes
AuthenticationMethods publickey
PubkeyAuthentication yes
PubkeyAcceptedAlgorithms ssh-ed25519-cert-v01@openssh.com
PasswordAuthentication no
KbdInteractiveAuthentication no
HostbasedAuthentication no
GSSAPIAuthentication no
AuthorizedKeysFile none
AuthorizedKeysCommand none
AuthorizedPrincipalsCommand none
TrustedUserCAKeys $ca_path
AuthorizedPrincipalsFile $principals/%u
LoginGraceTime 30
MaxAuthTries 3
DisableForwarding yes
PermitUserEnvironment no
Subsystem sftp internal-sftp
EOF
cat > "$stage/sshd-ztna.socket" <<EOF
[Unit]
DefaultDependencies=no
Conflicts=shutdown.target
Before=shutdown.target
Description=ZTNA SSH user certificates (port 2222)
After=network-online.target
Wants=network-online.target

[Socket]
ListenStream=$address:2222
Accept=yes
Service=sshd-ztna@.service
MaxConnections=64
MaxConnectionsPerSource=8

[Install]
WantedBy=multi-user.target
EOF
cat > "$stage/sshd-ztna@.service" <<EOF
[Unit]
Description=Isolated ZTNA certificate SSH connection %I
CollectMode=inactive-or-failed

[Service]
ExecStartPre=$sshd_bin -t -f $config
ExecStart=$sshd_bin -i -e -f $config
StandardInput=socket
StandardOutput=socket
StandardError=journal
KillMode=control-group
TimeoutStopSec=3
EOF
# Validate staging paths, then validate installed paths before starting anything.
sed -e "s|$ca_path|$stage/ca.pub|" -e "s|$principals/|$stage/principals/|" "$stage/sshd_config" > "$stage/check_config"
"$sshd_bin" -t -f "$stage/check_config" || die 'sshd -t recusou a configuração preparada.'
created+=("$ca_path"); install -o root -g root -m 0644 "$stage/ca.pub" "$ca_path"
created+=("$principals"); install -d -o root -g root -m 0755 "$principals"
for account in "${accounts[@]}"; do install -o root -g root -m 0644 "$stage/principals/$account" "$principals/$account"; done
created+=("$config"); install -o root -g root -m 0600 "$stage/sshd_config" "$config"
created+=("$receipt"); install -o root -g root -m 0600 "$stage/receipt.json" "$receipt"
"$sshd_bin" -t -f "$config" || die 'sshd -t recusou os arquivos instalados.'
created+=("$socket_unit"); install -o root -g root -m 0644 "$stage/sshd-ztna.socket" "$socket_unit"
created+=("$service_unit"); install -o root -g root -m 0644 "$stage/sshd-ztna@.service" "$service_unit"
activated=1
systemctl daemon-reload
systemctl enable sshd-ztna.socket
systemctl start sshd-ztna.socket
systemctl is-active --quiet sshd-ztna.socket
systemctl is-enabled --quiet sshd-ztna.socket
committed=1
echo "Endpoint registrado. SSH por certificado disponível em $address:2222 para ${accounts[*]}."
echo "Central e ID do registro: $receipt. Porta 22 administrativa preservada."
