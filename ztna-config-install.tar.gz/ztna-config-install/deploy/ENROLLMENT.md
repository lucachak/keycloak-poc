# Enrollment de servidores

Esta versão mantém três acessos separados:

| Acesso | Porta | Autenticação |
| --- | --- | --- |
| SSH administrativo | 22 existente | Configuração administrativa existente |
| Painel do central | Loopback, por exemplo 8082 via túnel | Mesmo usuário admin e segredo do painel |
| Enrollment do central | IP privado:9443, ativação explícita | HTTPS com TLS 1.3 + token de uso único, 15 minutos |
| SSH do satélite | IP local:2222 | Certificado de usuário assinado pela CA |

O listener de enrollment vem **desativado**. Não há mudança automática de NSG,
firewall, TLS ou serviços na Azure. Os exemplos abaixo são o procedimento a revisar
antes da ativação em produção.

## 1. Preparar o central

O central precisa da CA SSH dedicada da Frente 1. A chave TLS do enrollment é
outra chave: não reutilize a CA SSH. Nenhuma chave real é gerada nesta etapa de
desenvolvimento.

O instalador do central agora exige o caminho da CA já provisionada:

```bash
sudo bash deploy/install-server.sh --ca-key /CAMINHO/CA_SSH_DEDICADA \
  IP_LOCAL USUARIO_LOCAL 2222 8082 server-first
```

Escolha `client-first` ou `server-first` conforme a configuração já validada nessa
máquina. O instalador guarda a CA em `/etc/pam-ztna-ca/user_ca`, acessível ao usuário
do serviço; recusa substituir uma CA diferente. `--check` continua disponível sem
CA de produção e não instala nada. O instalador do central preserva o fluxo local
anterior de aprovação e monitoramento; o script de satélite é separado.

Para habilitar HTTPS, use as flags:

```text
--enroll-listen 172.16.0.4:9443
--enroll-tls-cert /etc/pam-ztna-tls/enrollment.crt
--enroll-tls-key /etc/pam-ztna-tls/enrollment.key
```

O exemplo `pam-ztna-enrollment.conf.example` mostra um drop-in do systemd, sem
instalá-lo. Substitua o endereço, confira a porta local do painel e os demais
argumentos do serviço antes de usar. Certificado e chave TLS devem ser legíveis
pelo usuário `pam-ztna`, em diretório protegido fora de `/home` (o serviço usa
`ProtectHome=yes`). A chave TLS deve ter acesso restrito. O certificado deve ter
SAN correspondente ao DNS interno ou IP usado em `--central`, cadeia válida e
validade atual. Distribua a CA TLS confiável por um canal administrativo existente.

São aceitos somente binds explícitos RFC1918/IPv6 ULA em portas a partir de 1024.
Wildcard, DNS de bind e IP público são recusados. O painel continua em loopback;
o novo listener não expõe rotas administrativas, grants ou assinatura. Peers com
IP público também são recusados; `X-Forwarded-For` não altera essa decisão.

**Na Azure, bind privado não substitui a NSG:** um IP público pode ser traduzido
para a interface privada. Restrinja TCP/9443 às sub-redes privadas dos satélites;
não crie regra de entrada da Internet nem proxy público para esse listener.
Os satélites precisam alcançar esse IP por VNet, peering ou VPN. Um Arch fora
dessa rede não terá acesso direto ao enrollment por IP público.

Ativar o drop-in exige restart do central e pode encerrar conexões vinculadas ao
guard existente. Isso deve ser feito em uma janela acordada, após confirmar TLS,
IP e regras de rede. Nenhum restart é executado por estes exemplos de configuração.

## 2. Emitir um token como administrador

Confirme o `hostname` do satélite com `hostname`. No computador que já acessa o
painel pelo túnel, solicite um token; o curl pergunta a senha do admin sem colocá-la
na linha de comando:

```bash
umask 077
curl --fail --user admin \
  -H 'Content-Type: application/json' -H 'X-ZTNA-Admin: 1' \
  --data '{"hostname":"satellite-01"}' \
  --output enrollment-response.json \
  http://127.0.0.1:8082/api/enrollment/tokens
python3 - <<'PY'
import json
from pathlib import Path
response = json.loads(Path('enrollment-response.json').read_text())
Path('ztna-token').write_text(response['token'] + '\n')
Path('enrollment-response.json').unlink()
PY
```

`hostname` é opcional (`{}`), mas associá-lo evita cadastrar outro hostname por
engano. Ele é informado pelo satélite; não é uma atestação da identidade da VM.
O token expira em 15 minutos e é a autorização para o registro inicial.
Somente o hash do token é persistido em `endpoints.json`, ao lado de `grants.json`
por padrão. `--endpoints-data` permite um arquivo separado explícito.

Envie `ztna-token`, `enroll-endpoint.sh` e, se necessária, a CA **TLS pública** para
o satélite pelo SSH administrativo já confiável. Não envie a chave privada SSH
da CA ou a chave privada TLS. Não cole o token em comandos, logs ou tickets.

## 3. Executar uma vez no satélite

Pré-requisitos: OpenSSH server configurado com host key Ed25519, systemd ativo,
Bash, curl com TLS 1.3, Python 3, iproute2 e util-linux (`flock`). As contas locais
de acesso já devem existir. Este script não cria usuários nem instala pacotes.
Esta versão do script usa IPv4; a URL deve resolver somente para endereços RFC1918.

```bash
sudo bash enroll-endpoint.sh \
  --central https://172.16.0.4:9443 \
  --listen-ip IP_LOCAL_DO_SATELITE \
  --users lucas \
  --tls-ca ca-tls-publica.pem \
  --token-file ztna-token
```

Omita `--tls-ca` se a cadeia já é confiável no sistema. Sem `--token-file`, o
script solicita o token sem eco no terminal. Não existe opção para ignorar TLS.
`--users lucas,outro` habilita explicitamente essas contas; root é recusado.
O principal permitido para cada conta é somente seu próprio nome. Um certificado
de `lucas` não permite login como `deploy`. Mapeamentos diferentes por host não
fazem parte desta versão.

O script verifica as dependências e conflitos antes de consumir o token, fixa a
resolução de DNS da chamada HTTPS e envia hostname/IP. O central consome o token,
persiste o registro e devolve a chave pública da CA **na mesma resposta**. Não há
segundo download que precise reutilizar o token nem credencial permanente.

Arquivos instalados:

- `/etc/ssh/ztna_ca.pub`: somente a chave pública SSH da CA.
- `/etc/ssh/ztna_principals/USUARIO`: principal da respectiva conta, controlado por root.
- `/etc/ssh/sshd_config_ztna`: configuração exclusiva, com `TrustedUserCAKeys` e
  `AuthorizedPrincipalsFile /etc/ssh/ztna_principals/%u`.
- `/etc/ssh/ztna_endpoint.json`: central e ID do registro, sem token.
- `sshd-ztna.socket` e `sshd-ztna@.service`: listener 2222 e processo por conexão.

O `sshd_config` da porta 22 não é editado nem incluído. Instalações ZTNA já
existentes são recusadas para revisão, sem sobrescrever configurações. O script
valida o candidato e a configuração instalada com `sshd -t` antes de ativar o
socket. Não recarrega nem reinicia o SSH administrativo. O serviço por conexão
também valida sua configuração antes de iniciar o sshd.

Após sucesso, remova os arquivos temporários contendo o token dos dois lados.
Para a primeira aprovação do usuário, inicie o fluxo de login no central (listener
ZTNA existente) e aprove o pedido no painel. O operador baixa o certificado pelo
ID desse grant. O cliente usa sua chave privada e o certificado entregue pelo operador, conforme
`server/CERTIFICATES.md`. Não precisa de senha nem nova aprovação por satélite,
enquanto o certificado estiver válido e a conta/principal for permitida.

## 4. Conferir e diagnosticar

O painel mostra hostname, IP informado e data do registro, em páginas de 25.
`GET /api/endpoints?page=1&limit=25` usa a mesma autenticação administrativa.
Essa lista confirma o **registro no central**, não a conclusão da instalação ou
a disponibilidade atual: não há heartbeat nesta versão.

Se a resposta HTTPS se perder, o token pode já ter sido consumido. Se a instalação
falhar depois do registro, o registro permanece no central e os arquivos locais
criados pela tentativa são removidos. Se ocorrer falha de rollback do socket, o
script a informa para revisão manual. Não há rollback distribuído nem exclusão
de endpoints nesta versão.

Não reexecute às cegas. Leia o erro, confira a lista do painel, valide TLS/rede ou
`sshd -t -f /etc/ssh/sshd_config_ztna` quando esse arquivo existir e revise
`systemctl status sshd-ztna.socket`. Só emita outro token após diagnosticar a causa.

O satélite valida certificados localmente, sem consultar o central durante login.
Revogar no central não invalida um certificado já entregue e não encerra sessões
por certificado. O vencimento de até 8 horas impede **novos logins**, não derruba
conexões abertas. KRL, revogação de endpoint e monitoramento remoto ficam fora do
escopo acordado.

## Validação de desenvolvimento

```bash
cd server
go test -race ./...
go vet ./...
cd ..
bash -n deploy/enroll-endpoint.sh deploy/install-server.sh
python3 -B -m unittest discover -s deploy/tests -v
```

Os testes Python precisam de root e OpenSSH para validar configurações temporárias
com o `sshd -t` real. O central e systemd são simulados; um teste adicional usa
cliente SSH e `sshd -i` reais em loopback, com uma conta local de login existente.
Ele aceita o certificado correto e recusa principal incorreto e chave sem
certificado. Nenhum serviço instalado é alterado.
