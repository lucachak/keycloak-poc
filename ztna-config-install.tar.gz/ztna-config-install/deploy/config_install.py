#!/usr/bin/env python3
"""ZTNA installers driven by JSON. No shell sourcing or automatic retries."""
import argparse
import base64
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

BASE = Path(__file__).resolve().parent

class Error(Exception):
    pass

def run(args, data=None, interactive=False):
    r = subprocess.run(args, input=data, stdout=None if interactive else subprocess.PIPE,
                       stderr=None if interactive else subprocess.PIPE)
    if r.returncode:
        if r.stderr: sys.stderr.write(r.stderr.decode(errors='replace'))
        raise Error('Comando falhou. Nenhuma repetição automática; diagnostique antes de tentar novamente.')
    return r.stdout or b''

def name(v):
    if not isinstance(v,str) or not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}',v):
        raise Error('Nome/host inválido na configuração.')
    return v

def port(v):
    if type(v)!=int or not 1<=v<=65535: raise Error('Porta inválida.')
    return str(v)

def path(v):
    if not isinstance(v,str) or not v or any(ch in v for ch in '\r\n\x00%"'):
        raise Error('Caminho inválido.')
    return Path(v).expanduser().absolute()

def file(v):
    p=path(v)
    if not p.is_file(): raise Error('Arquivo necessário ausente: '+str(p))
    return p

def load(v):
    p=path(v)
    c=json.loads(p.read_text())
    if not isinstance(c,dict) or c.get('role') not in ('central','endpoint','client'):
        raise Error('Informe role: central, endpoint ou client.')
    def visit(obj):
        if isinstance(obj,dict):
            for k,v in obj.items():
                if k.endswith('_file') and isinstance(v,str):
                    f=Path(v).expanduser()
                    obj[k]=str(f if f.is_absolute() else p.parent/f)
                else: visit(v)
        elif isinstance(obj,list):
            for v in obj: visit(v)
    visit(c)
    return c

def write(p,data,mode=0o600):
    p=Path(p)
    p.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    if p.is_symlink(): raise Error('Destino é link simbólico; revise: '+str(p))
    fd,tmp=tempfile.mkstemp(prefix='.ztna-',dir=p.parent)
    try:
        os.fchmod(fd,mode)
        with os.fdopen(fd,'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,p)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)

def ssh_options(h):
    name(h['host']); name(h['user'])
    return ['ssh','-F','/dev/null','-T','-p',port(h.get('port',22)),
            '-i',str(file(h['identity_file'])),'-o','BatchMode=yes',
            '-o','IdentitiesOnly=yes','-o','StrictHostKeyChecking=yes',
            '-o','ForwardAgent=no','-o','ConnectTimeout=10',
            '-o','ServerAliveInterval=15','-o','ServerAliveCountMax=2',
            '-o','UserKnownHostsFile='+str(file(h['known_hosts_file']))]

def remote(h,args,data=None):
    return run(ssh_options(h)+[h['user']+'@'+h['host'],shlex.join(args)],data)

# Runs over authenticated SSH on the central, using its existing admin middleware.
# The admin credential stays on the central. Responses are captured, never logged.
CENTRAL_HELPER = r'''
import base64,json,sys,urllib.request
from pathlib import Path
try:
    r=json.load(sys.stdin)
    if r['op']=='tls':
        data=Path(r['tls_cert_path']).read_text()
        if 'PRIVATE KEY' in data or 'BEGIN CERTIFICATE' not in data: raise ValueError()
        sys.stdout.write(data)
    else:
        secrets=[l.split('=',1)[1] for l in Path('/etc/pam-ztna/admin.env').read_text().splitlines() if l.startswith('ZTNA_ADMIN_TOKEN=')]
        if len(secrets)!=1 or len(secrets[0])<32: raise ValueError()
        auth=base64.b64encode(('admin:'+secrets[0]).encode()).decode()
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        def api(route,body=None):
            headers={'Authorization':'Basic '+auth}
            if body is not None:
                headers.update({'Content-Type':'application/json','X-ZTNA-Admin':'1'})
                body=json.dumps(body).encode()
            req=urllib.request.Request('http://127.0.0.1:'+str(int(r['panel_port']))+route,data=body,headers=headers)
            with opener.open(req,timeout=15) as response: return response.read()
        if r['op']=='token':
            sys.stdout.buffer.write(api('/api/enrollment/tokens',{'hostname':r['hostname']}))
        elif r['op']=='certificate':
            rows=json.loads(api('/api/grants'))
            rows=[g for g in rows if g['user']==r['user'] and g['fingerprint']==r['fingerprint'] and g['state']=='approved']
            if len(rows)!=1: raise ValueError()
            from urllib.parse import quote
            sys.stdout.buffer.write(api('/api/certificate?id='+quote(rows[0]['id'],safe='')))
        else: raise ValueError()
except Exception:
    sys.exit('Central recusou a operação. Confira a aprovação e o serviço; nenhum segredo exibido.')
'''

def central_call(c,op,**kw):
    data=json.dumps(dict(op=op,panel_port=int(port(c.get('panel_port',8082))),**kw)).encode()
    return remote(c['ssh'],['sudo','-n','python3','-c',CENTRAL_HELPER],data)

UPLOAD = r'''
import base64,json,os,sys,tempfile
from pathlib import Path
r=json.load(sys.stdin)
p=Path(r['directory']) if r.get('directory') else Path(tempfile.mkdtemp(prefix='ztna-bootstrap-'))
if not p.name.startswith('ztna-bootstrap-') or p.parent!=Path('/tmp') or p.is_symlink() or p.stat().st_uid!=os.getuid():
    sys.exit('Diretório remoto inválido.')
for name,data in r['files'].items():
    if name not in ('enroll.sh','tls.crt','token'): sys.exit('Nome de arquivo inválido.')
    fd=os.open(p/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f: f.write(base64.b64decode(data,validate=True))
print(p)
'''

def upload(h,files,directory=None):
    data=json.dumps({'directory':directory,'files':{k:base64.b64encode(v).decode() for k,v in files.items()}}).encode()
    result=remote(h,['python3','-c',UPLOAD],data).decode().strip()
    if not re.fullmatch(r'/tmp/ztna-bootstrap-[A-Za-z0-9_-]+',result): raise Error('Diretório remoto inesperado.')
    return result

def endpoint(c,check):
    central,target=c['central'],c['target']
    ssh_options(central['ssh']); ssh_options(target['ssh'])
    expected=name(target['hostname']).lower()
    address=str(ipaddress.IPv4Address(target['listen_ip']))
    users=target['users']
    if not isinstance(users,list) or not users or any(not re.fullmatch(r'[a-z_][a-z0-9_-]*',u) or u=='root' for u in users):
        raise Error('Informe contas locais não-root em users.')
    if check:
        print('Configuração local válida. Nenhum acesso remoto nem token emitido.')
        return
    if remote(target['ssh'],['hostname']).decode().strip().lower()!=expected:
        raise Error('Hostname remoto diferente do configurado; nenhum token emitido.')
    public=central_call(central,'tls',tls_cert_path=central.get('tls_cert_path','/etc/pam-ztna-tls/enrollment.crt'))
    stage=None; issued=False
    try:
        stage=upload(target['ssh'],{'enroll.sh':(BASE/'enroll-endpoint.sh').read_bytes(),'tls.crt':public})
        args=['sudo','-n','bash',stage+'/enroll.sh','--central',central['enrollment_url'],
              '--listen-ip',address,'--users',','.join(users),'--tls-ca',stage+'/tls.crt']
        print('Validando o satélite antes de emitir token...',flush=True)
        print(remote(target['ssh'],args+['--check']).decode(),end='')
        result=json.loads(central_call(central,'token',hostname=expected)); issued=True
        secret=result['token']
        if not re.fullmatch(r'[A-Za-z0-9_-]{43}',secret): raise Error('Resposta de token inválida.')
        upload(target['ssh'],{'token':(secret+'\n').encode()},stage)
        print('Executando enrollment uma única vez...',flush=True)
        print(remote(target['ssh'],args+['--token-file',stage+'/token']).decode(),end='')
    except Exception:
        if issued: print('Token emitido e possivelmente consumido. Confira o painel antes de tentar novamente.',file=sys.stderr)
        raise
    finally:
        if stage:
            try: remote(target['ssh'],['python3','-c','import shutil,sys; shutil.rmtree(sys.argv[1])',stage])
            except Error: print('Limpe manualmente os arquivos temporários no satélite: '+stage,file=sys.stderr)

def fp(p):
    output=run(['ssh-keygen','-lf',str(p)]).decode().split()
    if len(output)<2: raise Error('Chave inválida.')
    return output[1]

def scan_check(data,expected):
    lines=[line for line in data.splitlines() if line and not line.startswith(b'#')]
    if not lines: raise Error('Nenhuma host key recebida.')
    for line in lines:
        parts=line.split()
        if len(parts)!=3 or parts[1]!=b'ssh-ed25519': raise Error('Host key inesperada.')
        wire=base64.b64decode(parts[2],validate=True)
        actual='SHA256:'+base64.b64encode(hashlib.sha256(wire).digest()).decode().rstrip('=')
        if actual!=expected: raise Error('Fingerprint de host não confere; nenhuma chave será aceita.')
    return b'\n'.join(lines)+b'\n'

def cert_check(c,data):
    fields=data.split()
    if len(fields)<2 or fields[0]!=b'ssh-ed25519-cert-v01@openssh.com': raise Error('Certificado Ed25519 inválido.')
    wire=base64.b64decode(fields[1],validate=True); pos=0
    def take(n):
        nonlocal pos
        if n>len(wire)-pos: raise Error('Certificado truncado.')
        out=wire[pos:pos+n]; pos+=n; return out
    def number(n): return int.from_bytes(take(n),'big')
    def string(): return take(number(4))
    string(); string(); public=string(); number(8)
    if number(4)!=1: raise Error('Certificado de host recusado.')
    string(); principals=string(); wanted=c['user'].encode()
    if principals!=len(wanted).to_bytes(4,'big')+wanted: raise Error('Principal diferente do usuário configurado.')
    after,before=number(8),number(8)
    if not after<=time.time()<before: raise Error('Certificado vencido ou ainda não válido. Solicite renovação ao operador.')
    string(); string(); string(); ca=string()
    def digest(b): return 'SHA256:'+base64.b64encode(hashlib.sha256(b).digest()).decode().rstrip('=')
    if digest(ca)!=c['ca_fingerprint']: raise Error('CA diferente da configurada.')
    raw=b'\0\0\0\x0bssh-ed25519'+len(public).to_bytes(4,'big')+public
    if digest(raw)!=fp(str(path(c['identity_file']))+'.pub'): raise Error('Certificado pertence a outro dispositivo.')
    return data

def quote(v):
    v=str(v)
    if any(ch in v for ch in '\n\r\x00%"'): raise Error('Valor inválido na configuração SSH.')
    return '"'+v+'"'

def profile_dir(c): return Path.home()/'.config/ztna'/name(c['name'])

def render_client(c):
    name(c['user']); name(c['name'])
    if c.get('key_mode','agent') not in ('agent','unprotected'): raise Error('key_mode inválido.')
    if not re.fullmatch(r'SHA256:[A-Za-z0-9+/]{43}',c['ca_fingerprint']): raise Error('Fingerprint da CA inválida.')
    targets=([dict(c['jump'],name='ztna-jump')] if c.get('jump') else [])
    targets += [dict(c['authority'],name='ztna-approval')]+c['servers']
    lines=['# Managed by ztna-config-client']; seen=set()
    for t in targets:
        alias=name(t['name']); name(t['host'])
        if alias in seen: raise Error('Alias duplicado.')
        seen.add(alias)
        if not re.fullmatch(r'SHA256:[A-Za-z0-9+/]{43}',t['host_fingerprint']): raise Error('Fingerprint de host inválida.')
        jump=alias=='ztna-jump'
        key=file(t['identity_file']) if jump else path(c['identity_file'])
        lines += ['Host '+alias,'  HostName '+t['host'],'  User '+name(t['user'] if jump else c['user']),
                  '  Port '+port(t.get('port',22 if jump else 2222)),'  IdentityFile '+quote(key)]
        if t.get('via_jump'):
            if not c.get('jump') or jump: raise Error('ProxyJump inválido.')
            lines += ['  ProxyJump ztna-jump']
        if alias=='ztna-approval': lines += ['  PubkeyAcceptedAlgorithms ssh-ed25519']
        elif not jump:
            lines += ['  CertificateFile '+quote(str(key)+'-cert.pub'),
                      '  PubkeyAcceptedAlgorithms ssh-ed25519-cert-v01@openssh.com']
    lines += ['Host *','  IdentitiesOnly yes','  BatchMode yes','  PasswordAuthentication no',
              '  KbdInteractiveAuthentication no','  StrictHostKeyChecking yes',
              '  UserKnownHostsFile '+quote(profile_dir(c)/'known_hosts'),
              '  ForwardAgent no','  ControlMaster no','  ControlPath none']
    return '\n'.join(lines)+'\n',targets

def install_client(c,check):
    if os.geteuid()==0: raise Error('Instale o cliente como usuário normal, sem sudo.')
    config,targets=render_client(c)
    if check:
        print('Configuração válida; nenhuma chave criada nem acesso de rede realizado.')
        return
    key=path(c['identity_file']); root=profile_dir(c)
    launcher=Path.home()/'.local/bin'/('ztna-'+c['name'])
    if launcher.exists() and '# Managed by ztna-config-client' not in launcher.read_text():
        raise Error('Launcher existente não gerenciado; nada será sobrescrito.')
    if root.exists() and not (root/'managed').is_file(): raise Error('Perfil existente não gerenciado; revise.')
    if not key.exists():
        if Path(str(key)+'.pub').exists(): raise Error('Chave pública sem privada; revise antes de gerar outra.')
        key.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        args=['ssh-keygen','-t','ed25519','-f',str(key),'-C','ztna-'+c['name']]
        if c.get('key_mode','agent')=='unprotected': args += ['-N','']
        run(args,interactive=True)
    if '(ED25519)' not in run(['ssh-keygen','-lf',str(key)+'.pub']).decode(): raise Error('Use uma chave Ed25519 dedicada.')
    known=[]
    with tempfile.TemporaryDirectory(prefix='ztna-client-') as stage:
        stage=Path(stage)
        temporary=config.replace(quote(root/'known_hosts'),quote(stage/'known_hosts'))
        write(stage/'ssh_config',temporary.encode())
        for t in targets:
            scan=['ssh-keyscan','-T','5','-t','ed25519','-p',port(t.get('port',22 if t['name']=='ztna-jump' else 2222)),t['host']]
            if t.get('via_jump'):
                output=run(['ssh','-F',str(stage/'ssh_config'),'ztna-jump',shlex.join(scan)])
            else: output=run(scan)
            known.append(scan_check(output,t['host_fingerprint']))
            write(stage/'known_hosts',b'\n'.join(known))
    certificate=cert_check(c,file(c['certificate_file']).read_bytes()) if c.get('certificate_file') else None
    write(root/'managed',b'ztna-config-client\n')
    write(root/'ssh_config',config.encode())
    write(root/'known_hosts',b'\n'.join(known))
    local={k:v for k,v in c.items() if k not in ('operator','certificate_file')}
    write(root/'client.json',json.dumps(local,indent=2).encode())
    write(root/'config_install.py',Path(__file__).read_bytes(),0o700)
    command='exec python3 '+shlex.quote(str(root/'config_install.py'))+' '+shlex.quote(str(root/'client.json'))+' "$@"\n'
    write(launcher,('#!/bin/sh\n# Managed by ztna-config-client\n'+command).encode(),0o700)
    if certificate is not None: write(str(key)+'-cert.pub',certificate)
    print('Cliente instalado: '+str(launcher))
    print('Fingerprint pública do dispositivo: '+fp(str(key)+'.pub'))
    print('Solicite aprovação com: '+str(launcher)+' request')

def client_action(c,action,value):
    root=profile_dir(c); key=path(c['identity_file'])
    if action=='import':
        write(str(key)+'-cert.pub',cert_check(c,file(value).read_bytes()))
        print('Certificado instalado.'); return
    if action=='export':
        data=central_call(c['operator'],'certificate',user=c['user'],fingerprint=fp(str(key)+'.pub'))
        write(path(value),cert_check(c,data)); print('Certificado exportado sem exibir conteúdo.'); return
    if action=='unlock':
        run(['ssh-add',str(key)],interactive=True); return
    if c.get('key_mode','agent')=='agent':
        loaded=run(['ssh-add','-l']).decode()
        if fp(str(key)+'.pub') not in loaded: raise Error('Chave não carregada no agente. Execute unlock na sessão do ssh-agent.')
    if action=='connect':
        if value not in [s['name'] for s in c['servers']]: raise Error('Servidor não cadastrado no perfil.')
        cert_check(c,file(str(key)+'-cert.pub').read_bytes()); alias=value
    elif action=='request': alias='ztna-approval'
    else: raise Error('Ação inválida.')
    args=['ssh','-F',str(root/'ssh_config'),alias]
    if action=='request':
        print('Aguardando aprovação da chave no painel...',flush=True); args += ['true']
    run(args,interactive=True)

def central(c,check):
    ca=file(c['ca_key_file']); ip=str(ipaddress.IPv4Address(c['listen_ip']))
    order=c.get('address_order','server-first')
    if order not in ('server-first','client-first'): raise Error('address_order inválido.')
    args=['bash',str(BASE/'install-server.sh'),'--ca-key',str(ca),ip,name(c['user']),
          port(c.get('ssh_port',2222)),port(c.get('panel_port',8082)),order]
    tls=c.get('enrollment')
    if tls:
        import ssl
        host=str(ipaddress.IPv4Address(tls['listen_ip']))
        if not any(ipaddress.ip_address(host) in ipaddress.ip_network(n) for n in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16')):
            raise Error('O listener de enrollment exige IP RFC1918.')
        tls_port=port(tls.get('port',9443))
        if int(tls_port)<1024: raise Error('Porta de enrollment deve ser >=1024.')
        cert,key=file(tls['certificate_file']),file(tls['key_file'])
        if os.path.samefile(ca,key) or os.path.samefile(ca,cert): raise Error('TLS e CA SSH precisam de arquivos separados.')
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(cert),str(key))
        run(['openssl','x509','-in',str(cert),'-noout','-checkend','0'])
        match=run(['openssl','x509','-in',str(cert),'-noout','-checkip',host]).decode()
        if 'does match certificate' not in match:
            raise Error('O certificado TLS não corresponde ao IP de enrollment.')
    if check: args += ['--check']
    run(args,interactive=True)
    if tls and not check:
        for f in (cert,key): run(['runuser','-u','pam-ztna','--','test','-r',str(f)])
        command=['/usr/local/libexec/pam-ztna-server','--socket','/run/pam-ztna/auth.sock',
                 '--data','/var/lib/pam-ztna/grants.json','--port',port(c.get('panel_port',8082)),
                 '--ca-key','/etc/pam-ztna-ca/user_ca','--enroll-listen',host+':'+tls_port,
                 '--enroll-tls-cert',str(cert),'--enroll-tls-key',str(key)]
        # JSON cannot inject systemd directives/specifiers through these arguments.
        for value in command:
            if any(ch in value for ch in '\n\r%\x00'): raise Error('Argumento de serviço inválido.')
        dropin=Path('/etc/systemd/system/pam-ztna.service.d/enrollment.conf')
        previous=dropin.read_bytes() if dropin.exists() else None
        if previous is not None:
            fd,backup=tempfile.mkstemp(prefix='enrollment-backup-',suffix='.txt',dir=dropin.parent)
            with os.fdopen(fd,'wb') as f: f.write(previous)
        content=('[Service]\nExecStart=\nExecStart='+shlex.join(command)+'\n').encode()
        write(dropin,content,0o644)
        try:
            run(['sshd','-t','-f','/etc/pam-ztna/sshd_config'])
            run(['systemctl','daemon-reload'])
            run(['systemctl','restart','pam-ztna.service'])
            run(['systemctl','start','ztna-session-guard.service','sshd-ztna.socket'])
            run(['systemctl','is-active','--quiet','pam-ztna.service'])
        except Error:
            if previous is None: dropin.unlink()
            else: write(dropin,previous,0o644)
            run(['systemctl','daemon-reload'])
            print('Drop-in restaurado. Diagnostique os serviços antes de reiniciar; nenhuma nova tentativa automática.',file=sys.stderr)
            raise

def main():
    p=argparse.ArgumentParser(description='ZTNA por JSON; sem repetição automática em caso de falha.')
    p.add_argument('config'); p.add_argument('action',nargs='?',default='install',choices=['install','request','connect','unlock','import','export'])
    p.add_argument('value',nargs='?'); p.add_argument('--check',action='store_true')
    a=p.parse_args()
    try:
        os.umask(0o077); c=load(a.config)
        if a.action!='install':
            if c['role']!='client' or a.check: raise Error('Ação exige perfil de cliente.')
            client_action(c,a.action,a.value)
        elif c['role']=='client': install_client(c,a.check)
        elif c['role']=='endpoint': endpoint(c,a.check)
        else: central(c,a.check)
    except (Error,KeyError,ValueError,OSError,TypeError):
        exc=sys.exc_info()[1]
        print(str(exc) if isinstance(exc,Error) else 'Configuração/arquivo inválido ou incompleto. Revise campos e permissões; nenhum segredo exibido.',file=sys.stderr)
        return 1
    return 0

if __name__=='__main__': sys.exit(main())
