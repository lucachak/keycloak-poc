# Instalação por configuração

Requer Bash, Python 3 e OpenSSH no computador que executa a automação. Os arquivos
JSON contêm endereços e caminhos, nunca senhas, tokens ou conteúdo de chaves.
Caminhos relativos são resolvidos em relação ao JSON; `~` corresponde ao usuário
que executa o comando. Não use `sudo` no computador do operador ou no cliente.

## Novo servidor satélite — um comando no computador do operador

Copie `config/endpoint.example.json` para `endpoint.json` e ajuste os IPs, o
hostname esperado e os caminhos das chaves administrativas `.pem`. O servidor
precisa ser novo para ZTNA, com contas existentes e OpenSSH/systemd configurados.
Não rode sobre a `sso` já cadastrada: o script recusa instalações existentes.

```bash
bash deploy/install-config.sh endpoint.json --check
bash deploy/install-config.sh endpoint.json
```

O primeiro comando apenas valida configuração e arquivos locais. O segundo:

1. Conecta ao central e ao destino pelo SSH administrativo, com host keys já
   confiáveis no `known_hosts` indicado. Nunca aceita uma host key desconhecida.
2. Busca somente o certificado TLS público pelo canal SSH confiável.
3. Transfere os arquivos e verifica dependências, contas, IP, conflitos e TLS.
4. Solicita um token de 15 minutos, usando a API administrativa pelo loopback do
   central. O segredo de `admin.env` não sai do central.
5. Envia o token ao destino e executa o enrollment uma vez. Limpa os temporários.

O operador precisa de acesso administrativo já autorizado por chave no central
e no destino, e `sudo -n` para essas operações. Não adicionamos regras NOPASSWD.
O SSH usa `BatchMode=yes`: falha claramente se a chave não funcionar ou exigir
desbloqueio, em vez de solicitar senhas. Para chaves administrativas protegidas,
carregue-as no seu `ssh-agent` antes. Nenhuma chave privada é copiada para o destino.

O destino deve alcançar a URL HTTPS privada indicada e sua origem deve estar
permitida na NSG/firewall. O instalador não cria VNet, peering, VPN, regras Azure
ou contas Unix. A porta ZTNA permanece 2222; SSH administrativo permanece separado.

Se falhar depois da emissão, o token pode já estar consumido. Confira o erro e o
registro no painel; nunca há repetição automática de instalação ou emissão.

## Cliente novo — chave própria, sem senha de login

Copie `config/client.example.json` para `client.json`. Ajuste usuário, destinos,
caminho da chave local e fingerprints conferidas pelo operador. Os valores de CA
e hosts nos exemplos correspondem à PoC atual; confirme antes de usá-los em outro
ambiente. A fingerprint da porta administrativa 22 pode diferir da porta 2222.

O exemplo `client.example.json` exige conectividade direta com os destinos. Para
o Arch fora da VNet, use `client-arch.example.json`, que demonstra ProxyJump pelo
acesso administrativo que **você já possui**. Não distribua a chave administrativa
do central a outros funcionários: eles precisam de rede privada acessível ou de
um acesso próprio e limitado ao bastion/jump host. Configurar esse acesso é uma
decisão de infraestrutura separada do certificado ZTNA.

```bash
bash deploy/install-config.sh client.json --check
bash deploy/install-config.sh client.json
```

O instalador cria uma chave Ed25519 apenas se ela não existir, verifica as host
keys pelas fingerprints (inclusive as recebidas por `ssh-keyscan`) e cria:

- `~/.config/ztna/trabalho/`: perfil, known_hosts privado e configuração SSH.
- `~/.local/bin/ztna-trabalho`: comando do cliente (nome definido em `name`).

Seu `~/.ssh/config` não é sobrescrito. O perfil instalado exclui a configuração
`operator`; nenhum segredo do painel é colocado nos clientes.

### Escolher como proteger a chave local

- `"key_mode": "agent"` é o padrão. A geração solicita passphrase; na sessão do
  seu agente, execute `~/.local/bin/ztna-trabalho unlock` uma vez. Depois,
  solicitações e conexões usam `BatchMode=yes`, sem pedir senhas. Se não houver
  agente de sessão, você pode iniciar um com `eval "$(ssh-agent -s)"`.
- `"key_mode": "unprotected"` gera uma chave **nova** sem passphrase. Não exige
  digitação nem agente para essa chave. Quem obtiver o arquivo privado poderá
  usá-lo com um certificado válido. Guarde-o com permissões restritas e disco
  protegido. Essa opção não remove passphrase de uma chave existente.

Cada dispositivo deve gerar a própria chave. Não copie a chave privada do Arch
para novos clientes, nem a chave administrativa ou a chave da CA.

### Primeira aprovação e certificado

No cliente:

```bash
~/.local/bin/ztna-trabalho request
```

O operador aprova a fingerprint no painel. Esse comando solicita aprovação pelo
listener legado do central; não exige senha Unix. Após aprovação, termina sem
abrir uma shell. Não baixa certificados nem recebe privilégios administrativos.

Para buscar o certificado sem copiar ID, senha ou token, o operador copia **somente
a chave pública** do cliente para seu computador, por exemplo `public-keys/novo-pc.pub`,
preenche `config/operator.example.json` e executa:

```bash
bash deploy/install-config.sh operator.json export novo-pc-cert.pub
```

`identity_file` nesse perfil aponta para `public-keys/novo-pc` (sem `.pub`). O export
precisa somente do arquivo `.pub`, nunca da chave privada do cliente. Ele procura
o grant pela fingerprint e pelo usuário, usa o middleware existente do central e
salva o certificado sem exibi-lo. A aprovação manual não é contornada.

O operador entrega o arquivo público ao cliente por um canal confiável. No cliente:

```bash
~/.local/bin/ztna-trabalho import ~/Downloads/novo-pc-cert.pub
~/.local/bin/ztna-trabalho connect sso
```

O import confere chave, principal, fingerprint da CA e período de validade antes
de substituir o certificado. O sshd verifica a assinatura durante o login.
O ProxyJump, quando configurado, elimina os comandos manuais de túnel por servidor.

Há dois comandos do operador/cliente para entrega: **esta versão não oferece
download de certificado pelo cliente comum diretamente do central**. Isso evita
distribuir o segredo do admin ou criar uma nova autenticação sem revisão.

Para renovar, o operador renova o grant no painel, exporta e entrega o novo
certificado. O TTL máximo permanece 8 horas. Nenhum script torna certificados
permanentes, invalida certificados entregues ou encerra sessões dos satélites ao
revogar no central.

## Instalação do central

Esse perfil é executado **localmente no servidor central**, como root:

```bash
sudo bash deploy/install-config.sh central.json --check
sudo bash deploy/install-config.sh central.json
```

Use `config/central.example.json`. Provisione previamente a CA SSH dedicada e,
se habilitar `enrollment`, o par TLS separado com SAN do IP privado e permissões
que permitam leitura por `pam-ztna`. O perfil não gera/rotaciona CA real nem muda
NSG. O par TLS é validado antes da instalação e o drop-in é escrito sem quebras
manuais de caminhos. Sem `enrollment`, o wrapper não modifica o drop-in TLS existente.
As contas e dependências do instalador original continuam necessárias.

A instalação executa os testes Go, valida sshd antes de reiniciar, instala os
serviços e pode encerrar conexões ZTNA existentes. Preserve seu SSH administrativo.
Falhas não provocam nova tentativa automática; se a ativação TLS falhar, o drop-in
anterior é restaurado em disco e o estado dos serviços exige diagnóstico.

## Verificação de desenvolvimento

```bash
python3 -B -m unittest discover -s deploy/tests -v
bash -n deploy/install-config.sh deploy/enroll-endpoint.sh
cd server
go test -race ./...
go vet ./...
```

Os testes de instalação usam diretórios isolados e systemd/rede simulados; o
teste SSH existente usa apenas loopback. Não executamos esses instaladores na
Azure durante o desenvolvimento.
