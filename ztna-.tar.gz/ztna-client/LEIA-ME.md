# Cliente SSH

Dependências: Bash, OpenSSH e util-linux. No Kali: sudo apt install openssh-client util-linux. No Arch: sudo pacman -S openssh util-linux.

Execute sem sudo: bash install-client.sh ENDERECO_DO_SERVIDOR USUARIO 2222
Conecte: ~/.local/bin/ztna-connect

O instalador preserva a chave existente. O wrapper desbloqueia a chave no ssh-agent antes de conectar; não armazena a passphrase. Confira a fingerprint do host e aprove a chave no painel do servidor.
