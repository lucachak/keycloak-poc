Para o passo a passo completo, consulte o [manual de uso](MANUAL.md).

## Painel de autorizações

A interface inclui busca por dispositivo, usuário, IP e fingerprint, filtros
por estado, ordenação e páginas de 25/50/100 identidades. Os detalhes permitem
aprovar, negar, renovar a validade e revogar com confirmação. A sincronização
preserva campos em edição, suspende decisões quando offline e reduz consultas
em abas ocultas ou durante falhas. A interface não depende de CDN ou fontes externas.

Os indicadores contam autorizações, não sessões SSH abertas. O backend atual
mantém o limite de 1024 identidades. Busca, filtros, ordenação e paginação
agora são executados no servidor; o painel recebe até 100 registros por página
e, se necessário, a identidade aberta nos detalhes. Os contadores representam
toda a base, independentemente do filtro. Buscas substituídas são canceladas
e respostas antigas não sobrescrevem a consulta atual. Escala além desse limite
ainda exige revisão da persistência, índices, limites e auditoria própria. O painel não oferece
histórico completo de decisões. O listener instalado agora encerra conexões
vinculadas a autorizações revogadas ou expiradas.

O HTML é incorporado ao binário Go. Para atualizar uma instalação, extraia o
novo pacote e execute novamente o instalador com os mesmos IP, usuário e portas.
Isso recompila o painel e reinicia os serviços. Na VM Azure deste exemplo:

```bash
sudo bash deploy/install-server.sh 172.16.0.4 azureuser 2222 8082 client-first
```

Validação de UI opcional: instale Selenium, Chromium e chromedriver e
execute `python3 server/tests/ui_smoke.py`. O teste usa
registros sintéticos e intercepta a API, sem alterar autorizações reais.

### API paginada

`GET /api/grants/page?page=1&limit=25&state=pending&sort=priority&q=arch`
retorna `items`, `total` (filtrado), `page`, `pages`, `limit`, `counts`
(globais) e `selected`. A consulta opcional `selected=ID` mantém o detalhe
visível mesmo quando a identidade sai do filtro ou da página. A lista é
ordenada com desempate por ID; páginas além do fim são ajustadas para a última.
Os filtros aceitos são `all`, `pending`, `approved`, `inactive`, `revoked`,
`expired` e `denied`; as ordenações são `priority`, `recent`, `name` e `expiry`.
Todas as consultas exigem a mesma autenticação administrativa do painel.

`GET /api/grants` continua retornando a lista completa por compatibilidade
com clientes anteriores; o painel novo utiliza exclusivamente a API paginada.
O armazenamento continua em memória com persistência JSON; as consultas ainda
percorrem um snapshot da base. A mudança limita transferência e renderização,
não transforma esta PoC em um serviço distribuído.


## Revogação de conexões abertas

Atualize pelo instalador completo. O SSH gerenciado agora usa `sshd-ztna.socket`
e uma unidade `sshd-ztna@.service` por conexão. `ztna-session-guard.service`
monitora os identificadores de aprovação pelo socket privado e encerra somente
as unidades vinculadas a identificadores que deixaram de estar ativos.
Uma conexão fica vinculada à primeira chave aprovada que apresentar; para
usar outra chave, abra outro transporte SSH.

O monitor autentica o helper por credenciais Unix e pelo executável instalado;
a unidade vem do cgroup real do processo, não de um PID fornecido pelo cliente.
O serviço guarda também a InvocationID da unidade. Falha do monitor encerra
as conexões por dependência BindsTo; falha da autoridade fecha os transportes
rastreados. A revogação é aplicada após a persistência da decisão, com consulta
periódica de um segundo e parada da unidade de até três segundos em condições normais.

Validação opcional em uma máquina Linux/systemd de teste, com as contas `kali`
e `pam-ztna` existentes: `sudo python3 server/tests/revocation_live.py`.
Esse teste usa serviços temporários, chaves descartáveis e listeners loopback.
