#!/usr/bin/env bash
set -euo pipefail
umask 077
host=${1:-192.168.15.170}
user=${2:-kali}
port=${3:-2222}
[[ $host =~ ^[a-zA-Z0-9][a-zA-Z0-9.:-]*$ && $user =~ ^[a-z_][a-z0-9_-]*$ && $port =~ ^[0-9]{1,5}$ ]] || { echo 'Uso: bash install-client.sh HOST USUARIO PORTA' >&2; exit 1; }
(( 10#$port >= 1 && 10#$port <= 65535 )) || exit 1
[[ $EUID != 0 ]] || { echo 'Execute como seu usuário normal, sem sudo.' >&2; exit 1; }
for cmd in ssh ssh-keygen ssh-agent ssh-add flock; do
    command -v "$cmd" >/dev/null || { echo 'Instale OpenSSH: Kali: sudo apt install openssh-client; Arch: sudo pacman -S openssh' >&2; exit 1; }
done
mkdir -p "$HOME/.ssh" "$HOME/.local/bin"
chmod 700 "$HOME/.ssh"
key="$HOME/.ssh/id_ed25519_ztna"
if [[ ! -e $key ]]; then
    [[ ! -e $key.pub ]] || { echo 'Já existe uma chave pública sem a privada; revise antes de continuar.' >&2; exit 1; }
    echo 'Escolha uma passphrase para proteger a chave deste dispositivo.'
    ssh-keygen -t ed25519 -f "$key" -C "ztna-$(hostname)"
fi
[[ $(ssh-keygen -lf "$key.pub") == *'(ED25519)' ]] || { echo 'A chave existente precisa ser Ed25519.' >&2; exit 1; }
config="$HOME/.ssh/ztna_config"
if [[ -e $config ]] && ! head -n 1 "$config" | grep -qx '# Managed by ztna-client'; then
    echo "Arquivo já existente: $config; instalação interrompida." >&2; exit 1
fi
cat > "$config" <<EOF
# Managed by ztna-client
Host ztna-vm
    HostName $host
    User $user
    Port $port
    IdentityFile ~/.ssh/id_ed25519_ztna
    IdentitiesOnly yes
    ControlMaster no
    ControlPath none
    StrictHostKeyChecking ask
    ForwardAgent no
EOF
launcher="$HOME/.local/bin/ztna-connect"
if [[ -e $launcher ]] && ! grep -qx '# Managed by ztna-client' "$launcher"; then
    echo "Arquivo já existente: $launcher; instalação interrompida." >&2; exit 1
fi
cat > "$launcher" <<'EOF'
#!/usr/bin/env bash
# Managed by ztna-client
set -euo pipefail
umask 077
# Prefer the desktop/session agent. Otherwise reuse a private, fixed socket.
agent_status=0
ssh-add -l >/dev/null 2>&1 || agent_status=$?
if (( agent_status == 2 )); then
    agent_dir="$HOME/.ssh/ztna-agent"
    mkdir -p "$agent_dir"
    chmod 700 "$agent_dir"
    export SSH_AUTH_SOCK="$agent_dir/socket"
    exec 9>"$agent_dir/lock"
    flock 9
    agent_status=0
    ssh-add -l >/dev/null 2>&1 || agent_status=$?
    if (( agent_status == 2 )); then
        rm -f -- "$SSH_AUTH_SOCK"
        ssh-agent -a "$SSH_AUTH_SOCK" >/dev/null
    fi
    flock -u 9
    exec 9>&-
fi
fingerprint=$(ssh-keygen -lf "$HOME/.ssh/id_ed25519_ztna.pub" | awk '{print $2}')
loaded=$(ssh-add -l 2>/dev/null || true)
if ! awk -v fp="$fingerprint" '$2 == fp {found=1} END {exit !found}' <<< "$loaded"; then
    echo 'Desbloqueie a chave deste dispositivo (passphrase local, não a senha da VM).'
    ssh-add "$HOME/.ssh/id_ed25519_ztna"
fi
exec ssh -F "$HOME/.ssh/ztna_config" ztna-vm "$@"
EOF
chmod 600 "$config"
chmod 700 "$launcher"
ssh-keygen -lf "$key.pub"
echo 'Instalado. Conecte com: ~/.local/bin/ztna-connect'
echo 'O wrapper carrega a chave no agente antes de conectar; a passphrase é pedida só quando necessário.'
echo 'Confira a fingerprint do host e aprove a chave no painel da VM.'
