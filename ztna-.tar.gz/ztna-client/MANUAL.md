# Manual de uso — Access / Aprovação SSH

Este sistema permite aprovar, negar e revogar **autorizações de login SSH** por usuário e chave. O administrador toma as decisões em um painel web; o cliente conecta pelo terminal.

O exemplo deste manual usa **Ubuntu no Azure como servidor** e **Arch Linux ou Kali como cliente**. Ele funciona independentemente do Django e do Keycloak.

## 1. Como funciona

1. O cliente cria uma chave Ed25519 própria, protegida por uma passphrase.
2. Ao executar `ztna-connect`, o wrapper carrega a chave no `ssh-agent` e inicia o SSH.
3. Se a chave ainda não está autorizada para aquele usuário, aparece um pedido no painel.
4. O administrador confere a fingerprint, escolhe uma validade e aprova ou nega.
5. O SSH verifica se o cliente possui a chave privada. Com a aprovação e a verificação concluídas, o login é liberado.
6. As próximas conexões com a mesma chave e usuário dispensam nova aprovação enquanto a autorização for válida.

**A chave privada e sua passphrase ficam no cliente.** O painel recebe a identificação da chave, não esses segredos. Um pedido pendente ainda não comprova que o cliente possui a chave privada.

Existem três informações diferentes:

| Informação | Para que serve |
|---|---|
| Passphrase da chave | Desbloqueia a chave no computador cliente. |
| Senha do painel | Permite ao administrador aprovar e revogar autorizações. |
| Fingerprint | Identifica uma chave; deve ser conferida antes de confiar nela. |

## 2. Instalar o servidor

### Preparar a VM

É necessário Linux com systemd ativo, acesso `sudo` e uma conta de login existente que não seja root. Mantenha a conexão SSH administrativa atual aberta durante a instalação.

No **Ubuntu ou Kali servidor**:

```bash
sudo apt update
sudo apt install -y golang-go openssh-server openssl iproute2 build-essential
```

Em um **servidor Arch**, as dependências são:

```bash
sudo pacman -S --needed go openssh openssl iproute2 base-devel
```

O projeto requer Go 1.21 ou superior. Confira o IP local e as portas ocupadas:

```bash
go version
ip -brief -4 address
sudo ss -ltnp
```

### Copiar e instalar

No **computador onde está o pacote**, envie-o à VM:

```bash
scp ztna-server-linux.tar.gz azureuser@ENDERECO_DA_VM:~/
```

Substitua `ENDERECO_DA_VM` pelo IP público ou nome usado no seu SSH administrativo. Se você usa uma chave específica, acrescente `-i CAMINHO_DA_CHAVE` ao `scp` e aos comandos SSH deste manual.

Na **VM servidora**:

```bash
tar -xzf ~/ztna-server-linux.tar.gz -C ~/
cd ~/ztna-server
```

No nosso exemplo Azure:

| Parâmetro | Valor |
|---|---|
| IP privado presente na interface da VM | `172.16.0.4` |
| Usuário de login da VM | `azureuser` |
| Porta do SSH com aprovação | `2222` |
| Porta local do painel | `8082` |
| Ordem dos endereços entregue pelo SSH | `client-first` |

Primeiro, valide sem instalar:

```bash
sudo bash deploy/install-server.sh \
  172.16.0.4 azureuser 2222 8082 client-first --check
```

Se a validação passar, instale:

```bash
sudo bash deploy/install-server.sh \
  172.16.0.4 azureuser 2222 8082 client-first
```

**Adapte os valores para sua máquina.** O instalador do servidor exige um IPv4 realmente presente na interface local; no exemplo Azure, esse é o IP privado, não o público.

`client-first` é o padrão. Na VM Kali original deste projeto, foi necessário `server-first` porque o OpenSSH entregou os endereços em outra ordem. Confira o IP do pedido no painel após o primeiro teste; não escolha a opção apenas pelo nome da distribuição.

O instalador compila e testa o projeto, cria o segredo do painel e a chave de host se ainda não existirem, instala os serviços e **habilita o início automático no boot**. Também mantém a configuração do SSH administrativo separado.

Confira o resultado:

```bash
sudo systemctl is-active pam-ztna ztna-session-guard sshd-ztna.socket
sudo systemctl is-enabled pam-ztna ztna-session-guard sshd-ztna.socket
```

### Permitir a conexão pela rede

No NSG associado à **VM Ubuntu no Azure**, crie uma regra de entrada:

| Campo | Valor |
|---|---|
| Origem | IP público da conexão de internet do cliente, com `/32` |
| Porta de origem | `*` |
| Destino, se configurado como endereço IP | IP privado da VM: `172.16.0.4` neste exemplo |
| Porta de destino | `2222` |
| Protocolo / ação | TCP / Permitir |

Escolha uma prioridade disponível que permita a conexão antes de uma eventual regra de bloqueio. Se houver NSGs tanto na interface quanto na sub-rede, ambos precisam permitir o tráfego. [Referência: filtragem por NSGs no Azure](https://learn.microsoft.com/en-us/azure/virtual-network/network-security-group-how-it-works).

O instalador não altera NSG, firewall local ou roteamento. Caso exista firewall ativo na VM, ele também precisa permitir essa conexão. **Não é necessário liberar a porta do painel na internet.**

## 3. Abrir o painel

No **Arch/Kali cliente**, abra um túnel pela conexão SSH administrativa já disponível:

```bash
ssh -N -o ExitOnForwardFailure=yes \
  -L 127.0.0.1:8082:127.0.0.1:8082 \
  azureuser@ENDERECO_DA_VM
```

Deixe esse terminal aberto e acesse **http://127.0.0.1:8082/** no navegador do cliente. O comando ficar em primeiro plano, sem abrir um shell, é esperado.

- Usuário do painel: `admin`.
- Senha: na **VM**, consulte `sudo cat /etc/pam-ztna/admin.env` e use somente o valor após `=`. Não compartilhe esse segredo com os usuários clientes.

Se a porta 8082 já estiver ocupada no seu computador, use `-L 127.0.0.1:18082:127.0.0.1:8082` e abra **http://127.0.0.1:18082/**.

O túnel usa o SSH administrativo, normalmente na porta 22. Não use a conexão ainda pendente de aprovação para tentar abrir o próprio painel. Também não inicie outra instância manual do servidor: ela pode usar outro banco e não mostrar os pedidos da instalação.

## 4. Instalar o cliente e conectar

No **Arch**:

```bash
sudo pacman -S --needed openssh util-linux
```

No **Kali/Ubuntu cliente**:

```bash
sudo apt install openssh-client util-linux
```

Com o pacote do cliente nesse computador, execute **sem sudo**:

```bash
tar -xzf ztna-client-linux.tar.gz
cd ztna-client
bash install-client.sh ENDERECO_DA_VM azureuser 2222
```

Escolha uma passphrase ao criar a chave. O instalador cria:

- `~/.ssh/id_ed25519_ztna`: chave privada; não compartilhe.
- `~/.ssh/id_ed25519_ztna.pub`: chave pública.
- `~/.ssh/ztna_config`: configuração do destino.
- `~/.local/bin/ztna-connect`: comando para conectar.

Cada dispositivo deve gerar sua própria chave. Reexecutar o instalador preserva a chave existente e troca o destino configurado; o wrapper atual mantém um destino por vez. `azureuser` é a conta **da VM**, não precisa ser o nome do usuário no Arch.

### Primeiro login

Na **VM**, consulte a fingerprint do host:

```bash
sudo ssh-keygen -lf /etc/pam-ztna/ssh_host_ed25519_key.pub
```

No **cliente**, consulte sua própria fingerprint e conecte:

```bash
ssh-keygen -lf ~/.ssh/id_ed25519_ztna.pub
~/.local/bin/ztna-connect
```

Confira se a fingerprint do host apresentada pelo SSH corresponde à consultada na VM. Depois, no painel:

1. Abra **Pendentes** e clique em **Revisar pedido**.
2. Confira o usuário, o IP de origem e a fingerprint **do cliente**.
3. Dê um nome ao dispositivo, por exemplo `arch-pessoal`.
4. Selecione a validade e clique em **Aprovar acesso**.

Aprove durante a espera, de até **90 segundos**. Se o prazo acabar, execute o comando de conexão novamente.

## 5. Uso diário

Para conectar, use sempre:

```bash
~/.local/bin/ztna-connect
```

O wrapper reutiliza o agente da sessão ou inicia um agente próprio. A passphrase só é solicitada quando a chave precisa ser carregada. Após reiniciar a máquina, encerrar o agente ou remover a chave dele, será necessário desbloqueá-la novamente. O wrapper não grava a passphrase.

No painel:

| Ação | Resultado |
|---|---|
| Aprovar | Autoriza novos logins com aquela chave e usuário pelo período escolhido. |
| Negar | Recusa o pedido pendente. Uma nova tentativa poderá gerar outro pedido. |
| Salvar e renovar validade | Atualiza o nome e define uma nova validade a partir da confirmação. |
| Revogar e desconectar | Bloqueia novos logins e encerra todas as conexões daquela autorização no listener gerenciado, em poucos segundos. |
| Buscar / filtrar | Localiza identidades por nome, usuário, IP, fingerprint ou estado. |

**No listener gerenciado atualizado, revogar ou deixar expirar encerra também as conexões SSH abertas daquela autorização, normalmente em poucos segundos.** Os indicadores representam autorizações, não conexões ativas. A regra de aprovação vale para o listener instalado, neste exemplo na porta 2222; não passa a controlar o SSH administrativo da porta 22.

O nome do dispositivo é um rótulo atribuído pelo operador. A identidade é a combinação de **usuário + chave**, não o IP nem o nome. A versão atual suporta até 1024 identidades, páginas de até 100 registros e não possui histórico completo de auditoria.

## 6. Atualizar e resolver problemas

### Atualizar o painel ou servidor

Transfira o novo pacote, extraia e execute novamente o instalador com os mesmos parâmetros. O HTML é incorporado ao binário: copiar somente `index.html` não atualiza o serviço em execução.

```bash
cd ~/ztna-server
sudo bash deploy/install-server.sh \
  172.16.0.4 azureuser 2222 8082 client-first
```

A reinstalação preserva o banco, o segredo e a chave de host existentes. Os serviços são reiniciados; pedidos e conexões do listener de teste podem ser interrompidos. As configurações anteriores são copiadas para `/etc/pam-ztna/backup-*`; isso não substitui um backup completo do banco.

### Comandos úteis na VM

```bash
# Estado e logs recentes
sudo systemctl status pam-ztna ztna-session-guard sshd-ztna.socket
sudo journalctl -u pam-ztna -u ztna-session-guard -u 'sshd-ztna@*.service' -n 50 --no-pager

# Iniciar ou parar
sudo systemctl start pam-ztna ztna-session-guard sshd-ztna.socket
sudo systemctl stop sshd-ztna.socket ztna-session-guard pam-ztna
```

Parar os serviços não desativa o início no boot. Para isso, use `sudo systemctl disable pam-ztna ztna-session-guard sshd-ztna.socket`.

### Problemas comuns

| Sintoma | O que conferir |
|---|---|
| Cliente espera e não aparece pedido | Painel correto, túnel, porta 2222 e logs. Outra instância do painel pode usar outro banco. |
| Conexão expira antes de chegar ao SSH | Endereço público, NSG, firewall local e IP público de origem da regra. |
| Pedido expirou ou ficou sem aprovação | Inicie nova conexão e aprove em até 90 segundos. |
| Solicita `Enter passphrase for key` | É o desbloqueio local da chave, esperado quando ainda não está carregada. |
| Solicita senha de `azureuser@...` | Confira o destino e a porta: o listener instalado aceita somente chave, não senha de usuário. |
| IP exibido é o do próprio servidor | Confira a ordem dos endpoints nos logs e ajuste `client-first`/`server-first` na instalação. |
| Painel não abre ou fica sem conexão | Confira túnel, serviço `pam-ztna`, porta escolhida e autenticação do painel. |
| SSH avisa que a chave do host mudou | Confirme a nova fingerprint diretamente na VM antes de alterar a confiança no cliente. |

Para ver detalhes de uma tentativa, execute no **cliente**:

```bash
ssh -vv -F ~/.ssh/ztna_config ztna-vm
```

Antes de compartilhar logs, revise nomes, endereços e caminhos que você não queira divulgar. Nunca envie chaves privadas, passphrases ou o segredo administrativo.


### Atualização para revogação de conexões abertas

Esta função exige o instalador novo, não apenas a troca do HTML ou binário.
Cada transporte SSH passa a executar em `sshd-ztna@…service`, criado pelo socket
`sshd-ztna.socket`. O monitor `ztna-session-guard` vincula essa instância à
aprovação antes de liberar a chave. Revogar ou expirar faz o monitor encerrar
as instâncias correspondentes; outra aprovação não reativa as conexões antigas.

O monitor consulta a autorização a cada segundo. O encerramento pode levar
alguns segundos, incluindo o prazo de parada do systemd. Se o monitor ou o
serviço de autorização parar, as conexões gerenciadas são encerradas por
segurança. O monitor roda como root para parar apenas essas unidades; o painel
continua sob a conta dedicada `pam-ztna`.

Na atualização, o daemon compartilhado antigo é desativado e sua unidade é
movida para o backup. As conexões do listener de teste precisam ser refeitas.
O SSH administrativo permanece independente. O socket admite até 64 conexões
simultâneas, com limite de 8 por endereço de origem.

Encerrar o transporte não garante eliminar tarefas destacadas da sessão,
como serviços iniciados separadamente, `tmux` ou processos com `nohup`.
Os indicadores do painel continuam contando autorizações, não sessões ativas.
