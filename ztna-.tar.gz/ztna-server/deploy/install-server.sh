#!/usr/bin/env bash
set -euo pipefail
umask 077
usage() {
    echo 'Uso: sudo bash install-server.sh IP USUARIO [PORTA_SSH=2222] [PORTA_PAINEL=8081] [client-first|server-first] [--check|--enable]'
    echo 'A instalação ativa os serviços no boot por padrão. --check: valida sem instalar. --enable: opção compatível, agora redundante.'
}
[[ ${1:-} != --help ]] || { usage; exit 0; }
[[ $# -ge 2 && $# -le 6 ]] || { usage; exit 1; }
address=$1 account=$2 port=${3:-2222} dashboard=${4:-8081} order=${5:-client-first} mode=${6:-}
[[ $EUID == 0 ]] || { echo 'Execute com sudo.' >&2; exit 1; }
[[ $address =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ && $account =~ ^[a-z_][a-z0-9_-]*$ && $account != root ]] || { usage; exit 1; }
for n in "$port" "$dashboard"; do
    [[ $n =~ ^[0-9]{1,5}$ ]] && (( 10#$n > 0 && 10#$n < 65536 )) || exit 1
done
[[ $port != "$dashboard" && $port != 22 ]] || { echo 'Escolha portas distintas; SSH isolado não usa 22.' >&2; exit 1; }
[[ $order == client-first || $order == server-first ]] || { usage; exit 1; }
[[ -z $mode || $mode == --check || $mode == --enable ]] || { usage; exit 1; }
getent passwd "$account" >/dev/null || { echo 'A conta local de destino não existe.' >&2; exit 1; }
[[ -d /run/systemd/system ]] || { echo 'É necessário systemd ativo.' >&2; exit 1; }
for cmd in go sshd ssh-keygen openssl ip systemctl; do
    command -v "$cmd" >/dev/null || {
        echo 'Dependências: Kali: sudo apt install golang-go openssh-server openssl iproute2' >&2
        echo 'Arch: sudo pacman -S go openssh openssl iproute2' >&2
        exit 1
    }
done
ip -o -4 address show | awk '{print $4}' | cut -d/ -f1 | grep -Fxq "$address" || { echo 'IP não pertence a esta máquina.' >&2; exit 1; }
base=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
stage=$(mktemp -d /tmp/ztna-install.XXXXXXXX)
trap 'rm -rf -- "$stage"' EXIT
cd "$base/server"
go test -race ./...
go vet ./...
go build -buildvcs=false -o "$stage/pam-ztna-server" .
go build -buildvcs=false -o "$stage/ztna-keys" ./cmd/ztna-keys
go build -buildvcs=false -o "$stage/ztna-session-guard" ./cmd/ztna-session-guard
extra=' --guard-socket /run/pam-ztna-guard/guard.sock'
[[ $order != server-first ]] || extra="$extra --server-first"
sed -e "s/POC_USER/$account/g" \
    -e "s/Port 2222/Port $port/" \
    -e "s/ListenAddress 127.0.0.1/ListenAddress $address/" \
    -e 's|/ABSOLUTE/PRIVATE/PATH/ssh_host_ed25519_key|/etc/pam-ztna/ssh_host_ed25519_key|' \
    -e "s|ztna-keys --socket|ztna-keys$extra --socket|" \
    "$base/deploy/sshd-poc.conf.example" > "$stage/sshd_config"
sshd_bin=$(command -v sshd)
if [[ $mode == --check ]]; then
    ssh-keygen -q -t ed25519 -N '' -f "$stage/host_key"
    sed -e "s|/etc/pam-ztna/ssh_host_ed25519_key|$stage/host_key|" \
        -e "s|/usr/local/libexec/ztna-keys|$stage/ztna-keys|" \
        -e 's/AuthorizedKeysCommandUser pam-ztna/AuthorizedKeysCommandUser root/' \
        "$stage/sshd_config" > "$stage/check_config"
    "$sshd_bin" -t -f "$stage/check_config"
    echo 'Compilação, testes e configuração validados; nada instalado.'
    exit 0
fi
if ! getent passwd pam-ztna >/dev/null; then
    useradd --system --user-group --home-dir /var/lib/pam-ztna --shell "$(command -v nologin)" pam-ztna
fi
install -d -o root -g root -m 0755 /usr/local/libexec
install -d -o root -g root -m 0700 /etc/pam-ztna
for bin in pam-ztna-server ztna-keys ztna-session-guard; do
    install -o root -g root -m 0755 "$stage/$bin" "/usr/local/libexec/$bin.new"
    mv -f -- "/usr/local/libexec/$bin.new" "/usr/local/libexec/$bin"
done
if [[ ! -e /etc/pam-ztna/admin.env ]]; then
    printf 'ZTNA_ADMIN_TOKEN=%s\n' "$(openssl rand -hex 32)" > /etc/pam-ztna/admin.env
fi
chown root:root /etc/pam-ztna/admin.env
chmod 600 /etc/pam-ztna/admin.env
if [[ ! -e /etc/pam-ztna/ssh_host_ed25519_key ]]; then
    ssh-keygen -q -t ed25519 -N '' -f /etc/pam-ztna/ssh_host_ed25519_key
fi
"$sshd_bin" -t -f "$stage/sshd_config"
backup="/etc/pam-ztna/backup-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -m 700 "$backup"
for f in /etc/pam-ztna/sshd_config /etc/systemd/system/pam-ztna.service /etc/systemd/system/sshd-ztna.service /etc/systemd/system/sshd-ztna.socket /etc/systemd/system/sshd-ztna@.service /etc/systemd/system/ztna-session-guard.service; do
    [[ ! -e $f ]] || cp -p -- "$f" "$backup/"
done
install -m 0600 "$stage/sshd_config" /etc/pam-ztna/sshd_config
sed "s/--port 8080/--port $dashboard/" "$base/deploy/pam-ztna.service" > "$stage/pam-ztna.service"
sed -e "s/LISTEN_IP/$address/" -e "s/LISTEN_PORT/$port/" "$base/deploy/sshd-ztna.socket" > "$stage/sshd-ztna.socket"
sed "s|/usr/sbin/sshd|$sshd_bin|" "$base/deploy/sshd-ztna@.service" > "$stage/sshd-ztna@.service"
# Retire the previous shared daemon only after saving its configuration.
if [[ -f /etc/systemd/system/sshd-ztna.service ]]; then
    systemctl disable --now sshd-ztna.service
    mv /etc/systemd/system/sshd-ztna.service "$backup/sshd-ztna.service.retired"
fi
install -m 0644 "$stage/pam-ztna.service" "$stage/sshd-ztna.socket" "$stage/sshd-ztna@.service" "$base/deploy/ztna-session-guard.service" /etc/systemd/system/
systemctl daemon-reload
# Restarting the authority also closes existing guarded transports via BindsTo.
systemctl restart pam-ztna
systemctl restart ztna-session-guard sshd-ztna.socket
systemctl enable pam-ztna ztna-session-guard sshd-ztna.socket
sleep 1
systemctl is-active --quiet pam-ztna
systemctl is-active --quiet ztna-session-guard
systemctl is-active --quiet sshd-ztna.socket
systemctl is-enabled --quiet pam-ztna
systemctl is-enabled --quiet ztna-session-guard
systemctl is-enabled --quiet sshd-ztna.socket
echo 'Serviços ativos, início no boot habilitado e revogação de conexões em execução disponível.'
echo "SSH: $account@$address:$port; painel local: http://127.0.0.1:$dashboard/ (admin)"
echo 'Consulte o segredo: sudo cat /etc/pam-ztna/admin.env'
echo "Backup da configuração anterior: $backup"
ssh-keygen -lf /etc/pam-ztna/ssh_host_ed25519_key.pub
