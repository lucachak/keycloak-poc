package main

import "encoding/base64"

func decodeStdBase64(s string) ([]byte, error) {
	return base64.StdEncoding.DecodeString(s)
}
