// ztna-keys is called only by sshd's AuthorizedKeysCommand. It never handles a
// private key: sshd still verifies the client's signature after this lookup.
package main

import (
	"bytes"
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"time"

	"pam-ztna-lab-server/internal/gate"
)

func run() error {
	socket := flag.String("socket", "/run/pam-ztna/auth.sock", "private server socket")
	serverFirst := flag.Bool("server-first", false, "sshd supplies server address and port before client endpoints in %C")
	flag.Parse()
	a := flag.Args()
	if len(a) != 4 || a[1] != "ssh-ed25519" {
		return fmt.Errorf("expected user, Ed25519 type, public key and quoted %%C")
	}
	if _, err := gate.Fingerprint(a[2]); err != nil {
		return err
	}
	endpoints := strings.Fields(a[3])
	if len(endpoints) != 4 || net.ParseIP(endpoints[0]) == nil || net.ParseIP(endpoints[2]) == nil {
		return fmt.Errorf("invalid SSH connection endpoints")
	}
	sourceIP := endpoints[0]
	if *serverFirst {
		sourceIP = endpoints[2]
	}
	data, err := json.Marshal(gate.Request{User: a[0], Key: a[2], SourceIP: sourceIP})
	if err != nil {
		return err
	}
	transport := &http.Transport{DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
		return (&net.Dialer{Timeout: 3 * time.Second}).DialContext(ctx, "unix", *socket)
	}}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 100 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	resp, err := client.Post("http://unix/authorize-key", "application/json", bytes.NewReader(data))
	if err != nil {
		return fmt.Errorf("authorization service unavailable")
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, io.LimitReader(resp.Body, 4096))
	if resp.StatusCode != 204 {
		return fmt.Errorf("key not authorized")
	}
	// No shell interpolation, certificate options or user-controlled comments.
	fmt.Printf("ssh-ed25519 %s\n", a[2])
	return nil
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
