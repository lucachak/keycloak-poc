package main

import (
	"context"
	"crypto/sha256"
	"crypto/subtle"
	_ "embed"
	"encoding/json"
	"flag"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"

	"pam-ztna-lab-server/internal/gate"
)

//go:embed static/index.html
var dashboardHTML []byte

func adminHandler(s *gate.Store, token string) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		if r.Method != "GET" {
			http.Error(w, "method", 405)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(dashboardHTML)
	})
	mux.HandleFunc("/api/grants", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "GET" {
			http.Error(w, "method", 405)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(s.Snapshot())
	})
	mux.HandleFunc("/api/grants/page", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			http.Error(w, "method", http.StatusMethodNotAllowed)
			return
		}
		values, err := urlValues(r)
		if err != nil {
			http.Error(w, "invalid query", http.StatusBadRequest)
			return
		}
		result, err := s.List(values)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(result)
	})
	mux.HandleFunc("/api/decision", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "method", 405)
			return
		}
		// A cross-origin form cannot set this header. No CORS is enabled.
		if r.Header.Get("X-ZTNA-Admin") != "1" || r.Header.Get("Content-Type") != "application/json" {
			http.Error(w, "forbidden", 403)
			return
		}
		var cmd struct {
			ID       string `json:"id"`
			Action   string `json:"action"`
			Hostname string `json:"hostname"`
			Seconds  int64  `json:"seconds"`
		}
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&cmd) != nil {
			http.Error(w, "bad request", 400)
			return
		}
		if err := s.Decide(cmd.ID, cmd.Action, cmd.Hostname, cmd.Seconds); err != nil {
			http.Error(w, err.Error(), 409)
			return
		}
		w.WriteHeader(204)
	})
	want := sha256.Sum256([]byte(token))
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
		host, _, err := net.SplitHostPort(r.Host)
		if err != nil || (host != "127.0.0.1" && host != "localhost" && host != "::1") {
			http.Error(w, "invalid host", 403)
			return
		}
		if site := r.Header.Get("Sec-Fetch-Site"); site == "cross-site" {
			http.Error(w, "forbidden", 403)
			return
		}
		if origin := r.Header.Get("Origin"); origin != "" && origin != "http://"+r.Host {
			http.Error(w, "invalid origin", 403)
			return
		}
		user, pass, ok := r.BasicAuth()
		got := sha256.Sum256([]byte(pass))
		if !ok || user != "admin" || subtle.ConstantTimeCompare(got[:], want[:]) != 1 {
			w.Header().Set("WWW-Authenticate", `Basic realm="ZTNA operator", charset="UTF-8"`)
			http.Error(w, "authentication required", 401)
			return
		}
		mux.ServeHTTP(w, r)
	})
}

func urlValues(r *http.Request) (gate.ListQuery, error) {
	v := r.URL.Query()
	q := gate.ListQuery{Page: 1, Limit: 25, Search: v.Get("q"), State: v.Get("state"), Sort: v.Get("sort"), Selected: v.Get("selected")}
	var err error
	if v.Has("page") {
		q.Page, err = strconv.Atoi(v.Get("page"))
		if err != nil {
			return q, err
		}
	}
	if v.Has("limit") {
		q.Limit, err = strconv.Atoi(v.Get("limit"))
	}
	return q, err
}

func keyHandler(s *gate.Store, timeout time.Duration) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/active-grants" && r.Method == http.MethodGet {
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(s.ActiveIDs())
			return
		}

		if r.URL.Path != "/authorize-key" {
			http.NotFound(w, r)
			return
		}
		if r.Method != "POST" {
			http.Error(w, "method", 405)
			return
		}
		var req gate.Request
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&req) != nil || net.ParseIP(req.SourceIP) == nil {
			http.Error(w, "bad request", 400)
			return
		}
		ctx, cancel := context.WithTimeout(r.Context(), timeout)
		defer cancel()
		id := s.AwaitGrant(ctx, req)
		if id == "" {
			http.Error(w, "not authorized", 403)
			return
		}
		w.Header().Set("X-ZTNA-Grant-ID", id)
		w.WriteHeader(204)
	})
}

func main() {
	port := flag.String("port", "8080", "dashboard loopback port")
	socket := flag.String("socket", "auth.sock", "private Unix socket for sshd helper")
	data := flag.String("data", "grants.json", "persistent grants (private directory)")
	timeout := flag.Duration("approve-timeout", 90*time.Second, "approval wait; keep below SSH LoginGraceTime")
	flag.Parse()
	token := strings.TrimSpace(os.Getenv("ZTNA_ADMIN_TOKEN"))
	if len(token) < 32 {
		log.Fatal("set ZTNA_ADMIN_TOKEN to a random secret of at least 32 characters")
	}
	if *timeout <= 0 || *timeout > 90*time.Second {
		log.Fatal("approve-timeout must be >0 and <=90s (helper deadline is 100s)")
	}
	s, err := gate.Open(*data)
	if err != nil {
		log.Fatal(err)
	}
	// Dedicated service uid shares the private socket with AuthorizedKeysCommand.
	// Never remove an existing socket: another server may still be running.
	syscall.Umask(0077)
	ln, err := net.Listen("unix", *socket)
	if err != nil {
		log.Fatal(err)
	}
	defer ln.Close()
	if err = os.Chmod(*socket, 0600); err != nil {
		log.Fatal(err)
	}
	api := &http.Server{Handler: keyHandler(s, *timeout), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: *timeout + 10*time.Second}
	ui := &http.Server{Addr: net.JoinHostPort("127.0.0.1", *port), Handler: adminHandler(s, token), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 10 * time.Second}
	errCh := make(chan error, 2)
	go func() { errCh <- api.Serve(ln) }()
	go func() { errCh <- ui.ListenAndServe() }()
	log.Printf("dashboard: http://127.0.0.1:%s/ (user admin); private SSH authorization socket ready", *port)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	failed := false
	select {
	case <-ctx.Done():
	case err := <-errCh:
		log.Printf("server stopped: %v", err)
		failed = true
	}
	ui.Close()
	api.Close()
	ln.Close()
	if failed {
		os.Exit(1)
	}
}
