module pam-ztna-lab-server

go 1.21
