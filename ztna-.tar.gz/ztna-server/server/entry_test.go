package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"pam-ztna-lab-server/internal/gate"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestAdminBoundary(t *testing.T) {
	s, e := gate.Open(filepath.Join(t.TempDir(), "grants.json"))
	if e != nil {
		t.Fatal(e)
	}
	token := strings.Repeat("t", 32)
	h := adminHandler(s, token)
	for _, tc := range []struct {
		name, path, method, host, origin, secret, header string
		want                                             int
	}{
		{name: "anonymous dashboard", path: "/", method: "GET", host: "127.0.0.1:8080", want: 401},
		{name: "anonymous page", path: "/api/grants/page", method: "GET", host: "127.0.0.1:8080", want: 401},
		{name: "authenticated page", path: "/api/grants/page?page=1&limit=25", method: "GET", host: "127.0.0.1:8080", secret: token, want: 200},
		{name: "page over limit", path: "/api/grants/page?limit=101", method: "GET", host: "127.0.0.1:8080", secret: token, want: 400},
		{name: "invalid page", path: "/api/grants/page?page=abc", method: "GET", host: "127.0.0.1:8080", secret: token, want: 400},
		{name: "page wrong method", path: "/api/grants/page", method: "POST", host: "127.0.0.1:8080", secret: token, want: 405},
		{name: "anonymous data", path: "/api/grants", method: "GET", host: "127.0.0.1:8080", want: 401},
		{name: "authenticated", path: "/api/grants", method: "GET", host: "127.0.0.1:8080", secret: token, want: 200},
		{name: "wrong token", path: "/api/grants", method: "GET", host: "127.0.0.1:8080", secret: "wrong", want: 401},
		{name: "DNS rebinding", path: "/", method: "GET", host: "evil.example:8080", secret: token, want: 403},
		{name: "CSRF", path: "/api/decision", method: "POST", host: "127.0.0.1:8080", origin: "http://evil.example", secret: token, header: "1", want: 403},
		{name: "missing header", path: "/api/decision", method: "POST", host: "127.0.0.1:8080", secret: token, want: 403},
		{name: "unknown decision", path: "/api/decision", method: "POST", host: "127.0.0.1:8080", secret: token, header: "1", want: 409},
		{name: "no legacy endpoint", path: "/authorize", method: "GET", host: "127.0.0.1:8080", secret: token, want: 404},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r := httptest.NewRequest(tc.method, "http://"+tc.host+tc.path, strings.NewReader(`{}`))
			r.Host = tc.host
			r.Header.Set("Origin", tc.origin)
			r.Header.Set("Content-Type", "application/json")
			r.Header.Set("X-ZTNA-Admin", tc.header)
			if tc.secret != "" {
				r.SetBasicAuth("admin", tc.secret)
			}
			w := httptest.NewRecorder()
			h.ServeHTTP(w, r)
			if w.Code != tc.want {
				t.Fatalf("got %d want %d", w.Code, tc.want)
			}
		})
	}
}

func TestInvalidAuthorizationFailsClosed(t *testing.T) {
	s, e := gate.Open(filepath.Join(t.TempDir(), "grants.json"))
	if e != nil {
		t.Fatal(e)
	}
	h := keyHandler(s, time.Millisecond)
	r := httptest.NewRequest(http.MethodPost, "http://unix/authorize-key", strings.NewReader(`{"user":"alice","key":"bad","source_ip":"192.0.2.1"}`))
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 403 {
		t.Fatal(w.Code)
	}
}

func TestPagedAPIAndLegacyContract(t *testing.T) {
	path := filepath.Join(t.TempDir(), "grants.json")
	rows := make([]gate.Grant, 1024)
	for i := range rows {
		rows[i] = gate.Grant{ID: fmt.Sprintf("%04d", i), User: "alice", Fingerprint: fmt.Sprintf("SHA256:%04d", i), Hostname: fmt.Sprintf("device-%04d", i), State: "revoked", UpdatedAt: time.Now()}
	}
	data, err := json.Marshal(rows)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
	s, err := gate.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	token := strings.Repeat("t", 32)
	h := adminHandler(s, token)
	get := func(path string) *httptest.ResponseRecorder {
		r := httptest.NewRequest(http.MethodGet, "http://127.0.0.1:8080"+path, nil)
		r.SetBasicAuth("admin", token)
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if w.Code != 200 {
			t.Fatalf("%s: %d", path, w.Code)
		}
		return w
	}
	paged := get("/api/grants/page?page=1&limit=100&sort=name&selected=1023")
	var result gate.GrantPage
	if err := json.Unmarshal(paged.Body.Bytes(), &result); err != nil {
		t.Fatal(err)
	}
	if len(result.Items) != 100 || result.Total != 1024 || result.Counts.All != 1024 || result.Selected == nil || result.Selected.ID != "1023" {
		t.Fatalf("unexpected page: %+v", result)
	}
	legacy := get("/api/grants")
	var all []gate.Grant
	if err := json.Unmarshal(legacy.Body.Bytes(), &all); err != nil || len(all) != 1024 {
		t.Fatal("legacy contract changed", err)
	}
	if paged.Body.Len() >= legacy.Body.Len()/5 {
		t.Fatal("page response unexpectedly large")
	}
}
