package main

import (
	"net/http"
	"net/http/httptest"
	"pam-ztna-lab-server/internal/gate"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestAdminBoundary(t *testing.T) {
	s, e := gate.Open(filepath.Join(t.TempDir(), "grants.json"))
	if e != nil {
		t.Fatal(e)
	}
	token := strings.Repeat("t", 32)
	h := adminHandler(s, token)
	for _, tc := range []struct {
		name, path, method, host, origin, secret, header string
		want                                             int
	}{
		{name: "anonymous dashboard", path: "/", method: "GET", host: "127.0.0.1:8080", want: 401},
		{name: "anonymous data", path: "/api/grants", method: "GET", host: "127.0.0.1:8080", want: 401},
		{name: "authenticated", path: "/api/grants", method: "GET", host: "127.0.0.1:8080", secret: token, want: 200},
		{name: "wrong token", path: "/api/grants", method: "GET", host: "127.0.0.1:8080", secret: "wrong", want: 401},
		{name: "DNS rebinding", path: "/", method: "GET", host: "evil.example:8080", secret: token, want: 403},
		{name: "CSRF", path: "/api/decision", method: "POST", host: "127.0.0.1:8080", origin: "http://evil.example", secret: token, header: "1", want: 403},
		{name: "missing header", path: "/api/decision", method: "POST", host: "127.0.0.1:8080", secret: token, want: 403},
		{name: "unknown decision", path: "/api/decision", method: "POST", host: "127.0.0.1:8080", secret: token, header: "1", want: 409},
		{name: "no legacy endpoint", path: "/authorize", method: "GET", host: "127.0.0.1:8080", secret: token, want: 404},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r := httptest.NewRequest(tc.method, "http://"+tc.host+tc.path, strings.NewReader(`{}`))
			r.Host = tc.host
			r.Header.Set("Origin", tc.origin)
			r.Header.Set("Content-Type", "application/json")
			r.Header.Set("X-ZTNA-Admin", tc.header)
			if tc.secret != "" {
				r.SetBasicAuth("admin", tc.secret)
			}
			w := httptest.NewRecorder()
			h.ServeHTTP(w, r)
			if w.Code != tc.want {
				t.Fatalf("got %d want %d", w.Code, tc.want)
			}
		})
	}
}

func TestInvalidAuthorizationFailsClosed(t *testing.T) {
	s, e := gate.Open(filepath.Join(t.TempDir(), "grants.json"))
	if e != nil {
		t.Fatal(e)
	}
	h := keyHandler(s, time.Millisecond)
	r := httptest.NewRequest(http.MethodPost, "http://unix/authorize-key", strings.NewReader(`{"user":"alice","key":"bad","source_ip":"192.0.2.1"}`))
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 403 {
		t.Fatal(w.Code)
	}
}
