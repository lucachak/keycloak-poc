package gate

import (
	"errors"
	"sort"
	"strings"
)

type ListQuery struct {
	Page, Limit                   int
	Search, State, Sort, Selected string
}

type Counts struct {
	All      int `json:"all"`
	Pending  int `json:"pending"`
	Approved int `json:"approved"`
	Inactive int `json:"inactive"`
}

type GrantPage struct {
	Items    []Grant `json:"items"`
	Total    int     `json:"total"`
	Page     int     `json:"page"`
	Pages    int     `json:"pages"`
	Limit    int     `json:"limit"`
	Counts   Counts  `json:"counts"`
	Selected *Grant  `json:"selected"`
}

// List returns one bounded page and global counts from the same snapshot.
// Selected stays available when a live update moves it outside the page/filter.
func (s *Store) List(q ListQuery) (GrantPage, error) {
	var out GrantPage
	if q.Page < 1 || q.Page > 1000000 || q.Limit < 1 || q.Limit > 100 || len(q.Search) > 1024 || len(q.Selected) > 64 {
		return out, errors.New("invalid pagination or search length")
	}
	switch q.State {
	case "", "all", "pending", "approved", "inactive", "revoked", "expired", "denied":
	default:
		return out, errors.New("invalid state")
	}
	switch q.Sort {
	case "", "priority", "recent", "name", "expiry":
	default:
		return out, errors.New("invalid sort")
	}
	query := strings.ToLower(strings.TrimSpace(q.Search))
	matches := make([]Grant, 0)
	for _, g := range s.snapshot() {
		out.Counts.All++
		switch g.State {
		case "pending":
			out.Counts.Pending++
		case "approved":
			out.Counts.Approved++
		default:
			out.Counts.Inactive++
		}
		if g.ID == q.Selected {
			copy := g // A separate value, including on Go 1.21.
			out.Selected = &copy
		}
		if q.State != "" && q.State != "all" && q.State != g.State && !(q.State == "inactive" && g.State != "approved" && g.State != "pending") {
			continue
		}
		if query != "" && !strings.Contains(strings.ToLower(g.Hostname), query) && !strings.Contains(strings.ToLower(g.User), query) && !strings.Contains(strings.ToLower(g.SourceIP), query) && !strings.Contains(strings.ToLower(g.Fingerprint), query) {
			continue
		}
		matches = append(matches, g)
	}
	recent := func(a, b Grant) bool {
		if a.UpdatedAt.Equal(b.UpdatedAt) {
			return a.ID < b.ID
		}
		return a.UpdatedAt.After(b.UpdatedAt)
	}
	sort.Slice(matches, func(i, j int) bool {
		a, b := matches[i], matches[j]
		switch q.Sort {
		case "name":
			an, bn := strings.ToLower(a.Hostname), strings.ToLower(b.Hostname)
			if an == "" {
				an = "dispositivo sem nome"
			}
			if bn == "" {
				bn = "dispositivo sem nome"
			}
			if an != bn {
				return an < bn
			}
		case "expiry":
			aFinite, bFinite := a.State == "approved" && a.ExpiresAt != nil, b.State == "approved" && b.ExpiresAt != nil
			if aFinite != bFinite {
				return aFinite
			}
			if aFinite && !a.ExpiresAt.Equal(*b.ExpiresAt) {
				return a.ExpiresAt.Before(*b.ExpiresAt)
			}
		case "priority", "":
			if (a.State == "pending") != (b.State == "pending") {
				return a.State == "pending"
			}
		}
		return recent(a, b)
	})
	out.Total, out.Limit, out.Page = len(matches), q.Limit, q.Page
	out.Pages = (out.Total + q.Limit - 1) / q.Limit
	if out.Pages == 0 {
		out.Pages = 1
	}
	if out.Page > out.Pages {
		out.Page = out.Pages
	}
	start := (out.Page - 1) * q.Limit
	end := start + q.Limit
	if end > out.Total {
		end = out.Total
	}
	out.Items = matches[start:end]
	return out, nil
}
