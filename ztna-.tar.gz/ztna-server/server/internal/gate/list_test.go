package gate

import (
	"fmt"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

func listFixture(t *testing.T) *Store {
	t.Helper()
	s, err := Open(filepath.Join(t.TempDir(), "grants.json"))
	if err != nil {
		t.Fatal(err)
	}
	now := time.Now()
	future, past := now.Add(time.Hour), now.Add(-time.Hour)
	for i := 0; i < 1024; i++ {
		id := fmt.Sprintf("%04d", i)
		g := &Grant{ID: id, User: "alice", Hostname: "host-" + id, Fingerprint: "SHA256:" + id, SourceIP: "192.0.2.10", State: "revoked", UpdatedAt: now}
		switch i % 4 {
		case 0:
			g.State = "pending"
		case 1:
			g.State = "approved"
			g.ExpiresAt = &future
		case 2:
			g.State = "approved"
			g.ExpiresAt = &past
		}
		s.rows[id] = g
	}
	return s
}

func TestListPagesAndCounts(t *testing.T) {
	s := listFixture(t)
	q := ListQuery{Page: 1, Limit: 25, Sort: "priority"}
	first, err := s.List(q)
	if err != nil {
		t.Fatal(err)
	}
	if first.Total != 1024 || first.Pages != 41 || len(first.Items) != 25 || first.Counts != (Counts{1024, 256, 256, 512}) {
		t.Fatalf("unexpected metadata: %+v", first)
	}
	seen := map[string]bool{}
	for page := 1; page <= first.Pages; page++ {
		q.Page = page
		result, err := s.List(q)
		if err != nil {
			t.Fatal(err)
		}
		for _, g := range result.Items {
			if seen[g.ID] {
				t.Fatalf("duplicate across pages: %s", g.ID)
			}
			seen[g.ID] = true
		}
	}
	if len(seen) != 1024 {
		t.Fatal("missing rows", len(seen))
	}
	q.Page = 1000000
	last, _ := s.List(q)
	if last.Page != 41 || len(last.Items) != 24 {
		t.Fatalf("last page not clamped: %+v", last)
	}
	q.Page = 1
	again, _ := s.List(q)
	if !reflect.DeepEqual(first.Items, again.Items) {
		t.Fatal("unstable order for equal timestamps")
	}
}

func TestListFiltersSelectionAndExpiration(t *testing.T) {
	s := listFixture(t)
	q := ListQuery{Page: 1, Limit: 25, State: "approved", Search: "HOST-0001", Selected: "0000"}
	result, err := s.List(q)
	if err != nil {
		t.Fatal(err)
	}
	if result.Total != 1 || result.Items[0].ID != "0001" || result.Selected == nil || result.Selected.ID != "0000" || result.Counts.All != 1024 {
		t.Fatalf("filter or selected identity lost: %+v", result)
	}
	for _, search := range []string{"ALICE", "192.0.2.10", "sha256:0001"} {
		q.Search = search
		result, err = s.List(q)
		if err != nil || result.Total == 0 {
			t.Fatal("search failed", search, err)
		}
	}
	q.Search = ""
	q.State = "expired"
	result, _ = s.List(q)
	if result.Total != 256 {
		t.Fatal("expired count", result.Total)
	}
	if s.rows["0002"].State != "approved" {
		t.Fatal("read mutated persisted state")
	}
	q.State = "inactive"
	result, _ = s.List(q)
	if result.Total != 512 {
		t.Fatal("inactive count", result.Total)
	}
	q.Search = "missing"
	q.Selected = "missing"
	result, _ = s.List(q)
	if result.Total != 0 || result.Page != 1 || result.Pages != 1 || result.Items == nil || result.Selected != nil {
		t.Fatalf("empty response: %+v", result)
	}
}

func TestListOrderingAndValidation(t *testing.T) {
	s := listFixture(t)
	for _, mode := range []string{"priority", "recent", "name", "expiry"} {
		result, err := s.List(ListQuery{Page: 1, Limit: 100, Sort: mode})
		if err != nil {
			t.Fatal(err)
		}
		if mode == "priority" && result.Items[0].State != "pending" {
			t.Fatal("pending priority")
		}
		if mode == "name" && result.Items[0].Hostname != "host-0000" {
			t.Fatal("name ordering")
		}
		if mode == "expiry" && result.Items[0].State != "approved" {
			t.Fatal("finite active expirations must lead")
		}
	}
	for _, q := range []ListQuery{{Page: 0, Limit: 25}, {Page: 1, Limit: 101}, {Page: 1000001, Limit: 25}, {Page: 1, Limit: 25, State: "invalid"}, {Page: 1, Limit: 25, Sort: "invalid"}, {Page: 1, Limit: 25, Search: strings.Repeat("x", 1025)}, {Page: 1, Limit: 25, Selected: strings.Repeat("x", 65)}} {
		if _, err := s.List(q); err == nil {
			t.Fatalf("accepted invalid query: %+v", q)
		}
	}
}
