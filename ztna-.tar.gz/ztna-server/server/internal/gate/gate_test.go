package gate

import (
	"context"
	"encoding/base64"
	"encoding/binary"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func testKey(seed byte) string {
	b := make([]byte, 51)
	binary.BigEndian.PutUint32(b, 11)
	copy(b[4:], "ssh-ed25519")
	binary.BigEndian.PutUint32(b[15:], 32)
	for i := 19; i < len(b); i++ {
		b[i] = seed
	}
	return base64.StdEncoding.EncodeToString(b)
}
func pending(t *testing.T, s *Store) Grant {
	t.Helper()
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		for _, g := range s.Snapshot() {
			if g.State == "pending" {
				return g
			}
		}
		time.Sleep(time.Millisecond)
	}
	t.Fatal("no pending request")
	return Grant{}
}
func openTest(t *testing.T) *Store {
	t.Helper()
	s, e := Open(filepath.Join(t.TempDir(), "grants.json"))
	if e != nil {
		t.Fatal(e)
	}
	return s
}
func start(s *Store, r Request) (<-chan bool, context.CancelFunc) {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	ch := make(chan bool, 1)
	go func() { ch <- s.Await(ctx, r) }()
	return ch, cancel
}

func TestApprovalPersistenceAndRevocation(t *testing.T) {
	s := openTest(t)
	r := Request{User: "alice", Key: testKey(1), SourceIP: "192.0.2.1"}
	done, cancel := start(s, r)
	defer cancel()
	g := pending(t, s)
	if e := s.Decide(g.ID, "approve", "laptop", 0); e != nil {
		t.Fatal(e)
	}
	if !<-done {
		t.Fatal("approval rejected")
	}
	s2, e := Open(s.path)
	if e != nil {
		t.Fatal(e)
	}
	if !s2.Await(context.Background(), r) {
		t.Fatal("persistent grant not reused")
	}
	fi, _ := os.Stat(s.path)
	if fi.Mode().Perm() != 0600 {
		t.Fatal("database permissions")
	}
	if e := s2.Decide(g.ID, "revoke", "", 0); e != nil {
		t.Fatal(e)
	}
	s3, e := Open(s.path)
	if e != nil {
		t.Fatal(e)
	}
	next, stop := start(s3, r)
	newg := pending(t, s3)
	if newg.ID == g.ID {
		t.Fatal("request ID reused")
	}
	if e := s3.Decide(g.ID, "approve", "", 0); e == nil {
		t.Fatal("stale action accepted")
	}
	stop()
	if <-next {
		t.Fatal("revocation ignored")
	}
}

func TestKeyAndUserIsolation(t *testing.T) {
	s := openTest(t)
	r := Request{User: "alice", Key: testKey(1)}
	ch, cancel := start(s, r)
	defer cancel()
	g := pending(t, s)
	if e := s.Decide(g.ID, "approve", "laptop", 600); e != nil {
		t.Fatal(e)
	}
	if !<-ch {
		t.Fatal("denied")
	}
	for _, other := range []Request{{User: "bob", Key: r.Key}, {User: "alice", Key: testKey(2)}} {
		ctx, stop := context.WithTimeout(context.Background(), 10*time.Millisecond)
		if s.Await(ctx, other) {
			t.Fatal("identity isolation failed")
		}
		stop()
	}
}

func TestConcurrentWaitersAndDeny(t *testing.T) {
	s := openTest(t)
	r := Request{User: "alice", Key: testKey(1)}
	a, ca := start(s, r)
	defer ca()
	g := pending(t, s)
	b, cb := start(s, r)
	defer cb()
	deadline := time.Now().Add(time.Second)
	for {
		s.mu.Lock()
		n := s.rows[r.User+"\x00"+g.Fingerprint].waiters
		s.mu.Unlock()
		if n == 2 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("waiter did not join")
		}
		time.Sleep(time.Millisecond)
	}
	if e := s.Decide(g.ID, "deny", "", 0); e != nil {
		t.Fatal(e)
	}
	if <-a || <-b {
		t.Fatal("deny released a login")
	}
}

func TestExpiryTimeoutAndPersistenceFailure(t *testing.T) {
	s := openTest(t)
	r := Request{User: "alice", Key: testKey(1)}
	ch, cancel := start(s, r)
	defer cancel()
	g := pending(t, s)
	if e := s.Decide(g.ID, "approve", "", 599); e == nil {
		t.Fatal("short duration accepted")
	}
	original := s.path
	s.path = filepath.Join(t.TempDir(), "missing", "grants.json")
	if e := s.Decide(g.ID, "approve", "", 600); e == nil {
		t.Fatal("write failure ignored")
	}
	if s.Snapshot()[0].State != "pending" {
		t.Fatal("failed write changed state")
	}
	s.path = original
	if e := s.Decide(g.ID, "approve", "", 600); e != nil {
		t.Fatal(e)
	}
	if !<-ch {
		t.Fatal("denied")
	}
	s.mu.Lock()
	past := time.Now().Add(-time.Second)
	s.rows[r.User+"\x00"+g.Fingerprint].ExpiresAt = &past
	s.mu.Unlock()
	ctx, stop := context.WithTimeout(context.Background(), 10*time.Millisecond)
	defer stop()
	if s.Await(ctx, r) {
		t.Fatal("expired grant accepted")
	}
	if s.Snapshot()[0].State != "denied" {
		t.Fatal("timeout not cleared")
	}
}

func TestInvalidKeys(t *testing.T) {
	for _, key := range []string{"", "AAAA", testKey(1) + "\ncommand=bad"} {
		if _, e := Fingerprint(key); e == nil {
			t.Fatal("invalid key accepted")
		}
	}
}

func TestActiveIDsRespectRevocationExpirationAndGeneration(t *testing.T) {
	s, err := Open(filepath.Join(t.TempDir(), "grants.json"))
	if err != nil {
		t.Fatal(err)
	}
	future, past := time.Now().Add(time.Hour), time.Now().Add(-time.Hour)
	s.rows["alice\x00key"] = &Grant{ID: "old", User: "alice", Fingerprint: "key", State: "approved", ExpiresAt: &future}
	if ids := s.ActiveIDs(); len(ids) != 1 || ids[0] != "old" {
		t.Fatal(ids)
	}
	if err := s.Decide("old", "revoke", "", 0); err != nil {
		t.Fatal(err)
	}
	if len(s.ActiveIDs()) != 0 {
		t.Fatal("revoked generation remained active")
	}
	s.rows["alice\x00key"] = &Grant{ID: "new", User: "alice", Fingerprint: "key", State: "approved", ExpiresAt: &future}
	if ids := s.ActiveIDs(); len(ids) != 1 || ids[0] != "new" {
		t.Fatal("generation reused", ids)
	}
	s.rows["alice\x00key"].ExpiresAt = &past
	if len(s.ActiveIDs()) != 0 {
		t.Fatal("expired approval remained active")
	}
}
