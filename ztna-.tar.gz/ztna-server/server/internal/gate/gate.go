// Package gate implements device grants. Only sshd can prove possession of a key;
// an approval here authorizes that key, not a claimed hostname or source address.
package gate

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

type Request struct {
	User     string `json:"user"`
	Key      string `json:"key"`
	SourceIP string `json:"source_ip"`
}

type Grant struct {
	ID          string     `json:"id"`
	User        string     `json:"user"`
	Fingerprint string     `json:"fingerprint"`
	Hostname    string     `json:"hostname"` // Operator label, never authentication evidence.
	SourceIP    string     `json:"source_ip"`
	State       string     `json:"state"`
	ExpiresAt   *time.Time `json:"expires_at"`
	UpdatedAt   time.Time  `json:"updated_at"`
	waiters     int
	changed     chan struct{}
}

type Store struct {
	mu   sync.Mutex
	path string
	rows map[string]*Grant
}

// This PoC deliberately accepts only plain Ed25519 keys, not certificates.
func Fingerprint(key string) (string, error) {
	b, err := base64.StdEncoding.DecodeString(key)
	if err != nil || len(b) != 51 || base64.StdEncoding.EncodeToString(b) != key || binary.BigEndian.Uint32(b[:4]) != 11 || string(b[4:15]) != "ssh-ed25519" || binary.BigEndian.Uint32(b[15:19]) != 32 {
		return "", errors.New("expected a plain Ed25519 public key")
	}
	h := sha256.Sum256(b)
	return "SHA256:" + base64.RawStdEncoding.EncodeToString(h[:]), nil
}

func Open(path string) (*Store, error) {
	s := &Store{path: path, rows: map[string]*Grant{}}
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return s, nil
	}
	if err != nil {
		return nil, err
	}
	var rows []*Grant
	if err = json.Unmarshal(b, &rows); err != nil {
		return nil, err
	}
	for _, g := range rows {
		if g == nil || g.ID == "" || g.User == "" || g.Fingerprint == "" {
			return nil, errors.New("invalid grant database")
		}
		if g.State == "pending" {
			g.State = "denied"
		}
		g.changed = make(chan struct{})
		s.rows[g.User+"\x00"+g.Fingerprint] = g
	}
	return s, nil
}

func active(g *Grant) bool {
	return g.State == "approved" && (g.ExpiresAt == nil || time.Now().Before(*g.ExpiresAt))
}

func (s *Store) Await(ctx context.Context, r Request) bool {
	fp, err := Fingerprint(r.Key)
	if err != nil || r.User == "" || len(r.User) > 128 || strings.ContainsAny(r.User, "\x00\r\n") {
		return false
	}
	k := r.User + "\x00" + fp
	s.mu.Lock()
	g := s.rows[k]
	if g != nil && active(g) {
		s.mu.Unlock()
		return ctx.Err() == nil
	}
	if g == nil || g.State != "pending" {
		if g == nil && len(s.rows) >= 1024 {
			s.mu.Unlock()
			return false
		}
		var id [16]byte
		if _, err := rand.Read(id[:]); err != nil {
			s.mu.Unlock()
			return false
		}
		label := ""
		if g != nil {
			label = g.Hostname
		}
		g = &Grant{ID: hex.EncodeToString(id[:]), User: r.User, Fingerprint: fp, Hostname: label, SourceIP: r.SourceIP, State: "pending", UpdatedAt: time.Now(), changed: make(chan struct{})}
		s.rows[k] = g
	}
	g.waiters++
	ch := g.changed
	s.mu.Unlock()
	select {
	case <-ctx.Done():
	case <-ch:
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	g.waiters--
	if g.State == "pending" && g.waiters == 0 {
		g.State = "denied"
		g.UpdatedAt = time.Now()
		close(g.changed)
	}
	return ctx.Err() == nil && active(g)
}

func (s *Store) Snapshot() []Grant {
	s.mu.Lock()
	defer s.mu.Unlock()
	rows := make([]Grant, 0, len(s.rows))
	for _, g := range s.rows {
		v := *g
		if v.State == "approved" && !active(g) {
			v.State = "expired"
		}
		rows = append(rows, v)
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].UpdatedAt.After(rows[j].UpdatedAt) })
	return rows
}

func (s *Store) Decide(id, action, hostname string, seconds int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	var g *Grant
	for _, row := range s.rows {
		if row.ID == id {
			g = row
			break
		}
	}
	if g == nil {
		return errors.New("request no longer exists")
	}
	if action != "approve" && action != "deny" && action != "revoke" {
		return errors.New("invalid action")
	}
	if action == "approve" && (g.State != "pending" && !active(g)) {
		return errors.New("a new login request is required")
	}
	if action == "deny" && g.State != "pending" {
		return errors.New("request is not pending")
	}
	if seconds != 0 && (seconds < 600 || seconds > 31536000) {
		return errors.New("duration must be 10 minutes to 365 days, or unlimited")
	}
	if len(hostname) > 128 || strings.ContainsAny(hostname, "\r\n\x00") {
		return errors.New("invalid device label")
	}
	before := *g
	g.UpdatedAt = time.Now()
	switch action {
	case "approve":
		g.State = "approved"
		g.Hostname = strings.TrimSpace(hostname)
		g.ExpiresAt = nil
		if seconds != 0 {
			exp := time.Now().Add(time.Duration(seconds) * time.Second)
			g.ExpiresAt = &exp
		}
	case "deny":
		g.State = "denied"
	case "revoke":
		g.State = "revoked"
	}
	if err := s.save(); err != nil {
		*g = before
		return errors.New("could not persist decision")
	}
	if before.State == "pending" {
		close(g.changed)
	}
	return nil
}

// Caller holds mu. A failed write must never release a waiting login.
func (s *Store) save() error {
	rows := make([]*Grant, 0, len(s.rows))
	for _, g := range s.rows {
		rows = append(rows, g)
	}
	b, err := json.MarshalIndent(rows, "", "  ")
	if err != nil {
		return err
	}
	f, err := os.CreateTemp(filepath.Dir(s.path), ".grants-*")
	if err != nil {
		return err
	}
	name := f.Name()
	defer os.Remove(name)
	if _, err = f.Write(b); err != nil {
		f.Close()
		return err
	}
	if err = f.Sync(); err != nil {
		f.Close()
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	return os.Rename(name, s.path)
}
