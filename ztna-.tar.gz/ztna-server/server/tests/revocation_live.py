"""Root/systemd integration test using temporary loopback listeners and test keys.
Requires existing non-root `kali` and service account `pam-ztna` on the test host.
Does not change the production listeners, credentials or grants.
"""
import base64
import json
import os
import pathlib
import pwd
import secrets
import selectors
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.request

assert os.geteuid() == 0, 'Run on a disposable test host as root.'
project = pathlib.Path(__file__).resolve().parents[1]
service_account = pwd.getpwnam('pam-ztna')
pwd.getpwnam('kali')
work = pathlib.Path(tempfile.mkdtemp(prefix='ztna-revoke-test-', dir='/usr/local/libexec'))
work.chmod(0o755)
name = 'ztna-check-' + secrets.token_hex(3)
units = []
clients = []

def run(*args, **kw):
    return subprocess.run(args, check=True, capture_output=True, text=True, **kw)

def port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]

ssh_port, panel_port, admin_port = port(), port(), port()
secret = secrets.token_hex(32)

def unit(suffix, body):
    path = pathlib.Path('/run/systemd/system') / (name + suffix)
    path.write_text(body)
    units.append(path)
    return path.name

def api(path, body=None):
    r = urllib.request.Request(f'http://127.0.0.1:{panel_port}' + path, data=json.dumps(body).encode() if body else None)
    r.add_header('Authorization', 'Basic ' + base64.b64encode(('admin:' + secret).encode()).decode())
    if body:
        r.add_header('Content-Type', 'application/json')
        r.add_header('X-ZTNA-Admin', '1')
    with urllib.request.urlopen(r, timeout=5) as response:
        data = response.read()
        return json.loads(data) if data else None

def wait_for(fn, seconds=15):
    until = time.monotonic() + seconds
    while time.monotonic() < until:
        result = fn()
        if result:
            return result
        time.sleep(.15)
    raise AssertionError('Timed out waiting for test condition')

def pending(fp):
    return next((g for g in api('/api/grants') if g['fingerprint'] == fp and g['state'] == 'pending'), None)

def connect(key, destination=ssh_port):
    cmd = ['ssh', '-F', '/dev/null', '-p', str(destination), '-i', str(work / key), '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=yes', '-o', 'UserKnownHostsFile=' + str(work / 'known_hosts'), 'kali@127.0.0.1', 'printf "READY\\n"; sleep 300']
    client = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    clients.append(client)
    return client

def ready(client):
    with selectors.DefaultSelector() as selector:
        selector.register(client.stdout, selectors.EVENT_READ)
        if not selector.select(10):
            raise AssertionError('SSH did not open a shell')
        line = client.stdout.readline()
        if line != 'READY\n':
            raise AssertionError('SSH failed: ' + client.stderr.read())

try:
    for binary, source in [('server', '.'), ('ztna-keys', './cmd/ztna-keys'), ('guard', './cmd/ztna-session-guard')]:
        run('go', 'build', '-buildvcs=false', '-o', str(work / binary), source, cwd=project)
    for key in ('host', 'key-a', 'key-b'):
        run('ssh-keygen', '-q', '-t', 'ed25519', '-N', '', '-f', str(work / key))
    pub = (work / 'host.pub').read_text()
    (work / 'known_hosts').write_text(''.join(f'[127.0.0.1]:{p} ' + pub for p in (ssh_port, admin_port)))
    (work / 'key-a.pub').chmod(0o644)
    (work / 'data').mkdir(mode=0o700)
    os.chown(work / 'data', service_account.pw_uid, service_account.pw_gid)
    (work / 'guard-run').mkdir(mode=0o750)
    os.chown(work / 'guard-run', 0, service_account.pw_gid)
    (work / 'admin.env').write_text('ZTNA_ADMIN_TOKEN=' + secret + '\n')
    (work / 'admin.env').chmod(0o600)
    auth_socket = str(work / 'data/auth.sock')
    guard_socket = f'/run/{name}-guard/guard.sock'
    conf = (project.parent / 'deploy/sshd-poc.conf.example').read_text()
    conf = conf.replace('POC_USER', 'kali').replace('/ABSOLUTE/PRIVATE/PATH/ssh_host_ed25519_key', str(work / 'host')).replace('/usr/local/libexec/ztna-keys --socket /run/pam-ztna/auth.sock', f'{work}/ztna-keys --guard-socket {guard_socket} --socket {auth_socket}')
    (work / 'sshd.conf').write_text(conf)
    run('/usr/sbin/sshd', '-t', '-f', str(work / 'sshd.conf'))
    auth_unit = unit('-auth.service', f'[Service]\nUser=pam-ztna\nGroup=pam-ztna\nEnvironmentFile={work}/admin.env\nExecStart={work}/server --port {panel_port} --socket {auth_socket} --data {work}/data/grants.json\n')
    templates = project.parent / 'deploy'
    guard_body = (templates / 'ztna-session-guard.service').read_text().replace('pam-ztna.service', auth_unit).replace('RuntimeDirectory=pam-ztna-guard', 'RuntimeDirectory=' + name + '-guard').replace('ExecStart=/usr/local/libexec/ztna-session-guard', f'ExecStart={work}/guard --socket {guard_socket} --authority {auth_socket} --unit-prefix {name}-ssh@ --helper {work}/ztna-keys')
    guard_unit = unit('-guard.service', guard_body)
    connection_body = (templates / 'sshd-ztna@.service').read_text().replace('ztna-session-guard.service', guard_unit).replace('pam-ztna.service', auth_unit).replace('/etc/pam-ztna/sshd_config', str(work / 'sshd.conf'))
    unit('-ssh@.service', connection_body)
    socket_body = (templates / 'sshd-ztna.socket').read_text().replace('ztna-session-guard.service', guard_unit).replace('pam-ztna.service', auth_unit).replace('LISTEN_IP', '127.0.0.1').replace('LISTEN_PORT', str(ssh_port)).replace('sshd-ztna@.service', name + '-ssh@.service')
    socket_unit = unit('-ssh.socket', socket_body)
    # An independent administrative control connection with the same user/key.
    (work / 'admin.conf').write_text(f'Port {admin_port}\nListenAddress 127.0.0.1\nHostKey {work}/host\nAllowUsers kali\nPermitRootLogin no\nPasswordAuthentication no\nKbdInteractiveAuthentication no\nUsePAM yes\nAuthorizedKeysFile {work}/key-a.pub\n')
    admin_unit = unit('-admin.service', f'[Service]\nExecStart=/usr/sbin/sshd -D -e -f {work}/admin.conf\n')
    run('systemctl', 'daemon-reload')
    run('systemd-analyze', 'verify', *[str(u) for u in units])
    run('systemctl', 'start', socket_unit, admin_unit)
    wait_for(lambda: pathlib.Path(guard_socket).exists())
    fp_a = run('ssh-keygen', '-lf', str(work / 'key-a.pub')).stdout.split()[1]
    fp_b = run('ssh-keygen', '-lf', str(work / 'key-b.pub')).stdout.split()[1]
    admin = connect('key-a', admin_port); ready(admin)
    first = connect('key-a')
    grant_a = wait_for(lambda: pending(fp_a))
    api('/api/decision', dict(id=grant_a['id'], action='approve', hostname='test-a', seconds=600)); ready(first)
    second = connect('key-a'); ready(second)
    other = connect('key-b')
    grant_b = wait_for(lambda: pending(fp_b))
    api('/api/decision', dict(id=grant_b['id'], action='approve', hostname='test-b', seconds=600)); ready(other)
    api('/api/decision', dict(id=grant_a['id'], action='revoke'))
    wait_for(lambda: first.poll() is not None and second.poll() is not None, 10)
    assert other.poll() is None and admin.poll() is None, 'Unrelated connection was terminated'
    new = connect('key-a')
    next_grant = wait_for(lambda: pending(fp_a))
    assert next_grant['id'] != grant_a['id'], 'Reapproval reused revoked generation'
    api('/api/decision', dict(id=next_grant['id'], action='deny'))
    wait_for(lambda: new.poll() is not None)
    run('systemctl', 'stop', guard_unit)
    wait_for(lambda: other.poll() is not None, 10)
    assert admin.poll() is None, 'Guard stop affected administrative listener'
    print('PASS: revocation closes both active connections of key A; key B and administrative SSH stay open; reconnect needs new approval; stopping guard closes guarded sessions only.')
except Exception:
    for suffix in ('-guard.service', '-auth.service', '-admin.service'):
        print(run('journalctl', '-u', name + suffix, '-n', '20', '--no-pager').stdout)
    print(subprocess.run(['journalctl', '-u', name + '-ssh@*.service', '-n', '30', '--no-pager'], capture_output=True, text=True).stdout)
    raise
finally:
    for client in clients:
        if client.poll() is None:
            client.terminate()
        try:
            client.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            client.kill(); client.communicate()
    for path in reversed(units):
        if '@.' not in path.name:
            subprocess.run(['systemctl', 'stop', path.name], capture_output=True)
    for path in units:
        path.unlink(missing_ok=True)
    subprocess.run(['systemctl', 'daemon-reload'], capture_output=True)
    shutil.rmtree(work)
