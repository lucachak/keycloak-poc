"""Run: python3 tests/ui_smoke.py (Selenium, Chromium and chromedriver).
Serves synthetic records on an ephemeral loopback port; never uses a live API.
"""
import json
import pathlib
import tempfile
import threading
import time
from urllib.parse import urlsplit, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait, Select

html = (pathlib.Path(__file__).resolve().parents[1] / 'static/index.html').read_bytes()
rows = [dict(id=str(i), user='azureuser' if i % 2 else 'developer', hostname=f'workstation-{i:03}', source_ip=f'192.0.2.{i % 250 + 1}', fingerprint='SHA256:' + str(i).zfill(43), state=['pending', 'approved', 'revoked', 'expired', 'denied'][i % 5], expires_at='2099-09-08T12:00:00Z' if i % 5 == 1 else None, updated_at='2026-09-08T12:00:00Z') for i in range(1023)]
requests = []
failed = False
page_sizes = []
slow_started = threading.Event()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def do_GET(self):
        url = urlsplit(self.path)
        api = url.path == '/api/grants/page'
        data = html
        if api:
            params = {k: v[0] for k, v in parse_qs(url.query).items()}
            q = params.get('q', '').lower()
            state = params.get('state', 'all')
            limit = int(params.get('limit', 25))
            assert 1 <= limit <= 100
            snapshot = [dict(g) for g in rows]
            matches = [g for g in snapshot if (state == 'all' or state == g['state'] or (state == 'inactive' and g['state'] not in ['approved', 'pending'])) and any(q in str(g.get(key, '')).lower() for key in ['hostname', 'user', 'source_ip', 'fingerprint'])]
            mode = params.get('sort', 'priority')
            matches.sort(key=lambda g: ((0 if g['state'] == 'pending' else 1) if mode == 'priority' else g['hostname'].lower() if mode == 'name' else g.get('expires_at') or '9999' if mode == 'expiry' else 0, g['id']))
            pages = max(1, (len(matches) + limit - 1) // limit)
            page = min(pages, int(params.get('page', 1)))
            items = matches[(page - 1) * limit:page * limit]
            page_sizes.append(len(items))
            counts = dict(all=len(snapshot), pending=sum(g['state'] == 'pending' for g in snapshot), approved=sum(g['state'] == 'approved' for g in snapshot), inactive=sum(g['state'] not in ['pending', 'approved'] for g in snapshot))
            data = json.dumps(dict(items=items, page=page, pages=pages, total=len(matches), limit=limit, counts=counts, selected=next((g for g in snapshot if g['id'] == params.get('selected')), None))).encode()
            if q == 'slow-query':
                slow_started.set()
                time.sleep(1)
        self.send_response(503 if api and failed else 200)
        self.send_header('Content-Type', 'application/json' if api else 'text/html; charset=utf-8')
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass  # A superseded browser request was cancelled.

    def do_POST(self):
        assert self.path == '/api/decision'
        assert self.headers['X-ZTNA-Admin'] == '1'
        request = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        requests.append(request)
        grant = next(g for g in rows if g['id'] == request['id'])
        grant['state'] = dict(approve='approved', revoke='revoked', deny='denied')[request['action']]
        grant['hostname'] = request['hostname']
        self.send_response(204)
        self.end_headers()

server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
options = webdriver.ChromeOptions()
options.binary_location = '/usr/bin/chromium'
for arg in ['--headless', '--no-sandbox', '--disable-dev-shm-usage', '--window-size=1440,1080']:
    options.add_argument(arg)
options.set_capability('goog:loggingPrefs', {'browser': 'ALL'})
driver = webdriver.Chrome(service=Service("/usr/bin/chromedriver"), options=options)
wait = WebDriverWait(driver, 10)
def find(selector):
    return driver.find_element(By.CSS_SELECTOR, selector)
def idle():
    wait.until(lambda _: driver.execute_script('return !loading && !fetching'))

def fill(selector, value):
    element = find(selector)
    element.clear()
    element.send_keys(value)
    driver.execute_script('arguments[0].dispatchEvent(new Event("input", {bubbles:true}))', element)
    idle()
def refresh():
    driver.execute_async_script('const done=arguments[0]; refresh(true).then(done)')
def closed():
    wait.until(lambda _: not find('#detail').is_displayed())
try:
    driver.get(f'http://127.0.0.1:{server.server_port}/')
    wait.until(lambda _: find('#count-all').text == '1.023')
    assert len(driver.find_elements(By.CSS_SELECTOR, '#rows tr')) == 25
    find('#next').click()
    idle()
    assert find('#page').text == 'Página 2 de 41'
    fill('#search', 'workstation-001')
    assert len(driver.find_elements(By.CSS_SELECTOR, '#rows tr')) == 1
    fill('#search', '<img src=x onerror=alert(1)>')
    assert len(driver.find_elements(By.CSS_SELECTOR, '#rows tr')) == 0
    find('#clear').click()
    idle()
    find('.tab[data-filter=pending]').click()
    idle()
    find('#rows button').click()
    fill('#hostname', 'arch-pessoal')
    rows.append(dict(rows[0], id='new', hostname='new-request'))
    refresh()
    assert find('#hostname').get_attribute('value') == 'arch-pessoal'
    selected_id = driver.execute_script('return selected')
    current = next(g for g in rows if g['id'] == selected_id)
    current['state'] = 'approved'
    refresh()
    assert find('#revoke').is_displayed()  # Selected identity is outside the pending filter now.
    assert find('#hostname').get_attribute('value') == 'arch-pessoal'
    current['state'] = 'pending'
    refresh()
    Select(find('#duration')).select_by_value('3600')
    find('#approve').click()
    closed()
    assert requests[-1]['action'] == 'approve' and requests[-1]['seconds'] == 3600
    assert requests[-1]['hostname'] == 'arch-pessoal'
    find('.tab[data-filter=approved]').click()
    idle()
    fill('#search', 'arch-pessoal')
    find('#rows button').click()
    find('#revoke').click()
    driver.switch_to.alert.accept()
    closed()
    assert requests[-1]['action'] == 'revoke'
    fill('#search', '')
    find('.tab[data-filter=pending]').click()
    idle()
    find('#rows button').click()
    failed = True
    refresh()
    assert not find('#approve').is_enabled() and find('#error').is_displayed()
    failed = False
    refresh()
    assert find('#approve').is_enabled()
    find('#deny').click()
    closed()
    assert requests[-1]['action'] == 'deny'
    find('.tab[data-filter=all]').click()
    idle()
    driver.execute_script("const s=document.querySelector('#search');s.value='slow-query';s.dispatchEvent(new Event('input'))")
    assert slow_started.wait(3)
    fill('#search', 'workstation-001')
    time.sleep(1.2)
    assert len(driver.find_elements(By.CSS_SELECTOR, '#rows tr')) == 1
    assert 'workstation-001' in find('#rows').text
    fill('#search', '')
    Select(find('#size')).select_by_value('100')
    idle()
    assert len(driver.find_elements(By.CSS_SELECTOR, '#rows tr')) == 100
    assert max(page_sizes) <= 100
    Select(find('#size')).select_by_value('25')
    idle()
    driver.execute_script('window.scrollTo(0,0)')
    screenshots = pathlib.Path(tempfile.mkdtemp(prefix='ztna-ui-preview-'))
    driver.save_screenshot(str(screenshots / 'desktop.png'))
    driver.execute_cdp_cmd('Emulation.setDeviceMetricsOverride', {'width': 390, 'height': 844, 'deviceScaleFactor': 1, 'mobile': True})
    assert driver.execute_script('return document.documentElement.scrollWidth <= innerWidth')
    driver.save_screenshot(str(screenshots / 'mobile.png'))
    find('#rows button').click()
    assert find('#detail').is_displayed()
    find('#close').send_keys(Keys.ESCAPE)
    closed()
    assert not [e for e in driver.get_log('browser') if e['source'] == 'javascript' and e['level'] == 'SEVERE']
    print('PASS: server pages <=100, stale search cancellation, off-page selection, search, filters, preserved drafts, approve/revoke/deny, offline recovery, mobile overflow, keyboard dialog; no JS errors.')
    print('Screenshots:', screenshots)
finally:
    driver.quit()
    server.shutdown()
    server.server_close()
