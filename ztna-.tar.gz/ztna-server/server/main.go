// Servidor de teste para o pam_ztna.
//
// Fluxo:
//  1. O módulo PAM manda um POST cifrado em /authorize.
//  2. O servidor decifra, identifica o usuário e:
//     - se já tem sessão aprovada e válida -> libera na hora (code 200).
//     - senão, cria um pedido "pending" e espera (até --approve-timeout)
//       um admin aprovar ou negar pelo dashboard.
//  3. Depois de aprovado, o "cliente" (ex.: o host que fez login) pode abrir
//     um WebSocket de liveness em /ws/session?user=X. Se um admin revogar
//     pelo dashboard, esse socket é fechado na hora — é a "perda de conexão"
//     quando a sessão é revogada.
//
// Uso:
//   go run . --port 8080
// Depois abra http://127.0.0.1:8080/ para o dashboard.
package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"time"
)

type AuthRequest struct {
	User     string `json:"username"`
	Domain   string `json:"domain"`
	Hostname string `json:"hostname"`
	Role     string `json:"role"`
}

type authResult struct {
	Code        int    `json:"code"`
	Description string `json:"description"`
}

var store = NewSessionStore()

// --- dashboard: conjunto de conexões WS de admins conectados ---

type dashboardHub struct {
	conns map[*WSConn]bool
}

var dash = &dashboardHub{conns: map[*WSConn]bool{}}

func (h *dashboardHub) broadcast() {
	snap := store.Snapshot()
	b, err := json.Marshal(map[string]interface{}{"type": "snapshot", "sessions": snap})
	if err != nil {
		return
	}
	for c := range h.conns {
		if err := c.WriteText(string(b)); err != nil {
			c.Close()
			delete(h.conns, c)
		}
	}
}

func authorizeHandler(keys *serverKeys, approveTimeout time.Duration) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}

		var in struct {
			Data string `json:"data"`
		}
		if err := json.NewDecoder(io.LimitReader(r.Body, 1<<20)).Decode(&in); err != nil {
			http.Error(w, "bad json", http.StatusBadRequest)
			return
		}

		blob, err := decodeStdBase64(in.Data)
		if err != nil {
			http.Error(w, "bad base64", http.StatusBadRequest)
			return
		}

		plain, aesKey, iv, err := keys.decryptRequest(blob)
		if err != nil {
			log.Println("decrypt error:", err)
			http.Error(w, "bad payload", http.StatusBadRequest)
			return
		}

		var req AuthRequest
		if err := json.Unmarshal(plain, &req); err != nil {
			http.Error(w, "bad inner json", http.StatusBadRequest)
			return
		}
		log.Printf("pedido de auth: user=%s host=%s role=%s", req.User, req.Hostname, req.Role)

		var result authResult
		if store.IsActive(req.User, req.Hostname) {
			result = authResult{Code: 200, Description: "sessão já ativa"}
		} else {
			dash.broadcast() // avisa o dashboard que tem um pedido novo (pending)
			state := store.RequestApproval(req.User, req.Hostname, approveTimeout)
			if state == StateApproved {
				result = authResult{Code: 200, Description: "aprovado pelo operador"}
			} else {
				result = authResult{Code: 403, Description: "negado ou expirou a espera por aprovação"}
			}
			dash.broadcast()
		}

		respPlain, err := json.Marshal(result)
		if err != nil {
			http.Error(w, "internal error", http.StatusInternalServerError)
			return
		}
		encData, err := encryptResponse(respPlain, aesKey, iv)
		if err != nil {
			http.Error(w, "internal error", http.StatusInternalServerError)
			return
		}
		out, _ := json.Marshal(map[string]string{"data": encData})
		w.Header().Set("Content-Type", "application/json")
		w.Write(out)
	}
}

func dashboardWSHandler(w http.ResponseWriter, r *http.Request) {
	c, err := WSAccept(w, r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	dash.conns[c] = true
	dash.broadcast()

	defer func() {
		delete(dash.conns, c)
		c.Close()
	}()

	for {
		msg, err := c.ReadText()
		if err != nil {
			return
		}
		var cmd struct {
			Action string `json:"action"`
			User   string `json:"user"`
			Host   string `json:"host"`
		}
		if err := json.Unmarshal([]byte(msg), &cmd); err != nil {
			continue
		}
		switch cmd.Action {
		case "approve":
			store.Approve(cmd.User, cmd.Host)
		case "deny":
			store.Deny(cmd.User, cmd.Host)
		case "revoke":
			store.Revoke(cmd.User, cmd.Host)
		}
		dash.broadcast()
	}
}

// sessionWSHandler simula o canal de "sessão viva" que um host/cliente
// manteria aberto depois de logar. Se o admin revogar, o servidor fecha esse
// socket na hora — é a demonstração de "perde a conexão quando revogado".
func sessionWSHandler(w http.ResponseWriter, r *http.Request) {
	user := r.URL.Query().Get("user")
	host := r.URL.Query().Get("host")
	if user == "" {
		http.Error(w, "missing user", http.StatusBadRequest)
		return
	}
	c, err := WSAccept(w, r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	if !store.AttachLiveConn(user, host, c) {
		c.WriteText(`{"type":"error","message":"sem sessão aprovada para esse usuário"}`)
		c.Close()
		return
	}
	c.WriteText(`{"type":"connected"}`)
	dash.broadcast()

	for {
		if _, err := c.ReadText(); err != nil {
			return
		}
	}
}

func staticHandler(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" {
		http.NotFound(w, r)
		return
	}
	f, err := os.Open("static/index.html")
	if err != nil {
		http.Error(w, "dashboard não encontrado (rode a partir da pasta server/)", http.StatusInternalServerError)
		return
	}
	defer f.Close()
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	io.Copy(w, f)
}

func legacyLabMain() {
	port := flag.Int("port", 8080, "porta local")
	bind := flag.String("bind", "127.0.0.1", "endereço para escutar — use 0.0.0.0 (ou o IP da interface) para aceitar pedidos de outras máquinas/VMs")
	approveTimeout := flag.Duration("approve-timeout", 20*time.Second, "tempo de espera pela aprovação manual")
	certPath := flag.String("cert", "pam_ztna.pem", "certificado (aponte o pam_ztna.conf do módulo pra esse arquivo)")
	keyPath := flag.String("key", "pam_ztna.key", "chave privada (fica só no servidor, nunca sai daqui)")
	flag.Parse()

	keys, err := loadOrCreateKeys(*certPath, *keyPath)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("certificado de teste pronto em %s — configure cert=%s no pam_ztna.conf", *certPath, *certPath)

	mux := http.NewServeMux()
	mux.HandleFunc("/authorize", authorizeHandler(keys, *approveTimeout))
	mux.HandleFunc("/ws/dashboard", dashboardWSHandler)
	mux.HandleFunc("/ws/session", sessionWSHandler)
	mux.HandleFunc("/", staticHandler)

	addr := fmt.Sprintf("%s:%d", *bind, *port)
	server := &http.Server{Addr: addr, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	log.Printf("dashboard em http://%s/", addr)
	log.Fatal(server.ListenAndServe())
}
