package main

import (
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"net"
	"net/http"
	"os/exec"
	"pam-ztna-lab-server/internal/gate"
	"path/filepath"
	"testing"
	"time"
)

// Exercises the real helper process over the private socket. It does not claim
// to test sshd's signature verification or the system PAM configuration.
func TestHelperSocketFlow(t *testing.T) {
	dir := t.TempDir()
	bin := filepath.Join(dir, "ztna-keys")
	if out, err := exec.Command("go", "build", "-buildvcs=false", "-o", bin, "./cmd/ztna-keys").CombinedOutput(); err != nil {
		t.Fatalf("build: %v %s", err, out)
	}
	s, err := gate.Open(filepath.Join(dir, "grants.json"))
	if err != nil {
		t.Fatal(err)
	}
	socket := filepath.Join(dir, "auth.sock")
	ln, err := net.Listen("unix", socket)
	if err != nil {
		t.Fatal(err)
	}
	srv := &http.Server{Handler: keyHandler(s, time.Second)}
	defer srv.Close()
	go srv.Serve(ln)
	pub, _, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	wire := make([]byte, 51)
	binary.BigEndian.PutUint32(wire, 11)
	copy(wire[4:], "ssh-ed25519")
	binary.BigEndian.PutUint32(wire[15:], 32)
	copy(wire[19:], pub)
	key := base64.StdEncoding.EncodeToString(wire)
	run := func() *exec.Cmd {
		return exec.Command(bin, "--socket", socket, "alice", "ssh-ed25519", key, "192.0.2.10 54321 192.0.2.20 22")
	}
	cmd := run()
	var stdout bytes.Buffer
	cmd.Stdout = &stdout
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	var id string
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		rows := s.Snapshot()
		if len(rows) > 0 {
			if rows[0].SourceIP != "192.0.2.10" {
				t.Errorf("unexpected client IP: %s", rows[0].SourceIP)
			}
			id = rows[0].ID
			break
		}
		time.Sleep(time.Millisecond)
	}
	if id == "" {
		cmd.Wait()
		t.Fatal("helper did not create pending request")
	}
	if err := s.Decide(id, "approve", "test-laptop", 0); err != nil {
		t.Fatal(err)
	}
	if err := cmd.Wait(); err != nil {
		t.Fatal(err)
	}
	want := "ssh-ed25519 " + key + "\n"
	if stdout.String() != want {
		t.Fatal("unexpected authorized_keys output")
	}
	if out, err := run().Output(); err != nil || string(out) != want {
		t.Fatal("approved reconnect failed", err)
	}
	serverFirst := exec.Command(bin, "--socket", socket, "--server-first", "bob", "ssh-ed25519", key, "192.0.2.20 22 192.0.2.11 54321")
	if out, err := serverFirst.Output(); err == nil || len(out) != 0 {
		t.Fatal("unapproved server-first key emitted")
	}
	if got := s.Snapshot()[0].SourceIP; got != "192.0.2.11" {
		t.Fatalf("server-first client IP = %s", got)
	}
	if err := s.Decide(id, "revoke", "", 0); err != nil {
		t.Fatal(err)
	}
	if out, err := run().Output(); err == nil || len(out) != 0 {
		t.Fatal("revoked key emitted without reapproval")
	}
	srv.Close()
	if out, err := run().Output(); err == nil || len(out) != 0 {
		t.Fatal("service failure emitted a key")
	}
}
