package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/binary"
	"encoding/pem"
	"errors"
	"math/big"
	"os"
	"time"
)

type serverKeys struct {
	priv *rsa.PrivateKey
}

// loadOrCreateKeys gera um par de chaves de laboratório na primeira execução
// (cert.pem vai para o módulo PAM, key.pem fica só no servidor, 0600).
func loadOrCreateKeys(certPath, keyPath string) (*serverKeys, error) {
	if _, err := os.Stat(keyPath); err == nil {
		keyPEM, err := os.ReadFile(keyPath)
		if err != nil {
			return nil, err
		}
		block, _ := pem.Decode(keyPEM)
		if block == nil {
			return nil, errors.New("invalid key PEM")
		}
		priv, err := x509.ParsePKCS1PrivateKey(block.Bytes)
		if err != nil {
			return nil, err
		}
		return &serverKeys{priv: priv}, nil
	}

	priv, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, err
	}
	tmpl := &x509.Certificate{
		SerialNumber: big.NewInt(time.Now().UnixNano()),
		Subject:      pkix.Name{CommonName: "pam-ztna-lab"},
		NotBefore:    time.Now(),
		NotAfter:     time.Now().AddDate(5, 0, 0),
		KeyUsage:     x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &priv.PublicKey, priv)
	if err != nil {
		return nil, err
	}

	certOut, err := os.Create(certPath)
	if err != nil {
		return nil, err
	}
	if err := pem.Encode(certOut, &pem.Block{Type: "CERTIFICATE", Bytes: der}); err != nil {
		certOut.Close()
		return nil, err
	}
	certOut.Close()

	keyOut, err := os.OpenFile(keyPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0600)
	if err != nil {
		return nil, err
	}
	if err := pem.Encode(keyOut, &pem.Block{Type: "RSA PRIVATE KEY", Bytes: x509.MarshalPKCS1PrivateKey(priv)}); err != nil {
		keyOut.Close()
		return nil, err
	}
	keyOut.Close()

	return &serverKeys{priv: priv}, nil
}

// decryptRequest espelha o layout do blob do módulo:
// [4 bytes BE: tamanho do RSA][RSA-OAEP(aesKey)][iv de 16 bytes][ciphertext AES-CBC]
func (k *serverKeys) decryptRequest(b []byte) (plain, aesKey, iv []byte, err error) {
	if len(b) < 4 {
		return nil, nil, nil, errors.New("blob too short")
	}
	rsaLen := binary.BigEndian.Uint32(b[:4])
	rest := b[4:]
	if uint64(len(rest)) < uint64(rsaLen)+aes.BlockSize {
		return nil, nil, nil, errors.New("blob truncated")
	}
	encAES := rest[:rsaLen]
	iv = rest[rsaLen : uint64(rsaLen)+aes.BlockSize]
	ct := rest[uint64(rsaLen)+aes.BlockSize:]

	aesKey, err = rsa.DecryptOAEP(sha256.New(), rand.Reader, k.priv, encAES, nil)
	if err != nil {
		return nil, nil, nil, err
	}
	if len(ct) == 0 || len(ct)%aes.BlockSize != 0 {
		return nil, nil, nil, errors.New("bad ciphertext size")
	}
	block, err := aes.NewCipher(aesKey)
	if err != nil {
		return nil, nil, nil, err
	}
	dec := make([]byte, len(ct))
	cipher.NewCBCDecrypter(block, iv).CryptBlocks(dec, ct)
	padLen := int(dec[len(dec)-1])
	if padLen <= 0 || padLen > aes.BlockSize || padLen > len(dec) {
		return nil, nil, nil, errors.New("bad padding")
	}
	return dec[:len(dec)-padLen], aesKey, iv, nil
}

// encryptResponse cifra a resposta com a MESMA chave/IV que o cliente mandou
// (é isso que o módulo PAM espera para conseguir decifrar de volta).
func encryptResponse(plain, aesKey, iv []byte) (string, error) {
	block, err := aes.NewCipher(aesKey)
	if err != nil {
		return "", err
	}
	padLen := aes.BlockSize - (len(plain) % aes.BlockSize)
	padded := append(append([]byte{}, plain...), bytes.Repeat([]byte{byte(padLen)}, padLen)...)
	ct := make([]byte, len(padded))
	cipher.NewCBCEncrypter(block, iv).CryptBlocks(ct, padded)
	return base64.StdEncoding.EncodeToString(ct), nil
}
