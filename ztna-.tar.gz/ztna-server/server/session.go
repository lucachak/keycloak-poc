package main

import (
	"sync"
	"time"
)

type SessionState string

const (
	StatePending  SessionState = "pending"
	StateApproved SessionState = "approved"
	StateDenied   SessionState = "denied"
	StateRevoked  SessionState = "revoked"
)

// Session representa um pedido de login de um usuário em um host específico.
// A combinação user+host é a chave real — o mesmo usuário pode ter sessões
// independentes em servidores diferentes ao mesmo tempo.
type Session struct {
	User      string       `json:"user"`
	Host      string       `json:"host"`
	State     SessionState `json:"state"`
	ExpiresAt time.Time    `json:"expires_at"`
	LiveConn  *WSConn      `json:"-"` // socket de "sessão aberta"; fechado ao revogar
}

func sessionKey(user, host string) string {
	if host == "" {
		host = "unknown-host"
	}
	return user + "@" + host
}

type SessionStore struct {
	mu       sync.Mutex
	sessions map[string]*Session
	waiters  map[string]chan SessionState
}

func NewSessionStore() *SessionStore {
	return &SessionStore{
		sessions: make(map[string]*Session),
		waiters:  make(map[string]chan SessionState),
	}
}

// RequestApproval bloqueia até um admin aprovar/negar pelo dashboard, ou até
// o timeout — simula um push de aprovação (tipo Duo/Okta Verify).
// A pendência é isolada por user+host: aprovar lucas@web-01 não libera
// lucas@web-02.
func (s *SessionStore) RequestApproval(user, host string, timeout time.Duration) SessionState {
	key := sessionKey(user, host)
	s.mu.Lock()
	ch := make(chan SessionState, 1)
	s.waiters[key] = ch
	s.sessions[key] = &Session{User: user, Host: host, State: StatePending}
	s.mu.Unlock()

	select {
	case st := <-ch:
		return st
	case <-time.After(timeout):
		s.mu.Lock()
		delete(s.waiters, key)
		if sess, ok := s.sessions[key]; ok && sess.State == StatePending {
			sess.State = StateDenied
		}
		s.mu.Unlock()
		return StateDenied
	}
}

func (s *SessionStore) Approve(user, host string) {
	key := sessionKey(user, host)
	s.mu.Lock()
	defer s.mu.Unlock()
	sess, ok := s.sessions[key]
	if !ok {
		sess = &Session{User: user, Host: host}
		s.sessions[key] = sess
	}
	sess.State = StateApproved
	sess.ExpiresAt = time.Now().Add(8 * time.Hour)
	if ch, ok := s.waiters[key]; ok {
		ch <- StateApproved
		delete(s.waiters, key)
	}
}

func (s *SessionStore) Deny(user, host string) {
	key := sessionKey(user, host)
	s.mu.Lock()
	defer s.mu.Unlock()
	if sess, ok := s.sessions[key]; ok {
		sess.State = StateDenied
	}
	if ch, ok := s.waiters[key]; ok {
		ch <- StateDenied
		delete(s.waiters, key)
	}
}

// Revoke marca a sessão (user+host) como revogada e derruba o socket de
// liveness, se existir — é o "perde a conexão" quando revogado.
func (s *SessionStore) Revoke(user, host string) {
	key := sessionKey(user, host)
	s.mu.Lock()
	defer s.mu.Unlock()
	sess, ok := s.sessions[key]
	if !ok {
		return
	}
	sess.State = StateRevoked
	if sess.LiveConn != nil {
		sess.LiveConn.Close()
		sess.LiveConn = nil
	}
}

func (s *SessionStore) IsActive(user, host string) bool {
	key := sessionKey(user, host)
	s.mu.Lock()
	defer s.mu.Unlock()
	sess, ok := s.sessions[key]
	if !ok {
		return false
	}
	return sess.State == StateApproved && time.Now().Before(sess.ExpiresAt)
}

// AttachLiveConn associa o socket de "sessão aberta" simulado a uma sessão
// já aprovada para esse user+host. Retorna false se não houver sessão
// aprovada correspondente.
func (s *SessionStore) AttachLiveConn(user, host string, c *WSConn) bool {
	key := sessionKey(user, host)
	s.mu.Lock()
	defer s.mu.Unlock()
	sess, ok := s.sessions[key]
	if !ok || sess.State != StateApproved {
		return false
	}
	sess.LiveConn = c
	return true
}

func (s *SessionStore) Snapshot() []*Session {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]*Session, 0, len(s.sessions))
	for _, v := range s.sessions {
		cp := *v
		cp.LiveConn = nil
		out = append(out, &cp)
	}
	return out
}
