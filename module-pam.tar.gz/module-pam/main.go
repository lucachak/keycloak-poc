package main

/*
#cgo LDFLAGS: -lpam

#include <security/pam_appl.h>
#include <stdlib.h>

static int get_pam_user(pam_handle_t *pamh, char **out) {
	const void *item = NULL;

	int result = pam_get_item(
		pamh,
		PAM_USER,
		&item
	);

	if (result == PAM_SUCCESS && item != NULL) {
		*out = (char *)item;
	}

	return result;
}
*/
import "C"

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// TYPES, CONSTS E STRUCT
var sharedKey = []byte(
	"01234567890123456789012345678901",
)

const (
	authURL = "http://localhost:8000/auth"
	secretKey = "lucas-de-almeida-lucachak-amorin"
	requestToken = "123-123"
)

type EncryptedEnvelope struct {
	Data string `json:"data"`
}

type AuthRequest struct {
	Username string `json:"username"`
	Message  string `json:"message"`
	Token    string `json:"token"`
	Key      int64  `json:"key"`
}

type AuthResponse struct {
	Token string `json:"token"`
}

type AuthClaims struct {
	Username string `json:"username"`
	Message  string `json:"message"`
	Token    string `json:"token"`
	Key      int64  `json:"key"`

	jwt.RegisteredClaims
}


//FUNCS 
func encrypt(
	data []byte,
	key []byte,
) (string, error) {

	block, err := aes.NewCipher(key)
	if err != nil {
		return "", fmt.Errorf("AES cipher: %w", err)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", fmt.Errorf("AES-GCM: %w", err)
	}

	nonce := make(
		[]byte,
		gcm.NonceSize(),
	)

	if _, err := io.ReadFull(
		rand.Reader,
		nonce,
	); err != nil {
		return "", fmt.Errorf("nonce: %w", err)
	}

	ciphertext := gcm.Seal(
		nil, nonce, data, nil,
	)

	result := append(nonce, ciphertext...)

	return base64.StdEncoding.EncodeToString(result), nil
}

func decrypt(
	encoded string,
	key []byte,
) ([]byte, error) {

	raw, err := base64.StdEncoding.DecodeString(
		encoded,
	)
	if err != nil {
		return nil, fmt.Errorf(
			"base64: %w",
			err,
		)
	}

	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf(
			"AES cipher: %w",
			err,
		)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf(
			"AES-GCM: %w",
			err,
		)
	}

	nonceSize := gcm.NonceSize()

	if len(raw) < nonceSize {
		return nil, fmt.Errorf("mensagem criptografada inválida")
	}

	nonce := raw[:nonceSize]
	ciphertext := raw[nonceSize:]

	plaintext, err := gcm.Open(
		nil,
		nonce,
		ciphertext,
		nil,
	)

	if err != nil {
		return nil, fmt.Errorf("decrypt AES-GCM: %w", err)
	}

	return plaintext, nil
}

func decodeToken(
	tokenString string,
) (*AuthClaims, error) {

	claims := &AuthClaims{}

	token, err := jwt.ParseWithClaims(
		tokenString,
		claims,
		func(token *jwt.Token) (interface{}, error) {
			return []byte(secretKey), nil
		},
		jwt.WithValidMethods(
			[]string{jwt.SigningMethodHS256.Alg()}),
	)
	if err != nil {
		return nil, fmt.Errorf("JWT: %w", err)
	}

	if !token.Valid {
		return nil, fmt.Errorf("JWT inválido")
	}
	return claims, nil
}

func validateResponse(
	resp *http.Response,
	expectedUsername string,
	expectedToken string,
) bool {

	var envelope EncryptedEnvelope

	if err := json.NewDecoder(
		resp.Body,
	).Decode(&envelope); err != nil {
		fmt.Println("erro lendo envelope:", err)

		return false
	}

	if envelope.Data == "" {
		fmt.Println("response não contém data")
		return false
	}

	fmt.Println("\n=== RESPONSE CRIPTOGRAFADO ===")

	fmt.Println(envelope.Data)
	plaintext, err := decrypt(envelope.Data, sharedKey)

	if err != nil {
		fmt.Println("erro decriptando response:", err)
		return false
	}

	fmt.Println("\n=== RESPONSE DECRIPTADO ===")
	fmt.Println(string(plaintext))

	var authResponse AuthResponse

	if err := json.Unmarshal(
		plaintext,
		&authResponse,
	); err != nil {
		fmt.Println("erro decodificando AuthResponse:", err)

		return false
	}

	if authResponse.Token == "" {
		fmt.Println("JWT vazio")

		return false
	}

	fmt.Println("\n=== JWT RECEBIDO ===")
	fmt.Println(authResponse.Token)

	claims, err := decodeToken(
		authResponse.Token,
	)

	if err != nil {
		fmt.Println(
			"JWT inválido:",
			err,
		)

		return false
	}

	if claims.Username != expectedUsername {
		fmt.Printf(
			"username incorreto: %q != %q\n",
			claims.Username,
			expectedUsername,
		)

		return false
	}

	if claims.Token != expectedToken {
		fmt.Printf(
			"token incorreto: %q != %q\n",
			claims.Token,
			expectedToken,
		)

		return false
	}

	fmt.Println(
		"\n=== JWT VALIDADO ===",
	)

	fmt.Println(
		"Username:",
		claims.Username,
	)

	fmt.Println(
		"Message:",
		claims.Message,
	)

	fmt.Println(
		"Token:",
		claims.Token,
	)

	fmt.Println(
		"Key:",
		claims.Key,
	)

	return true
}

func sendAuthRequest(
	username string,
) (*http.Response, error) {

	payload := AuthRequest{
		Username: username,
		Message:  "login",
		Token:    requestToken,
		Key:      13,
	}

	jsonData, err := json.Marshal(
		payload,
	)
	if err != nil {
		return nil, fmt.Errorf(
			"marshal payload: %w",
			err,
		)
	}

	fmt.Println(
		"\n=== REQUEST ORIGINAL ===",
	)

	fmt.Println(
		string(jsonData),
	)

	encrypted, err := encrypt(
		jsonData,
		sharedKey,
	)

	if err != nil {
		return nil, fmt.Errorf(
			"encrypt request: %w",
			err,
		)
	}

	fmt.Println(
		"\n=== REQUEST CRIPTOGRAFADO ===",
	)

	fmt.Println(encrypted)

	envelope := EncryptedEnvelope{
		Data: encrypted,
	}

	bodyJSON, err := json.Marshal(
		envelope,
	)

	if err != nil {
		return nil, fmt.Errorf(
			"marshal envelope: %w",
			err,
		)
	}

	client := http.Client{
		Timeout: 3 * time.Second,
	}

	req, err := http.NewRequest(
		http.MethodPost,
		authURL,
		bytes.NewReader(bodyJSON),
	)

	if err != nil {
		return nil, fmt.Errorf(
			"criando HTTP request: %w",
			err,
		)
	}

	req.Header.Set(
		"Content-Type",
		"application/json",
	)

	return client.Do(req)
}

//export pam_sm_authenticate
func pam_sm_authenticate(
	pamh *C.pam_handle_t,
	flags C.int,
	argc C.int,
	argv **C.char,
) C.int {

	var cUser *C.char

	result := C.get_pam_user(
		pamh,
		&cUser,
	)

	if result != C.PAM_SUCCESS ||
		cUser == nil {

		fmt.Println(
			"não foi possível obter PAM_USER",
		)

		return C.PAM_AUTH_ERR
	}

	username := C.GoString(
		cUser,
	)

	fmt.Println(
		"\n=== PAM AUTH ===",
	)

	fmt.Println(
		"Username:",
		username,
	)

	resp, err := sendAuthRequest(
		username,
	)

	if err != nil {
		fmt.Println(
			"erro enviando autenticação:",
			err,
		)

		return C.PAM_AUTH_ERR
	}

	defer resp.Body.Close()

	fmt.Println(
		"HTTP status:",
		resp.StatusCode,
	)

	if resp.StatusCode != http.StatusOK {

		errorBody, _ := io.ReadAll(
			resp.Body,
		)

		fmt.Println(
			"Server response:",
			string(errorBody),
		)

		return C.PAM_AUTH_ERR
	}

	if !validateResponse(
		resp,
		username,
		requestToken,
	) {

		fmt.Println(
			"response inválido",
		)

		return C.PAM_AUTH_ERR
	}

	fmt.Println(
		"\n=== PAM SUCCESS ===",
	)

	return C.PAM_SUCCESS
}

//export pam_sm_setcred
func pam_sm_setcred(
	pamh *C.pam_handle_t,
	flags C.int,
	argc C.int,
	argv **C.char,
) C.int {

	return C.PAM_SUCCESS
}

func main() {}
