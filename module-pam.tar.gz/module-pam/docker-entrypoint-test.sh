#!/usr/bin/env bash
set -euo pipefail

echo "==> Starting FastAPI server"
uvicorn server:app --host 127.0.0.1 --port 8000 &
SERVER_PID=$!

cleanup() {
    kill "$SERVER_PID" 2>/dev/null || true
}
trap cleanup EXIT

echo "==> Waiting for port 8000"
python - <<'PY'
import socket
import time

for _ in range(50):
    try:
        with socket.create_connection(("127.0.0.1", 8000), timeout=0.2):
            raise SystemExit(0)
    except OSError:
        time.sleep(0.1)

raise SystemExit("FastAPI did not start on port 8000")
PY

echo "==> PAM module location"
find /usr/lib -path '*/security/pam_http.so' -print

echo "==> Running PAM test"
pamtester pam_cherokee admin authenticate
