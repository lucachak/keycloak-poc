
# pyrefly: ignore [missing-import]
from fastapi import FastAPI, HTTPException, Request

import base64
import json
import os
# pyrefly: ignore [missing-import]
import jwt
# pyrefly: ignore [missing-import]
import uvicorn
# pyrefly: ignore [missing-import]
from cryptography.exceptions import InvalidTag
# pyrefly: ignore [missing-import]
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


app = FastAPI(title="PAM Auth Test Server")


SHARED_KEY = b"01234567890123456789012345678901"
SECRET_KEY = "lucas-de-almeida-lucachak-amorin"


def decrypt_message(data: str) -> bytes:
    raw = base64.b64decode(data)

    if len(raw) < 12:
        raise ValueError("Mensagem criptografada muito curta")

    nonce = raw[:12]
    ciphertext = raw[12:]

    aesgcm = AESGCM(SHARED_KEY)

    return aesgcm.decrypt(
        nonce,
        ciphertext,
        None,
    )


def encrypt_message(data: bytes) -> str:
    aesgcm = AESGCM(SHARED_KEY)

    nonce = os.urandom(12)

    ciphertext = aesgcm.encrypt(
        nonce,
        data,
        None,
    )

    encrypted = nonce + ciphertext

    return base64.b64encode(encrypted).decode("utf-8")


def token_emission(request_payload: dict) -> str:
    token_payload = {
        "username": request_payload["username"],
        "message": "isso e uma mensagem de teste pra testar decrypt/encrypt",
        "token": request_payload["token"],
        "key": 10, #exemplo, se for necessario uma key/cert
    }

    return jwt.encode(
        token_payload,
        SECRET_KEY,
        algorithm="HS256",
    )


@app.post("/auth")
async def auth_endpoint(request: Request):
    try:
        body = await request.json()

        encrypted_request = body["data"]

        plaintext = decrypt_message(encrypted_request)

        request_payload = json.loads(plaintext)

        print("\n=== REQUEST DECRIPTADO ===")
        print(request_payload)

        jwt_token = token_emission(request_payload)

        response_payload = {
            "token": jwt_token,
        }

        response_json = json.dumps(
            response_payload
        ).encode("utf-8")

        encrypted_response = encrypt_message(
            response_json
        )

        print("\n=== JWT GERADO ===")
        print(jwt_token)

        print("\n=== RESPONSE ENCRIPTADO ===")
        print(encrypted_response)

        return {
            "data": encrypted_response,
        }

    except InvalidTag:
        print("AES-GCM: authentication tag inválida")

        raise HTTPException(
            status_code=401,
            detail="Mensagem criptografada inválida",
        )

    except Exception as err:
        print("ERRO:", err)

        raise HTTPException(
            status_code=400,
            detail=str(err),
        )


if __name__ == "__main__":
    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )